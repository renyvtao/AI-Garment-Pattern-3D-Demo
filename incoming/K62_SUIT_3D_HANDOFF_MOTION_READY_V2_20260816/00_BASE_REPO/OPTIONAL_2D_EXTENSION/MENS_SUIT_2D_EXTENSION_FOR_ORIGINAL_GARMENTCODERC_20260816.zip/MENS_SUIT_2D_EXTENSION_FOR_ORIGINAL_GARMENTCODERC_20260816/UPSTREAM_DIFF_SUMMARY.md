# 与 biansy000/GarmentCodeRC upstream main 的 2D 集成差异

- upstream `assets/garment_programs/` 当前只有通用服装模块（如 bodice.py / sleeves.py / collars.py / meta_garment.py 等），没有本包的 27 个男西装文件。
- upstream `assets/design_params/` 根目录没有男西装 canonical YAML / suit_parametric 规则目录。
- 本包的 27 个 Python 文件均按 upstream 的 `assets/garment_programs/` 机制新增，不需要覆盖原来的 bodice.py、sleeves.py、collars.py 等。
- 对 upstream 已有代码的唯一必需改动：`assets/garment_programs/meta_garment.py` 增加一行 `MensSuitJacketCleanFinal` import。
- 2D 移植不要求修改 `pygarment/` 核心。
