@echo off
setlocal
echo ============================================================
echo MENS_SUIT_2D_EXTENSION - install + 2D smoke test
echo This package DOES NOT install the 3D/Warp runtime.
echo Activate the colleague's original GarmentCode environment first.
echo ============================================================
set /p REPO=Please input original GarmentCode/GarmentCodeRC repo path: 
python "%~dp0install_to_original_repo.py" --repo "%REPO%" --run-test --run-matrix
if errorlevel 1 (
  echo.
  echo FAILED. See error above.
  pause
  exit /b 1
)
echo.
echo PASS.
pause
