# -*- coding: utf-8 -*-
"""Static dependency audit for the installed 2D suit extension."""
from pathlib import Path
import ast
import json

ROOT = Path(__file__).resolve().parent
GP = ROOT / "assets/garment_programs"

EXPECTED = {
    "formal_suit_back_panel", "formal_suit_front_panel", "formal_suit_front_v0",
    "formal_suit_six_panel", "formal_ws_shape_fit", "mens_suit_jacket_clean_final",
    "mens_third_gen_basic_block", "mens_two_piece_sleeve_data",
    "parametric_suit_collar_2d", "parametric_suit_front_lapel_2d",
    "parametric_two_piece_sleeve_2d", "sleeve_curve_utils",
    "suit_button_components", "suit_collar_lapel_draft", "suit_curve_rules_v2",
    "suit_feature_rules", "suit_front_draft", "suit_geometry",
    "suit_lapel_fold_semantics", "suit_pattern_data", "suit_peak_lapel_geometry",
    "suit_pocket_components", "suit_six_panel_geometry", "suit_stage_a6_unified_2d",
    "suit_stage_clean_final_2d", "suit_two_piece_sleeve_draft_a5", "suit_waist_draft",
}

missing_files = sorted(x for x in EXPECTED if not (GP / f"{x}.py").is_file())
external_custom_imports = []

for stem in sorted(EXPECTED):
    p = GP / f"{stem}.py"
    if not p.is_file():
        continue
    tree = ast.parse(p.read_text(encoding="utf-8"), filename=str(p))
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module and node.module.startswith("assets.garment_programs."):
            dep = node.module.rsplit(".", 1)[-1]
            if dep not in EXPECTED:
                external_custom_imports.append({"file": p.name, "import": node.module})

meta = GP / "meta_garment.py"
import_line = "from assets.garment_programs.mens_suit_jacket_clean_final import *"
meta_registered = meta.is_file() and import_line in meta.read_text(encoding="utf-8")

required_yaml = [
    ROOT / "assets/design_params/mens-suit-jacket-clean-final.yaml",
    ROOT / "assets/design_params/suit_parametric/front_notched.yaml",
    ROOT / "assets/design_params/suit_parametric/rules_v1/construction_rules.yaml",
    ROOT / "assets/design_params/suit_parametric/sleeve_curve_shapes_clean.yaml",
]
missing_yaml = [str(p) for p in required_yaml if not p.is_file()]

report = {
    "expected_custom_python_count": len(EXPECTED),
    "missing_custom_python": missing_files,
    "external_custom_garment_program_imports": external_custom_imports,
    "meta_registered": meta_registered,
    "missing_required_yaml": missing_yaml,
    "pygarment_core_modified_by_this_package": False,
    "3d_runtime_installed_by_this_package": False,
}
passed = not missing_files and not external_custom_imports and meta_registered and not missing_yaml
report["status"] = "PASS" if passed else "FAIL"
print(json.dumps(report, ensure_ascii=False, indent=2))
if not passed:
    raise SystemExit(1)
