# 当前男西装 2D 文件说明

本表对应本移植包 payload 中的 27 个新增 Python 文件。它们均位于原始仓库的 `assets/garment_programs/` 下。

| 文件 | 作用 |
|---|---|
| `formal_suit_back_panel.py` | 把正式后身二维边界转成 PyGarment Panel；维护后领口、肩线、袖窿、侧缝、下摆等语义接口。 |
| `formal_suit_front_panel.py` | 四开身前片的正式 PyGarment Panel 适配层；负责前门襟、肩线、袖窿、侧缝/省、下摆、平/枪驳领前片边界及语义分组。 |
| `formal_suit_front_v0.py` | 正式西装前身的纯二维制版结果层；从基础块/规则生成前身关键点与边界，不创建 3D。 |
| `formal_suit_six_panel.py` | 六开身前身 PyGarment 适配层；把前身拆为前中片 + 前侧片（princess/前侧缝），制版计算本身由 suit_six_panel_geometry.py 提供。 |
| `formal_ws_shape_fit.py` | 正式前身 WS 曲线的约束拟合辅助，保证基础轮廓向正式西装轮廓过渡稳定。 |
| `mens_suit_jacket_clean_final.py` | 对原始 MetaGarment 暴露的新上衣入口类 MensSuitJacketCleanFinal；本身很薄，只调用 clean-final 2D 构造链。 |
| `mens_third_gen_basic_block.py` | 第三代男装标准基本纸样：根据人体尺寸生成前/后基础块，是整个西装二维制版的几何底座。 |
| `mens_two_piece_sleeve_data.py` | 两片袖历史/参考几何常量与语义点数据；保留部分基准参考。 |
| `parametric_suit_collar_2d.py` | 把领子制版结果转换成真实 PyGarment 2D collar Panel；不负责 3D 翻折。 |
| `parametric_suit_front_lapel_2d.py` | 把 A4 领/驳点更新应用到前片；枪驳领分支在这里把 peak 几何接入前片，同时保持 3D 不介入。 |
| `parametric_two_piece_sleeve_2d.py` | 把大袖片/小袖片的制版结果转换成真实 PyGarment 2D Panels。 |
| `sleeve_curve_utils.py` | 两片袖曲线到 PyGarment Edge/CurveEdge 的辅助函数。 |
| `suit_button_components.py` | 扣子二维语义/预览组件；记录 button_1/button_2 等位置，不建立真实物理扣合。 |
| `suit_collar_lapel_draft.py` | 领子与驳领的核心二维构造规则，计算 r3/r5/r7/r8/s1...s6 等关键点及领片几何。 |
| `suit_curve_rules_v2.py` | 通用二维 Bézier 曲线工具：反向、重定向、分割、采样、长度和控制点转换等。 |
| `suit_feature_rules.py` | 统一解析 button_count、口袋开关等设计特征，并区分仅渲染语义与后续物理特征。 |
| `suit_front_draft.py` | 四开身前身纯二维制版层；从设计参数和基本块生成正式前身点、长度和诊断。 |
| `suit_geometry.py` | 固定二维几何到 PyGarment Edge/EdgeSequence 的轻量辅助。 |
| `suit_lapel_fold_semantics.py` | 平驳/枪驳共用的二维驳折线语义；用于标记折线，不执行 Warp/3D 翻折。 |
| `suit_pattern_data.py` | 四开身平驳领历史冻结几何/基准数据，用于重建、对照和兼容。 |
| `suit_peak_lapel_geometry.py` | 枪驳领前身局部二维分支：从共同驳领基准推导 y2/y3/y4/y5 并替换上部前门襟/驳头边界。 |
| `suit_pocket_components.py` | 口袋线语义：左胸小袋 q1-q2-q3-q4、左右下袋 p1-n9；当前不是额外布片，也不产生缝合。 |
| `suit_six_panel_geometry.py` | 六开身动态二维几何：把前片拆分为前中/前侧并生成 princess/前侧缝相关边界。 |
| `suit_stage_a6_unified_2d.py` | 二维总执行器：人体+设计→基本块→前/后身→腰围→领驳→4/6开身→袖窿长度→两片袖→真实 2D 组件。 |
| `suit_stage_clean_final_2d.py` | 当前正式 clean-final 2D 入口：在 A6 几何上叠加口袋线和装饰扣子语义，不重建主体/袖子。 |
| `suit_two_piece_sleeve_draft_a5.py` | 两片袖核心二维规则：依据当前袖窿 AH 和人体臂长构造大袖片/小袖片，曲线形状由独立 YAML 控制。 |
| `suit_waist_draft.py` | 腰围松量二维规则：按正式分配规则调整腰部收量；明确不涉及 placement/Warp。 |
