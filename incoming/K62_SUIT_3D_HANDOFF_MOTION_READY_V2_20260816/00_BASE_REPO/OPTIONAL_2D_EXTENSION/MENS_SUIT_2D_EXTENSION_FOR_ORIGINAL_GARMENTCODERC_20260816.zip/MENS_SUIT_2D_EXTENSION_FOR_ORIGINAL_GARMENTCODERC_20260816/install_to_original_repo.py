# -*- coding: utf-8 -*-
"""Install the 2D MensSuitJacketCleanFinal extension into a pristine GarmentCode/GarmentCodeRC checkout.

Only:
- copies new 2D suit files under their original relative paths;
- patches ONE import line into assets/garment_programs/meta_garment.py;
- copies smoke-test scripts.

It does NOT copy/modify:
- pygarment core;
- BoxMesh/Warp/simulation code;
- 3D placement authorities;
- body OBJ or simulation properties.
"""
from pathlib import Path
import argparse
import hashlib
import shutil
import subprocess
import sys

HERE = Path(__file__).resolve().parent
PAYLOAD = HERE / "payload"
IMPORT_LINE = "from assets.garment_programs.mens_suit_jacket_clean_final import *"


def digest(p: Path):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for b in iter(lambda: f.read(1024 * 1024), b""):
            h.update(b)
    return h.hexdigest()


def copy_with_backup(src: Path, dst: Path):
    dst.parent.mkdir(parents=True, exist_ok=True)
    if dst.exists():
        if digest(src) == digest(dst):
            print(f"[SAME] {dst}")
            return
        backup = dst.with_name(dst.name + ".before_mens_suit_2d_handoff.bak")
        if not backup.exists():
            shutil.copy2(dst, backup)
            print(f"[BACKUP] {dst} -> {backup}")
    shutil.copy2(src, dst)
    print(f"[COPY] {src.relative_to(PAYLOAD)} -> {dst}")


def patch_meta(repo: Path):
    p = repo / "assets/garment_programs/meta_garment.py"
    if not p.is_file():
        raise FileNotFoundError(f"Original meta_garment.py not found: {p}")

    txt = p.read_text(encoding="utf-8")
    if IMPORT_LINE in txt:
        print("[PATCH] meta_garment.py already contains MensSuitJacketCleanFinal import")
        return

    backup = p.with_name("meta_garment.py.before_mens_suit_2d_handoff.bak")
    if not backup.exists():
        shutil.copy2(p, backup)
        print(f"[BACKUP] {p} -> {backup}")

    lines = txt.splitlines()
    insert_at = 0
    for i, line in enumerate(lines):
        s = line.strip()
        if s.startswith("from assets.garment_programs.") or s.startswith("import assets.garment_programs."):
            insert_at = i + 1

    lines.insert(insert_at, IMPORT_LINE)
    p.write_text("\n".join(lines) + "\n", encoding="utf-8")
    print(f"[PATCH] inserted one MensSuitJacketCleanFinal import into {p}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--repo", required=True, help="Path to pristine GarmentCode/GarmentCodeRC repo root")
    ap.add_argument("--run-test", action="store_true", help="Run basic 2D smoke test after installation")
    ap.add_argument("--run-matrix", action="store_true", help="Run four-case 4P/6P x notched/peak 2D smoke")
    args = ap.parse_args()

    repo = Path(args.repo).resolve()
    required = [
        repo / "assets/garment_programs/meta_garment.py",
        repo / "assets/bodies/body_params.py",
        repo / "pygarment",
    ]
    missing = [str(p) for p in required if not p.exists()]
    if missing:
        raise RuntimeError("Not a compatible repo root; missing: " + ", ".join(missing))

    for src in sorted(PAYLOAD.rglob("*")):
        if src.is_file():
            rel = src.relative_to(PAYLOAD)
            copy_with_backup(src, repo / rel)

    patch_meta(repo)

    for name in ("test_mens_suit.py", "test_mens_suit_2d_matrix.py", "verify_2d_dependency_closure.py"):
        shutil.copy2(HERE / name, repo / name)
        print(f"[COPY] {name} -> {repo / name}")

    print("\nINSTALL_2D_EXTENSION = PASS")
    print("No 3D runtime or pygarment core files were installed.")
    print("Next:")
    print(f'  cd /d "{repo}"')
    print("  python verify_2d_dependency_closure.py")
    print("  python test_mens_suit.py")
    print("  python test_mens_suit_2d_matrix.py")

    if args.run_test:
        cp = subprocess.run([sys.executable, str(repo / "test_mens_suit.py")], cwd=repo)
        if cp.returncode:
            raise SystemExit(cp.returncode)
    if args.run_matrix:
        cp = subprocess.run([sys.executable, str(repo / "test_mens_suit_2d_matrix.py")], cwd=repo)
        raise SystemExit(cp.returncode)


if __name__ == "__main__":
    main()
