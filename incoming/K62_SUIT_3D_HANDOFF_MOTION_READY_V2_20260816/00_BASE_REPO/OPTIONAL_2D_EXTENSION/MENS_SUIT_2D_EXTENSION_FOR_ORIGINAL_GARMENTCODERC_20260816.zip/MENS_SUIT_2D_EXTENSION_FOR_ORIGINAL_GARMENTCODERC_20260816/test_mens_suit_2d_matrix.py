# -*- coding: utf-8 -*-
"""Zero-Warp 2D smoke matrix: four_panel/six_panel x notched/peak."""
from copy import deepcopy
from pathlib import Path
import json
import sys
import yaml

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from assets.bodies.body_params import BodyParameters
from assets.garment_programs.meta_garment import MetaGarment


def set_leaf(design, key, value):
    node = design["suit"][key]
    if isinstance(node, dict) and "v" in node:
        node["v"] = value
    else:
        design["suit"][key] = value


def main():
    design_path = ROOT / "assets/design_params/mens-suit-jacket-clean-final.yaml"
    body_path = ROOT / "assets/bodies/mean_all.yaml"
    if not body_path.is_file():
        raise FileNotFoundError(
            "Original repo assets/bodies/mean_all.yaml is required for this smoke test. "
            "You can pass another compatible BodyParameters YAML by editing this script."
        )

    base = yaml.safe_load(design_path.read_text(encoding="utf-8"))["design"]
    body = BodyParameters(str(body_path))
    out = ROOT / "Logs/MENS_SUIT_2D_MATRIX"
    out.mkdir(parents=True, exist_ok=True)

    results = []
    for layout in ("six_panel", "four_panel"):
        for lapel in ("notched", "peak"):
            design = deepcopy(base)
            set_leaf(design, "body_panel_layout", layout)
            set_leaf(design, "lapel_style", lapel)
            name = f"{layout}_{lapel}"
            garment = MetaGarment(name, body, design)
            pattern = garment.assembly()
            folder = Path(pattern.serialize(
                out / name,
                tag="",
                to_subfolder=True,
                with_3d=False,
                with_text=False,
                view_ids=False,
                with_printable=True,
            ))
            spec = next(folder.rglob("*_specification.json"), None)
            if spec is None:
                raise RuntimeError(f"{name}: specification not created")
            doc = json.loads(spec.read_text(encoding="utf-8"))
            pat = doc.get("pattern", doc)
            row = {
                "case": name,
                "layout": layout,
                "lapel_style": lapel,
                "specification": str(spec),
                "panel_count": len(pat.get("panels", {})),
                "stitch_count": len(pat.get("stitches", [])),
                "warp_run": False,
                "status": "PASS",
            }
            results.append(row)
            print(f"{name}: PASS panels={row['panel_count']} stitches={row['stitch_count']}")

    (out / "MENS_SUIT_2D_MATRIX_REPORT.json").write_text(
        json.dumps(results, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print("MENS_SUIT_2D_MATRIX = PASS")
    print("WARP = NOT_RUN")


if __name__ == "__main__":
    main()
