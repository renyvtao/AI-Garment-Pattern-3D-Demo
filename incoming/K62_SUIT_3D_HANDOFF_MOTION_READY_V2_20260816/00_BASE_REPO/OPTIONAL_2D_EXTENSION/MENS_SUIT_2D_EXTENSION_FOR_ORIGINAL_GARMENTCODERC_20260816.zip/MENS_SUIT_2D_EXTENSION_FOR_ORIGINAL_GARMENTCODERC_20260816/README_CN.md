# MENS_SUIT_2D_EXTENSION_FOR_ORIGINAL_GARMENTCODERC

## 用途

把当前已经整理完成的 `MensSuitJacketCleanFinal` 男西装 **2D 参数化版片**，
以原始 GarmentCodeRC 的目录结构安装到一套未改动的 GarmentCode/GarmentCodeRC 解码器仓库。

本包只处理：

`人体测量 YAML + design YAML -> MensSuitJacketCleanFinal -> 2D sewing pattern -> specification / printable pattern`

不安装当前开发仓库里的 3D placement、BoxMesh 特殊逻辑、Warp、collision、驳领动态翻折或 K62 运行时。

## 为什么可以这样移植

当前 2D 依赖闭包包含 27 个自定义 `assets/garment_programs/*.py`。
静态依赖检查确认：这些文件之间的 `assets.garment_programs.*` 自定义导入全部落在这 27 个文件内部，
对原始 GarmentCodeRC 只依赖标准 `pygarment` / `BodyParameters` API。

原始 `MetaGarment` 通过 `design['meta']['upper']['v']` 取类名，再用 `globals()[类名]` 创建上衣。
因此只需在原始 `meta_garment.py` 增加一行导入，使 `MensSuitJacketCleanFinal` 进入其全局命名空间。

## 安装内容

- `payload/assets/garment_programs/`：27 个男西装 2D 新模块
- `payload/assets/design_params/`：1 个 canonical design + 3 个内部规则 YAML
- `PATCHES/meta_garment_patch.txt`：原始 `meta_garment.py` 单行补丁说明
- `test_mens_suit.py`：单例 2D smoke
- `test_mens_suit_2d_matrix.py`：4P/6P × notched/peak 四组合 2D smoke
- `verify_2d_dependency_closure.py`：静态依赖闭包检查
- `reference_inputs/mean_all_current_snapshot.yaml`：当前开发基线人体测量参考；默认不覆盖同学原仓库的 body YAML

## 安装

先让同学在原始仓库中确认原示例能运行，再激活原来的 conda 环境。

一键：

```bat
INSTALL_AND_TEST.bat
```

或：

```bat
python install_to_original_repo.py --repo "D:\GarmentCodeRC" --run-test --run-matrix
```

脚本会按 payload 中的原相对路径复制文件，并只对：

`assets/garment_programs/meta_garment.py`

增加：

```python
from assets.garment_programs.mens_suit_jacket_clean_final import *
```

如果目标存在同名且内容不同的文件，会先保存 `.before_mens_suit_2d_handoff.bak`。

## 成功标志

依次应看到：

- `verify_2d_dependency_closure.py` -> `"status": "PASS"`
- `test_mens_suit.py` -> `MENS_SUIT_PORTABLE_TEST = PASS`
- `test_mens_suit_2d_matrix.py` -> `MENS_SUIT_2D_MATRIX = PASS`

四组合测试只验证 2D/serialization，不运行 Warp。

## 解码器输出必须满足

上衣类型：

```yaml
meta:
  upper:
    v: MensSuitJacketCleanFinal
```

如果同学的“解码器软件”在 GarmentCode 之外还维护了 garment-type 白名单，
还需在该软件里把 `MensSuitJacketCleanFinal` 加入允许值。
这属于解码器模型/GUI 的 schema 适配，不是 GarmentCode 版片代码本身。

## 不要做

- 不要用你当前开发仓库的完整 `meta_garment.py` 覆盖对方原文件。
- 不要把 `suit_role_based_section_adapter.py`、`suit_fresh_3d_assembly.py`、frozen placement YAML 放进本 2D 包。
- 不要覆盖 `pygarment/`。
- 不要把 K62 world-space mesh 当新版片的一部分。
