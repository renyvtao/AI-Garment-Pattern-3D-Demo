# -*- coding: utf-8 -*-
"""
2D smoke test for MensSuitJacketCleanFinal after installing the minimal extension into an otherwise original GarmentCode/GarmentCodeRC repo.

Run from repo root:
    python test_mens_suit.py
or
    python test_mens_suit.py --design assets/design_params/mens-suit-jacket-clean-final.yaml
"""
from pathlib import Path
import argparse
import json
import shutil
import sys
import yaml

ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from assets.garment_programs.meta_garment import MetaGarment
from assets.bodies.body_params import BodyParameters


def find_spec(folder: Path):
    candidates = sorted(folder.rglob("*_specification.json"))
    return candidates[0] if candidates else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--design", default="assets/design_params/mens-suit-jacket-clean-final.yaml")
    ap.add_argument("--body", default="assets/bodies/mean_all.yaml")
    ap.add_argument("--output", default="Logs/MENS_SUIT_PORTABLE_TEST")
    args = ap.parse_args()

    design_path = (ROOT / args.design).resolve()
    body_path = (ROOT / args.body).resolve()
    out_root = (ROOT / args.output).resolve()
    out_root.mkdir(parents=True, exist_ok=True)

    if not design_path.is_file():
        raise FileNotFoundError(f"design file not found: {design_path}")
    if not body_path.is_file():
        raise FileNotFoundError(f"body file not found: {body_path}")

    with design_path.open("r", encoding="utf-8") as f:
        design_doc = yaml.safe_load(f)
    design = design_doc["design"]

    upper = design.get("meta", {}).get("upper", {}).get("v")
    if upper != "MensSuitJacketCleanFinal":
        raise RuntimeError(f"Unexpected upper garment entry: {upper!r}")

    body = BodyParameters(str(body_path))
    garment = MetaGarment("mens_suit_portable", body, design)
    pattern = garment.assembly()

    folder = Path(pattern.serialize(
        out_root,
        tag="",
        to_subfolder=True,
        with_3d=False,
        with_text=False,
        view_ids=False,
        with_printable=True,
    ))

    # Preserve exact inputs next to the generated sample.
    shutil.copy2(design_path, folder / "design_params.yaml")
    shutil.copy2(body_path, folder / "body_measurements.yaml")

    spec = find_spec(folder)
    panels = stitches = None
    if spec is not None:
        doc = json.loads(spec.read_text(encoding="utf-8"))
        pat = doc.get("pattern", doc)
        panels = len(pat.get("panels", {}))
        stitches = len(pat.get("stitches", []))

    result = {
        "PASS": True,
        "garment_class": upper,
        "design": str(design_path),
        "body": str(body_path),
        "output_folder": str(folder),
        "specification": str(spec) if spec else None,
        "panel_count": panels,
        "stitch_count": stitches,
        "scope": "PARAMETRIC_2D_PATTERN_SMOKE_ONLY",
        "warp_run": False,
    }
    (folder / "PORTABLE_TEST_RESULT.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print("=" * 72)
    print("MENS_SUIT_PORTABLE_TEST = PASS")
    print(f"output: {folder}")
    print(f"spec:   {spec}")
    print(f"panels: {panels}  stitches: {stitches}")
    print("NOTE: this test validates design parameters -> sewing pattern only; Warp was NOT run.")
    print("=" * 72)


if __name__ == "__main__":
    main()
