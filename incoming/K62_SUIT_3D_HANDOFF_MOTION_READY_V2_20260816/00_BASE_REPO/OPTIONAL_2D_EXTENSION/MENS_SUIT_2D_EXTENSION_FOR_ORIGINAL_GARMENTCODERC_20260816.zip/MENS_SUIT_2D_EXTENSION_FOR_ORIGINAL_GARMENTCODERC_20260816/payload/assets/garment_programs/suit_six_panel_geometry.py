"""Stage-A3 dynamic six-panel derivation.

A3 scope
--------
This module is 2-D only.  It consumes the *current* Stage-A2 formal front
geometry instead of re-reading frozen FRONT_POINTS / FRONT_EDGES.

Confirmed topology rule:
- four-panel p8/p9 front-side dart becomes a six-panel princess seam;
- derive p7 from current p8/p9;
- extend the p5->p7 direction from p7 to the current t8->t6 hem -> w1;
- center-front princess path: p5 -> p8 -> w1;
- side-front princess path:   p6 -> p9 -> w1;
- side-front to back side seam keeps m1 -> m7 -> t8 vs m1 -> m8 -> t7;
- current curved/straight front-opening choice is inherited unchanged.

No Warp, 3-D placement, collar, sleeve, q1/q2 debug override, or body attachment
is modified here.
"""
from __future__ import annotations

from copy import deepcopy
import numpy as np

from assets.garment_programs.formal_suit_front_panel import build_formal_front_boundary
from assets.garment_programs.suit_curve_rules_v2 import (
    apply_curve_overrides,
    find_oriented_record,
    path_length,
    record_length,
    ray_intersection_with_record,
    retarget_curve_endpoint,
    reverse_record,
    split_curve_at_t,
)


# Compatibility-only serialization rule recovered from the working reference.
# This is deliberately not a drafting/semantic point and never enters the
# formal result or design parameter schema.
_BOXMESH_COMPAT_SPLIT_ARCLENGTH_T = 0.6879514770124355
_BOXMESH_COMPAT_SPLIT_NAME = "boxmesh_compat_armhole_lower_split"


def _split_record_at_arclength(record, points, target_length, split_name):
    """Split one cubic record at a measured arc length (topology only)."""
    total = record_length(record, points, samples=4000)
    if not (0.0 < target_length < total):
        raise ValueError("BOXMESH_COMPAT_SPLIT_ARCLENGTH_OUT_OF_RANGE")
    lo, hi = 0.0, 1.0
    for _ in range(60):
        mid = 0.5 * (lo + hi)
        probe_points = deepcopy(points)
        left, _ = split_curve_at_t(record, probe_points, mid, "__compat_probe")
        value = record_length(left, probe_points, samples=1200)
        if value < target_length:
            lo = mid
        else:
            hi = mid
    return split_curve_at_t(record, points, 0.5 * (lo + hi), split_name)


def _apply_boxmesh_compat_armhole_split(points, armhole_lower):
    """Insert the reference-compatible internal child without changing shape."""
    if len(armhole_lower) != 3:
        return armhole_lower
    if not (
        armhole_lower[0].get("p1") == "prototype_c1"
        and armhole_lower[1].get("p0") == "prototype_c1"
        and armhole_lower[1].get("p1") == "ws_kappa_s_side"
    ):
        return armhole_lower
    interval_total = record_length(armhole_lower[1], points, samples=4000)
    left_len = _BOXMESH_COMPAT_SPLIT_ARCLENGTH_T * interval_total
    left, right = _split_record_at_arclength(
        armhole_lower[1], points, left_len, _BOXMESH_COMPAT_SPLIT_NAME
    )
    for rec in (left, right):
        rec["semantic_group"] = "armhole_lower"
        rec["source"] = "formal_ws_armhole_lower"
        rec["boxmesh_compatibility_only"] = True
    return [armhole_lower[0], left, right, armhole_lower[2]]


def derive_p7(points):
    """Recover the drafting center from the confirmed 2/3 : 1/3 p8/p9 rule."""
    p8 = np.asarray(points["p8"], dtype=float)
    p9 = np.asarray(points["p9"], dtype=float)
    return (p8 + (2.0 / 3.0) * (p9 - p8)).tolist()


def _group(records, name):
    return [deepcopy(r) for r in records if r.get("semantic_group") == name]


def _set_group(record, group, source=None):
    rec = deepcopy(record)
    rec["semantic_group"] = group
    if source is not None:
        rec["source"] = source
    return rec


def build_six_panel_geometry(
    formal_result,
    front_draft_result,
    params=None,
):
    """Build current six-panel geometry from one already-resolved A2 front.

    Parameters
    ----------
    formal_result:
        Stage-A2 FormalSuitFrontV0Result after optional waist parameterization.
    front_draft_result:
        The same shared SuitFrontDraftResult used by the current front panels.
    params:
        Optional six_panel.yaml-style mapping.  Only curve overrides are read.

    Returns
    -------
    dict
        Pure geometry/semantic records.  No pygarment objects are created.
    """
    params = params or {}
    overrides = params.get("curve_rule", {}).get("overrides", {})
    if not overrides:
        overrides = params.get("curve_overrides", {})

    # This is the critical A3 rule: consume the CURRENT A2 boundary, including
    # current M / break point / garment length / waist / straight-vs-curved mode.
    points, current_records = build_formal_front_boundary(
        formal_result, front_draft_result
    )
    points = deepcopy(points)

    # Current p8/p9 may have moved under waist_ease_cm; recover p7 from them.
    points["p7"] = derive_p7(points)

    hem = find_oriented_record(current_records, "t8", "t6")
    ray = np.asarray(points["p7"], dtype=float) - np.asarray(points["p5"], dtype=float)
    hem_t, w1, ray_lambda = ray_intersection_with_record(
        points["p7"], ray, hem, points
    )
    points["w1"] = list(w1)
    hem_t8_w1, hem_w1_t6 = split_curve_at_t(hem, points, hem_t, "w1")
    hem_t8_w1 = _set_group(hem_t8_w1, "hem", "six_hem_t8_w1")
    hem_w1_t6 = _set_group(hem_w1_t6, "hem", "six_hem_w1_t6")

    # Current A2 front-side dart legs.  These may be straight in the formal
    # front; if a future formal front makes them curves, chord-local shape is
    # still preserved by retarget_curve_endpoint().
    p5_p8 = find_oriented_record(current_records, "p5", "p8")
    p8_p4 = find_oriented_record(current_records, "p8", "p4")
    p9_p4 = find_oriented_record(current_records, "p9", "p4")
    p9_p6 = find_oriented_record(current_records, "p9", "p6")

    p8_w1 = retarget_curve_endpoint(
        p8_p4, points, points, "w1", source="six_princess_center_p8_w1"
    )
    p9_w1 = retarget_curve_endpoint(
        p9_p4, points, points, "w1", source="six_princess_side_p9_w1"
    )
    p5_p8 = _set_group(p5_p8, "princess", "six_princess_center_p5_p8")
    p8_w1 = _set_group(p8_w1, "princess")
    p9_w1 = _set_group(p9_w1, "princess")
    p9_p6 = _set_group(p9_p6, "princess", "six_princess_side_p9_p6")

    neckline = _group(current_records, "neckline")
    shoulder = _group(current_records, "shoulder")
    armhole_upper = _group(current_records, "armhole_upper")
    armhole_lower = _group(current_records, "armhole_lower")
    side_seam = _group(current_records, "side_seam")
    front_opening = _group(current_records, "front_opening")

    if not all((neckline, shoulder, armhole_upper, armhole_lower, side_seam, front_opening)):
        raise ValueError("STAGE_A3_MISSING_CURRENT_FRONT_SEMANTIC_GROUP")

    # Closed center-front boundary:
    # neckline -> shoulder -> upper armhole -> princess -> hem -> front opening.
    center_records = (
        neckline
        + shoulder
        + armhole_upper
        + [p5_p8, p8_w1]
        + [hem_w1_t6]
        + front_opening
    )

    # Closed side-front boundary:
    # lower armhole -> side seam -> hem -> princess back upward.
    # Boundary traversal is w1->p9->p6, while the semantic stitching interface
    # is exposed later as p6->p9->w1.
    side_records = (
        armhole_lower
        + side_seam
        + [hem_t8_w1]
        + [
            _set_group(reverse_record(p9_w1), "princess"),
            _set_group(p9_p6, "princess"),
        ]
    )

    armhole_lower = _apply_boxmesh_compat_armhole_split(points, armhole_lower)
    side_records = (
        armhole_lower
        + side_seam
        + [hem_t8_w1]
        + [
            _set_group(reverse_record(p9_w1), "princess"),
            _set_group(p9_p6, "princess"),
        ]
    )

    base_points = deepcopy(points)
    center_records = apply_curve_overrides(
        base_points, center_records, points, overrides
    )
    side_records = apply_curve_overrides(
        base_points, side_records, points, overrides
    )

    center_princess = [
        find_oriented_record(center_records, "p5", "p8"),
        find_oriented_record(center_records, "p8", "w1"),
    ]
    side_princess = [
        find_oriented_record(side_records, "p6", "p9"),
        find_oriented_record(side_records, "p9", "w1"),
    ]

    center_len = path_length(center_princess, points)
    side_len = path_length(side_princess, points)
    lower_sources = [
        rec.get("source")
        for rec in center_records
        if rec.get("semantic_group") == "front_opening"
    ]

    audit = {
        "dynamic_front_input": True,
        "p7": list(points["p7"]),
        "w1": list(points["w1"]),
        "hem_intersection_t": float(hem_t),
        "p7_ray_lambda": float(ray_lambda),
        "front_side_takeup_cm": abs(float(points["p9"][0]) - float(points["p8"][0])),
        "clean_waist_source": "current_formal_result_after_apply_waist_ease",
        "clean_waist_takeups_cm": deepcopy(
            formal_result.derived_quantities.get("waist_takeups_cm")
        ),
        "clean_back_center_points_present": all(
            name in formal_result.points
            for name in ("y1", "n1", "n2", "n3", "m2", "g")
        ),
        "p8_p9_consumed_from_current_waist": (
            np.allclose(points["p8"], formal_result.points["p8"])
            and np.allclose(points["p9"], formal_result.points["p9"])
        ),
        "center_princess_cm": float(center_len),
        "side_princess_cm": float(side_len),
        "princess_abs_diff_cm": abs(float(center_len) - float(side_len)),
        "front_princess_order": [["p5", "p6"], ["p8", "p9"], ["w1", "w1"]],
        "front_lower_edge_style": front_draft_result.derived_quantities.get(
            "front_lower_edge_style", "curved"
        ),
        "front_opening_sources": lower_sources,
        "removed_four_panel_dart_apex": "p4",
        "p4_is_not_on_six_panel_boundary": all(
            rec.get("p0") != "p4" and rec.get("p1") != "p4"
            for rec in center_records + side_records
        ),
    }

    return {
        "points": points,
        "center_records": center_records,
        "side_records": side_records,
        "center_princess_records": center_princess,
        "side_princess_records": side_princess,
        "chest_waist_dart": deepcopy(formal_result.internal_edges),
        "audit": audit,
    }
