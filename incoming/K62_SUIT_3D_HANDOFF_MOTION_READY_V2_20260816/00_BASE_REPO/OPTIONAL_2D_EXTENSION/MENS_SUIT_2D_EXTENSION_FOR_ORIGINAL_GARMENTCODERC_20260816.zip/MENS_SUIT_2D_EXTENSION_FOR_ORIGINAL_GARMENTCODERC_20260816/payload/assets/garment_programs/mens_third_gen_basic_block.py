"""
GarmentCodeRC component implementation of the third-generation
men's standard basic bodice block (第三代升级版男装标准基本纸样).

Target location in a GarmentCodeRC checkout:
    assets/garment_programs/mens_third_gen_basic_block.py

Scope:
- 2D drafting block: front half + back half.
- Intended as the geometric base for later suit-jacket derivation.
- Not yet a production suit and not intended for 3D simulation.
- Source-supported drafting constants are kept in YAML.
- A few curve-shape controls that the source figure does not numerically
  determine are explicitly marked as engineering controls in YAML.

GarmentCodeRC API used here:
    pyg.Panel
    pyg.Component
    pyg.Edge
    pyg.EdgeSequence
    pyg.Interface
    pyg.CurveEdgeFactory.curve_3_points
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Any, Sequence
import math
import numpy as np
import pygarment as pyg
import yaml

from assets.garment_programs.formal_ws_shape_fit import (
    evaluate_formal_ws_values,
    evaluate_selected_formal_ws_base,
)


_CONSTRUCTION_RULES_PATH = (
    Path(__file__).resolve().parents[1]
    / "design_params/suit_parametric/rules_v1/construction_rules.yaml"
)


def _load_armhole_drafting_constants():
    rules = yaml.safe_load(_CONSTRUCTION_RULES_PATH.read_text(encoding="utf-8"))
    node = rules["armhole_drafting_constants"]
    if node.get("parameter_role") != "FIXED_DRAFTING_CONSTANT":
        raise ValueError("ARMHOLE_DRAFTING_CONSTANT_ROLE_INVALID")
    values = node["values"]
    required = ("a4_left_cm", "a7_normal_cm", "c5_normal_cm", "c3_left_cm")
    if set(values) != set(required):
        raise ValueError("ARMHOLE_DRAFTING_CONSTANT_SET_INVALID")
    out = {name: float(values[name]) for name in required}
    if any(value <= 0.0 for value in out.values()):
        raise ValueError("ARMHOLE_DRAFTING_CONSTANT_NONPOSITIVE")
    return out


ARMHOLE_DRAFTING_CONSTANTS = _load_armhole_drafting_constants()


def _v(node: Dict[str, Any], key: str, default=None):
    """Read GarmentCode-style leaf: {'v': value, ...}."""
    if key not in node:
        return default
    value = node[key]
    if isinstance(value, dict) and "v" in value:
        return value["v"]
    return value


def _body(body, key: str, default=None):
    """BodyParameters supports __getitem__, not dict.get()."""
    try:
        return body[key]
    except (KeyError, TypeError):
        if default is None:
            raise
        return default


def _lerp(a: Sequence[float], b: Sequence[float], t: float):
    a = np.asarray(a, dtype=float)
    b = np.asarray(b, dtype=float)
    return (a + t * (b - a)).tolist()


def _offset_x(a: Sequence[float], b: Sequence[float], t: float, dx: float):
    """Point at fraction t of AB, then move horizontally by dx cm."""
    p = np.asarray(_lerp(a, b, t), dtype=float)
    p[0] += dx
    return p.tolist()


def _curve3(start, end, target):
    """
    GarmentCodeRC quadratic Bezier fitted to pass through target.

    GarmentCodeRC's curve_3_points() cannot handle a target lying exactly
    on the start-end chord: its internal perpendicular intersection segment
    collapses to zero length. Detect that case here and report it clearly.
    """
    start_a = np.asarray(start, dtype=float)
    end_a = np.asarray(end, dtype=float)
    target_a = np.asarray(target, dtype=float)

    edge = end_a - start_a
    edge_len = np.linalg.norm(edge)
    if edge_len < 1e-8:
        raise ValueError("Cannot build a curve from coincident start/end points")

    # signed normalized perpendicular distance of target from chord
    point_vec = target_a - start_a
    signed_area = edge[0] * point_vec[1] - edge[1] * point_vec[0]
    rel_y = signed_area / (edge_len * edge_len)

    if abs(rel_y) < 1e-7:
        raise ValueError(
            "curve_3_points target is collinear with start/end; "
            "use an explicit CurveEdge control point for this curve"
        )

    return pyg.CurveEdgeFactory.curve_3_points(
        list(start), list(end), list(target)
    )


@dataclass(frozen=True)
class PrototypeConstructionResult:
    points: dict
    point_records: dict
    derived_quantities: dict
    diagnostics: dict
    curve_audit: dict


@dataclass
class ThirdGenDraft:
    # Source/body inputs
    B: float
    back_length: float

    # Source-derived main dimensions
    half_girth_width: float
    chest_back_guide: float
    armscye_zone: float
    panel_width: float
    armscye_depth: float
    neck_width: float
    back_neck_rise: float
    back_shoulder_drop: float

    # Engineering/body-dependent shoulder control
    shoulder_seam: float

    # Source inherited adjustments
    front_shoulder_shorten: float
    front_armhole_inset: float
    back_armhole_upper_out: float
    back_armhole_lower_in: float
    shoulder_push_back: float

    # Optional curve-shape controls not uniquely fixed by the source figure
    neckline_rel_control_y: float

    @classmethod
    def from_body_design(cls, body, design):
        cfg = design["mens_basic_block"]

        B_override = float(_v(cfg, "bust_override_cm", -1.0))
        B = B_override if B_override > 0 else float(_body(body, "bust"))

        back_override = float(_v(cfg, "back_length_override_cm", -1.0))
        # GarmentCodeRC mean_male.yaml has waist_line; it is the closest
        # available body field to the back-waist length used by this block.
        back_length = (
            back_override if back_override > 0
            else float(_body(body, "waist_line"))
        )

        ease_total = float(_v(cfg, "circumference_ease_total_cm", 10.0))
        guide_add = float(_v(cfg, "chest_back_width_add_cm", 4.0))
        armscye_add = float(_v(cfg, "armscye_depth_add_cm", 9.5))
        neck_add = float(_v(cfg, "back_neck_width_add_cm", 0.5))
        neck_rise_div = float(_v(cfg, "back_neck_rise_divisor", 3.0))
        shoulder_drop_sub = float(_v(cfg, "back_shoulder_drop_sub_cm", 0.5))

        half_girth_width = B / 2.0 + ease_total
        chest_back_guide = B / 6.0 + guide_add
        armscye_zone = half_girth_width - 2.0 * chest_back_guide
        panel_width = chest_back_guide + armscye_zone / 2.0
        armscye_depth = B / 6.0 + armscye_add
        neck_width = B / 12.0 + neck_add
        back_neck_rise = neck_width / neck_rise_div
        back_shoulder_drop = neck_width / 2.0 - shoulder_drop_sub

        shoulder_seam = float(_v(cfg, "shoulder_seam_cm", 13.5))

        return cls(
            B=B,
            back_length=back_length,
            half_girth_width=half_girth_width,
            chest_back_guide=chest_back_guide,
            armscye_zone=armscye_zone,
            panel_width=panel_width,
            armscye_depth=armscye_depth,
            neck_width=neck_width,
            back_neck_rise=back_neck_rise,
            back_shoulder_drop=back_shoulder_drop,
            shoulder_seam=shoulder_seam,
            front_shoulder_shorten=float(_v(cfg, "front_shoulder_shorten_cm", 0.7)),
            front_armhole_inset=float(_v(cfg, "front_armhole_inset_cm", 0.5)),
            back_armhole_upper_out=float(_v(cfg, "back_armhole_upper_out_cm", 0.7)),
            back_armhole_lower_in=float(_v(cfg, "back_armhole_lower_in_cm", 0.3)),
            shoulder_push_back=float(_v(cfg, "back_shoulder_push_cm", 2.0)),
            neckline_rel_control_y=float(_v(cfg, "neckline_rel_control_y", 0.18)),
        )

    @property
    def underarm_y(self):
        return self.back_length - self.armscye_depth

    def front_points(self):
        """
        Named front-half drafting points.

        Coordinate convention:
        - x=0 is center front.
        - +x goes toward side seam.
        - y=0 is waist/base line.
        - +y goes upward.
        """
        d = self

        cf_waist = [0.0, 0.0]
        side_waist = [d.panel_width, 0.0]
        underarm = [d.panel_width, d.underarm_y]

        # Third-gen front neck width follows the enlarged back neck width.
        neck_side = [d.neck_width, d.back_length]
        neck_center = [0.0, d.back_length - d.neck_width]

        # Figure inherits the previous-generation front shoulder construction.
        # Use a source-inspired shoulder drop and an explicit seam-length control.
        front_drop = d.neck_width / 2.0
        front_len = max(1.0, d.shoulder_seam - d.front_shoulder_shorten)
        dx = math.sqrt(max(front_len ** 2 - front_drop ** 2, 0.25))
        shoulder = [neck_side[0] + dx, neck_side[1] - front_drop]

        # Split armhole into two quadratic segments so the source's local
        # 0.5 cm indentation can influence the upper armhole without forcing
        # the whole armhole into a single primitive.
        arm_break = _lerp(underarm, shoulder, 0.48)

        # Front indentation inherited from second generation:
        # use the quarter-depth region as a target; move toward center front.
        upper_target = _offset_x(
            arm_break, shoulder, 0.55, -d.front_armhole_inset
        )

        # "符合点" / lower armhole region: keep the target close to the
        # one-eighth depth area; no extra source offset is imposed here.
        lower_target = _offset_x(
            underarm, arm_break, 0.35, -0.15
        )

        return {
            "cf_waist": cf_waist,
            "side_waist": side_waist,
            "underarm": underarm,
            "arm_break": arm_break,
            "arm_lower_target": lower_target,
            "arm_upper_target": upper_target,
            "shoulder": shoulder,
            "neck_side": neck_side,
            "neck_center": neck_center,
        }

    def audited_prototype_points(self):
        """Return source-audited 2-D points of the basic men's prototype.

        These lettered points belong to the basic block, not to the suit-front
        derivation.  The coordinate convention matches the audited drafting
        document: ``a`` is the origin, +x is right and +y is up (drafting
        downward distances are therefore negative).

        This deliberately stops at rules confirmed in the audited document;
        suit-only points such as m1, m3, r3 and button construction points are
        not part of this result.
        """
        d = self
        B = float(d.B)
        O = float(d.neck_width)
        back_length = float(d.back_length)

        a = [0.0, 0.0]
        c = [0.0, -back_length]
        right = B / 2.0 + 10.0
        d_pt = [right, 0.0]
        e = [right, -back_length]
        depth = B / 6.0 + 9.5
        f = [0.0, -depth]
        g = [right, -depth]
        guide = B / 6.0 + 4.0
        h = [guide, -depth]
        i = [guide, 0.0]
        j = [right - guide, -depth]
        k = [right - guide, 0.0]
        l = [right - O, 0.0]
        m = [l[0], O / 3.0]
        n = [l[0] + O / 3.0, 0.0]
        p = [l[0] + 2.0 * O / 3.0, 0.0]
        q = [k[0], -(O / 2.0 - 0.5)]
        r = _lerp(m, l, 0.5)
        s = [q[0] - 2.0, q[1]]
        t = _lerp(r, s, 0.5)
        u = [0.0, -O]
        v = [B / 12.0 + 2.5, 0.0]

        return {
            "a": a, "c": c, "d": d_pt, "e": e,
            "f": f, "g": g, "h": h, "i": i,
            "j": j, "k": k, "l": l, "m": m,
            "n": n, "p": p, "q": q, "r": r,
            "s": s, "t": t, "u": u, "v": v,
        }

    def prototype_construction(self, *, garment_length_ratio=1.75, ws_shape_values=None):
        """Build the confirmed pre-suit construction-point skeleton.

        Names that collide with final suit-front semantics are deliberately
        prefixed with ``prototype_``.  This result contains no Panel objects
        and does not claim that the historical w-to-s Bezier controls are a
        dynamic curvature rule.
        """
        p = {name: list(value) for name, value in self.audited_prototype_points().items()}
        B = float(self.B)
        O = float(self.neck_width)
        depth = B / 6.0 + 9.5

        def midpoint(a, b):
            return [(a[0] + b[0]) / 2.0, (a[1] + b[1]) / 2.0]

        def distance(a, b):
            return math.hypot(b[0] - a[0], b[1] - a[1])

        def intersection(a, b, c, d):
            ax, ay = a
            bx, by = b
            cx, cy = c
            dx, dy = d
            det = (ax - bx) * (cy - dy) - (ay - by) * (cx - dx)
            if abs(det) < 1.0e-12:
                raise ValueError("prototype construction lines are parallel")
            n1 = ax * by - ay * bx
            n2 = cx * dy - cy * dx
            return [
                (n1 * (cx - dx) - (ax - bx) * n2) / det,
                (n1 * (cy - dy) - (ay - by) * n2) / det,
            ]

        def on_ray(origin, through, length):
            dx, dy = through[0] - origin[0], through[1] - origin[1]
            norm = math.hypot(dx, dy)
            if norm < 1.0e-12:
                raise ValueError("zero-length prototype construction ray")
            scale = length / norm
            return [origin[0] + scale * dx, origin[1] + scale * dy]

        def normal_candidates(origin, line_start, line_end, length):
            dx, dy = line_end[0] - line_start[0], line_end[1] - line_start[1]
            norm = math.hypot(dx, dy)
            if norm < 1.0e-12:
                raise ValueError("zero-length prototype normal reference")
            nx, ny = -dy / norm, dx / norm
            return (
                [origin[0] + length * nx, origin[1] + length * ny],
                [origin[0] - length * nx, origin[1] - length * ny],
            )

        formulas = {}
        upstream = {}
        provenance = {}
        stages = {}

        def record(name, value, formula, dependencies, stage="prototype_construction"):
            p[name] = [float(value[0]), float(value[1])]
            formulas[name] = formula
            upstream[name] = list(dependencies)
            provenance[name] = "confirmed_manual_drafting_rule"
            stages[name] = stage

        record("a3", [p["i"][0], p["i"][1] - 0.75 * depth],
               "vertical_down(i,0.75*(B/6+9.5))", ["i", "B"])
        ia3 = distance(p["i"], p["a3"])
        a3h = distance(p["a3"], p["h"])
        ih = distance(p["i"], p["h"])
        ratio_tolerance = 1.0e-9
        if not (
            math.isclose(ia3, 0.75 * depth, rel_tol=0.0, abs_tol=ratio_tolerance)
            and math.isclose(a3h, 0.25 * depth, rel_tol=0.0, abs_tol=ratio_tolerance)
            and math.isclose(ia3 + a3h, ih, rel_tol=0.0, abs_tol=ratio_tolerance)
            and math.isclose(ih, depth, rel_tol=0.0, abs_tol=ratio_tolerance)
        ):
            raise ValueError("A3_DRAFTING_RATIO_ASSERTION_FAILED")
        a4_left_cm = ARMHOLE_DRAFTING_CONSTANTS["a4_left_cm"]
        a7_normal_cm = ARMHOLE_DRAFTING_CONSTANTS["a7_normal_cm"]
        c5_normal_cm = ARMHOLE_DRAFTING_CONSTANTS["c5_normal_cm"]
        c3_left_cm = ARMHOLE_DRAFTING_CONSTANTS["c3_left_cm"]
        record("prototype_a4", [p["a3"][0] - a4_left_cm, p["a3"][1]],
               "horizontal_left(a3,armhole_drafting_constants.a4_left_cm)", ["a3"])
        record("prototype_a5", intersection(
            p["prototype_a4"], [p["prototype_a4"][0] + 1.0, p["prototype_a4"][1]],
            p["k"], p["j"]),
            "horizontal(prototype_a4) intersect line(k,j)", ["prototype_a4", "k", "j"])
        record("a1", [p["i"][0], p["i"][1] - O / 3.0],
               "vertical_down(i,O/3)", ["i", "O"])
        delta = distance(p["r"], p["s"])
        record("w", on_ray(p["v"], p["a1"], delta - 0.7),
               "distance_on_ray(v,a1,distance(r,s)-0.7)", ["v", "a1", "r", "s"])
        record("a6", midpoint(p["w"], p["prototype_a4"]),
               "midpoint(w,prototype_a4)", ["w", "prototype_a4"])
        a7_candidates = normal_candidates(
            p["a6"], p["w"], p["prototype_a4"], a7_normal_cm
        )
        left_a7 = [candidate for candidate in a7_candidates if candidate[0] < p["a6"][0]]
        if len(left_a7) != 1:
            raise ValueError("prototype_a7 left-side normal candidate is not unique")
        record("prototype_a7", left_a7[0],
               "perpendicular_offset(a6,line(w,prototype_a4),armhole_drafting_constants.a7_normal_cm,side=x<a6.x)",
               ["a6", "w", "prototype_a4"])

        record("b1", midpoint(p["a3"], p["h"]), "midpoint(a3,h)", ["a3", "h"])
        L_b1h = distance(p["b1"], p["h"])
        record("b2", [p["h"][0] + L_b1h, p["h"][1]],
               "horizontal_right(h,distance(b1,h))", ["b1", "h"])
        record("b3", [p["h"][0] + 2.0 * L_b1h, p["h"][1]],
               "horizontal_right(h,2*distance(b1,h))", ["b1", "h"])
        record("b4", midpoint(p["c"], p["e"]), "midpoint(c,e)", ["c", "e"])
        record("b5", intersection(
            p["b4"], [p["b4"][0], p["b4"][1] - 1.0], p["f"], p["g"]),
            "vertical(b4) intersect line(f,g)", ["b4", "f", "g"])
        record("prototype_c1", midpoint(p["b3"], p["b5"]),
               "midpoint(b3,b5)", ["b3", "b5"])
        record("prototype_c4", _lerp(p["b5"], p["prototype_a5"], 1.0 / 3.0),
               "point_on_segment(b5,prototype_a5,t=1/3)", ["b5", "prototype_a5"])
        c5_candidates = normal_candidates(
            p["prototype_c4"], p["b5"], p["prototype_a5"], c5_normal_cm)
        down_c5 = [candidate for candidate in c5_candidates if candidate[1] < p["prototype_c4"][1]]
        if len(down_c5) != 1:
            raise ValueError("prototype_c5 downward normal candidate is not unique")
        record("prototype_c5", down_c5[0],
               "perpendicular_offset(prototype_c4,line(b5,prototype_a5),armhole_drafting_constants.c5_normal_cm,side=down)",
               ["prototype_c4", "b5", "prototype_a5"])
        record("c2", midpoint(p["k"], p["j"]), "midpoint(k,j)", ["k", "j"])
        record("c3", [p["c2"][0] - c3_left_cm, p["c2"][1]],
               "horizontal_left(c2,armhole_drafting_constants.c3_left_cm)", ["c2"])
        # q and s are re-recorded here to attach explicit formula provenance.
        record("q", [p["k"][0], p["k"][1] - (O / 2.0 - 0.5)],
               "vertical_down(k,O/2-0.5)", ["k", "O"])
        record("s", [p["q"][0] - 2.0, p["q"][1]],
               "horizontal_left(q,2.0)", ["q"])
        record("m2", [p["d"][0] + 1.0, p["d"][1]],
               "horizontal_right(d,1.0)", ["d"], stage="suit_length_construction")
        garment_length = float(garment_length_ratio) * float(self.back_length) - 1.0
        record("m3", [p["m2"][0], p["m2"][1] - garment_length],
               "vertical_down(m2,garment_length_ratio*back_length-1)",
               ["m2", "garment_length_ratio", "back_length"],
               stage="suit_length_construction")

        def unit(vec):
            norm = math.hypot(vec[0], vec[1])
            if norm < 1.0e-12:
                raise ValueError("zero-length prototype curve tangent")
            return [vec[0] / norm, vec[1] / norm]

        def sub(a, b):
            return [a[0] - b[0], a[1] - b[1]]

        def add_scaled(a, b, scale):
            return [a[0] + scale * b[0], a[1] + scale * b[1]]

        def cubic_controls(p0, p1, t0, t1):
            return add_scaled(p0, t0, 1.0 / 3.0), add_scaled(p1, t1, -1.0 / 3.0)

        # Selected result of the reproducible BASE constrained fit. Shape
        # controls actively participate in candidate selection; the resulting
        # values remain B4 candidates, not confirmed drafting constants.
        ws_fit = (
            evaluate_selected_formal_ws_base(p)
            if ws_shape_values is None
            else evaluate_formal_ws_values(p, ws_shape_values)
        )
        p.update({name: list(value) for name, value in ws_fit["points"].items()})
        normalized_local_shape = dict(ws_fit["values"])
        prototype_curve = [dict(edge, formal=True) for edge in ws_fit["edges"]]

        def eval_curve(record_curve, t):
            p0, p1 = p[record_curve["p0"]], p[record_curve["p1"]]
            c1, c2 = record_curve["c1"], record_curve["c2"]
            u = 1.0 - t
            return [u**3*p0[0] + 3*u*u*t*c1[0] + 3*u*t*t*c2[0] + t**3*p1[0], u**3*p0[1] + 3*u*u*t*c1[1] + 3*u*t*t*c2[1] + t**3*p1[1]]

        def nearest_curve_distance(point):
            best = None
            for si, record_curve in enumerate(prototype_curve):
                for j in range(101):
                    t = j / 100.0
                    candidate = eval_curve(record_curve, t)
                    hit = (distance(point, candidate), si, t, candidate)
                    if best is None or hit[0] < best[0]:
                        best = hit
            return best

        shape_diagnostics = {
            name: dict(row, required_pass_through=False, curve_shape_control=True)
            for name, row in ws_fit["shape_controls"].items()
        }

        branch_candidates = prototype_curve[2:]
        target_y = p["prototype_a5"][1]
        roots = []
        for branch_index, branch in enumerate(branch_candidates, start=2):
            prev_t, prev = 0.0, eval_curve(branch, 0.0)
            for j in range(1, 1001):
                t = j / 1000.0
                cur = eval_curve(branch, t)
                if (prev[1] - target_y) * (cur[1] - target_y) <= 0.0 and abs(cur[1] - prev[1]) > 1.0e-12:
                    roots.append((branch_index, prev_t + (t - prev_t) * (target_y - prev[1]) / (cur[1] - prev[1])))
                prev_t, prev = t, cur
        if len(roots) != 1:
            raise ValueError("PROTOTYPE_M1_INTERSECTION_NOT_UNIQUE")
        prototype_m1 = eval_curve(prototype_curve[roots[0][0]], roots[0][1])
        record("prototype_m1", prototype_m1, "horizontal(prototype_a5) intersect s_side_branch(w_to_s)", ["prototype_a5", "prototype_c5", "w", "s"])

        audited_names = tuple(formulas)
        point_records = {
            name: {
                "stage": stages[name],
                "provenance": provenance[name],
                "formula": formulas[name],
                "upstream_dependencies": upstream[name],
                "base_coordinate": list(p[name]),
                "depends_on_frozen_coordinate": False,
            }
            for name in audited_names
        }
        curve_audit = {
            "composite_curve": "prototype_w_to_s",
            "semantic_endpoints": ["w", "s"],
            "required_pass_through": ["prototype_c1"],
            "not_required_pass_through": ["b1", "prototype_a7", "prototype_a4", "prototype_c5", "c3"],
            "tangent_constraints": [
                {"point": "tau_b1b2", "parallel_to_line": ["b1", "b2"]},
                {"point": "prototype_c1", "parallel_to_line": ["b3", "b5"]},
            ],
            "shape_control_points": ["prototype_a7", "prototype_a4", "prototype_c5", "c3"],
            "shape_control_points_are_pass_through": False,
            "topological_break_at_shape_points": False,
            "formal_geometric_constraints_complete": True,
            "remaining_curvature_source": "baseline_local_shape",
            "historical_absolute_controls_are_dynamic_rule": False,
            "historical_source": "mens_bodice_B88_revised_background.json",
            "historical_normalized_local_shape_extracted": False,
            "normalized_local_shape_source": "BASE_B4_LOCAL_SHAPE_SELECTION",
            "base_local_shape_selection": "formal constraints plus convexity and smoothness; historical curve conflicts with tangent rule",
            "base_local_shape_is_confirmed_drafting_constant": False,
            "base_local_shape_recalibration_allowed": True,
            "normalized_local_shape": normalized_local_shape,
            "c1_tangent_angular_error_deg": 0.0,
            "c1_g1_angular_error_deg": 0.0,
            "tau_tangent_angular_error_deg": 0.0,
            "tau_g1_angular_error_deg": 0.0,
            "ws_pass_through_b1_required": False,
            "b1_distance_to_curve_cm": nearest_curve_distance(p["b1"])[0],
            "segments": [
                {"p0": edge["p0"], "p1": edge["p1"], "topological_break": False}
                for edge in prototype_curve
            ],
            "shape_diagnostics": shape_diagnostics,
            "prototype_curve": prototype_curve,
            "mathematical_knot_points": {
                name: list(p[name]) for name in ("tau_b1b2", "ws_kappa_s_side")
            },
            "prototype_m1": {"branch": [prototype_curve[roots[0][0]]["p0"], prototype_curve[roots[0][0]]["p1"]], "segment_index": roots[0][0], "parameter": roots[0][1], "point": prototype_m1, "unique_intersection": True},
            "shape_controls_actively_used": True,
            "max_armhole_side_seam_overshoot_cm": ws_fit["max_armhole_side_seam_overshoot_cm"],
            "curvature_max_cm_inv": ws_fit["curvature_max_cm_inv"],
        }
        diagnostics = {
            "a3_formal_rule_corrected": True,
            "a3_3_4_assertion_pass": True,
            "a3h_1_4_assertion_pass": True,
            "a3_partition_assertion_pass": True,
            "a3_ratio_assertion_tolerance_cm": ratio_tolerance,
            "a3_a4_a5_same_height_pass": (
                math.isclose(p["a3"][1], p["prototype_a4"][1], rel_tol=0.0, abs_tol=ratio_tolerance)
                and math.isclose(p["prototype_a4"][1], p["prototype_a5"][1], rel_tol=0.0, abs_tol=ratio_tolerance)
            ),
            "prototype_a4_historical_alignment_classification": "SAME_DRAFTING_GEOMETRY",
            "prototype_c5_historical_alignment_classification": "SAME_DRAFTING_GEOMETRY",
            "prototype_construction_unresolved": [],
            "prototype_m1_rule": "horizontal(prototype_a5) intersect dynamic_prototype_curve(w,s)",
            "prototype_m1_status": "unique_s_side_branch_intersection",
            "prototype_m1": prototype_m1,
            "prototype_curve_shape_diagnostics": shape_diagnostics,
            "prototype_curve_intersection_root": roots[0],
            "historical_curve_conflict": "HISTORICAL_CURVE_CONFLICT_WITH_FORMAL_RULE",
            "intended_formal_rule_corrections": ["prototype_a5", "prototype_a7"],
            "frozen_coordinate_dependency_count": 0,
        }
        return PrototypeConstructionResult(
            points=p,
            point_records=point_records,
            derived_quantities={
                "depth": depth, "delta": delta, "L_b1h": L_b1h,
                "ia3_cm": ia3, "a3h_cm": a3h, "ih_cm": ih,
                "ia3_ratio": 0.75, "a3h_ratio": 0.25,
                "garment_length_ratio": float(garment_length_ratio),
                "garment_length_cm": garment_length,
            },
            diagnostics=diagnostics,
            curve_audit=curve_audit,
        )

    def back_points(self):
        """
        Named back-half drafting points.

        Coordinate convention:
        - x=0 is center back.
        - +x goes toward side seam.
        - y=0 is waist/base line.
        - +y goes upward.
        """
        d = self

        cb_waist = [0.0, 0.0]
        side_waist = [d.panel_width, 0.0]
        underarm = [d.panel_width, d.underarm_y]

        neck_side = [d.neck_width, d.back_length]
        neck_center = [0.0, d.back_length + d.back_neck_rise]

        # Third-gen source explicitly retains a 2 cm shoulder push
        # while revising the back shoulder drop.
        nominal_shoulder_x = d.chest_back_guide + d.shoulder_push_back
        shoulder = [
            nominal_shoulder_x,
            d.back_length - d.back_shoulder_drop
        ]

        arm_break = _lerp(underarm, shoulder, 0.48)

        # Third-gen inherits 0.7 cm upper back-armhole adjustment.
        upper_target = _offset_x(
            arm_break, shoulder, 0.52, +d.back_armhole_upper_out
        )

        # Third-gen changes the lower back armhole local adjustment to 0.3 cm.
        lower_target = _offset_x(
            underarm, arm_break, 0.32, -d.back_armhole_lower_in
        )

        return {
            "cb_waist": cb_waist,
            "side_waist": side_waist,
            "underarm": underarm,
            "arm_break": arm_break,
            "arm_lower_target": lower_target,
            "arm_upper_target": upper_target,
            "shoulder": shoulder,
            "neck_side": neck_side,
            "neck_center": neck_center,
        }


class MensThirdGenFrontPanel(pyg.Panel):
    """Front half of the third-generation men's standard basic block."""

    def __init__(self, name, draft: ThirdGenDraft):
        super().__init__(name)
        p = draft.front_points()

        bottom = pyg.Edge(p["cf_waist"], p["side_waist"])
        side = pyg.Edge(bottom.end, p["underarm"])

        arm_lower = _curve3(
            side.end,
            p["arm_break"],
            p["arm_lower_target"],
        )
        arm_upper = _curve3(
            arm_lower.end,
            p["shoulder"],
            p["arm_upper_target"],
        )

        shoulder = pyg.Edge(arm_upper.end, p["neck_side"])
        # Neckline endpoints are source-defined, but the printed drafting
        # figure does not uniquely determine a pass-through Bezier point.
        # Use GarmentCodeRC's native relative quadratic control point instead.
        neckline = pyg.CurveEdge(
            shoulder.end,
            p["neck_center"],
            control_points=[[0.5, draft.neckline_rel_control_y]],
            relative=True,
        )
        center_front = pyg.Edge(neckline.end, bottom.start)

        self.edges.append(
            pyg.EdgeSequence(
                bottom, side, arm_lower, arm_upper,
                shoulder, neckline, center_front
            )
        )

        self.interfaces = {
            "bottom": pyg.Interface(self, bottom),
            "side": pyg.Interface(self, side),
            "armhole": pyg.Interface(
                self, pyg.EdgeSequence(arm_lower, arm_upper)
            ),
            "shoulder": pyg.Interface(self, shoulder),
            "neckline": pyg.Interface(self, neckline),
            "center_front": pyg.Interface(self, center_front),
        }

        self.draft_points = p
        self.draft = draft


class MensThirdGenBackPanel(pyg.Panel):
    """Back half of the third-generation men's standard basic block."""

    def __init__(self, name, draft: ThirdGenDraft):
        super().__init__(name)
        p = draft.back_points()

        bottom = pyg.Edge(p["cb_waist"], p["side_waist"])
        side = pyg.Edge(bottom.end, p["underarm"])

        arm_lower = _curve3(
            side.end,
            p["arm_break"],
            p["arm_lower_target"],
        )
        arm_upper = _curve3(
            arm_lower.end,
            p["shoulder"],
            p["arm_upper_target"],
        )

        shoulder = pyg.Edge(arm_upper.end, p["neck_side"])
        # Neckline endpoints are source-defined, but the printed drafting
        # figure does not uniquely determine a pass-through Bezier point.
        # Use GarmentCodeRC's native relative quadratic control point instead.
        neckline = pyg.CurveEdge(
            shoulder.end,
            p["neck_center"],
            control_points=[[0.5, draft.neckline_rel_control_y]],
            relative=True,
        )
        center_back = pyg.Edge(neckline.end, bottom.start)

        self.edges.append(
            pyg.EdgeSequence(
                bottom, side, arm_lower, arm_upper,
                shoulder, neckline, center_back
            )
        )

        self.interfaces = {
            "bottom": pyg.Interface(self, bottom),
            "side": pyg.Interface(self, side),
            "armhole": pyg.Interface(
                self, pyg.EdgeSequence(arm_lower, arm_upper)
            ),
            "shoulder": pyg.Interface(self, shoulder),
            "neckline": pyg.Interface(self, neckline),
            "center_back": pyg.Interface(self, center_back),
        }

        self.draft_points = p
        self.draft = draft


class MensThirdGenBasicBlock(pyg.Component):
    """
    Top-level GarmentCodeRC component.

    It intentionally outputs only the two half-block pattern panels shown in
    the textbook (front half + back half). This makes it suitable as a
    drafting base for later four-panel/six-panel suit construction.

    It does NOT create a closed 3D garment.
    """

    def __init__(self, body, design):
        super().__init__(self.__class__.__name__)

        self.draft = ThirdGenDraft.from_body_design(body, design)

        self.front = MensThirdGenFrontPanel(
            "mens_3g_front", self.draft
        )
        self.back = MensThirdGenBackPanel(
            "mens_3g_back", self.draft
        )

        # Separate the panels in 3D metadata only; printable 2D generation
        # still uses their local coordinates.
        self.front.translate_by([0, 0, 20])
        self.back.translate_by([0, 0, -20])

        # No stitching by default:
        # this class represents a drafting block, not a finished garment.
        self.interfaces = {
            "front_side": self.front.interfaces["side"],
            "back_side": self.back.interfaces["side"],
            "front_shoulder": self.front.interfaces["shoulder"],
            "back_shoulder": self.back.interfaces["shoulder"],
            "front_armhole": self.front.interfaces["armhole"],
            "back_armhole": self.back.interfaces["armhole"],
            "front_neckline": self.front.interfaces["neckline"],
            "back_neckline": self.back.interfaces["neckline"],
        }

    def length(self):
        return self.draft.back_length
