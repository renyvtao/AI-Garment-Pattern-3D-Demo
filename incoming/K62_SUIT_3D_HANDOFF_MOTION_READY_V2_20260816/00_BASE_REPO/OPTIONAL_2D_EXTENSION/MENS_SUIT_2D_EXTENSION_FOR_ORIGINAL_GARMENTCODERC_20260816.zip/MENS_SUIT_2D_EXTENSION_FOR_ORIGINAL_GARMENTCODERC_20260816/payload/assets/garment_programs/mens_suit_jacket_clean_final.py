# -*- coding: utf-8 -*-
r"""MetaGarment-compatible upper component for the canonical CLEAN final suit."""
import pygarment as pyg

from assets.garment_programs.suit_stage_clean_final_2d import (
    build_mens_suit_clean_final_2d,
)


class MensSuitJacketCleanFinal(pyg.Component):
    def __init__(self, body, design):
        super().__init__("MensSuitJacketCleanFinal")
        self.clean_final_result = build_mens_suit_clean_final_2d(
            body,
            design,
            name="mens_suit_clean_final",
        )
        self.pattern = self.clean_final_result.pattern_component
        self.subs = [self.pattern]
        self.interfaces = {}

    def length(self):
        front = self.clean_final_result.base_a6_result.front_draft_result
        return float(front.derived_quantities["garment_length_cm"])
