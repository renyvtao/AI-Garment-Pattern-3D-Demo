"""BASE formal back adapter sharing the symmetric upper side-seam B4 shape."""
from __future__ import annotations

from copy import deepcopy

import pygarment as pyg

from assets.garment_programs.suit_curve_rules_v2 import (
    abs_cp_to_q, q_to_abs, reverse_record, split_curve_at_t,
)
from assets.garment_programs.suit_geometry import localize_points, make_edge
from assets.garment_programs.suit_pattern_data import BACK_EDGES, BACK_POINTS


def build_formal_back_geometry(formal_front_result):
    p = {name: list(value) for name, value in BACK_POINTS.items()}
    fp = formal_front_result.points
    p["m1"] = list(fp["m1"])
    p["m8"] = list(fp["m8"])
    p["t7"] = list(fp["t7"])

    # CLEAN current-formal integration.
    #
    # These points are current 2-D drafting results and must not silently
    # fall back to frozen BACK_POINTS when body/waist/garment-length inputs
    # change.
    #
    # Center-back boundary:
    #   n2 -> n1 -> g -> n3 -> m2
    #
    # Back neckline:
    #   m2 -> d -> p -> m
    #
    # Back shoulder:
    #   m -> s
    #
    # IMPORTANT:
    # p and m are construction points of the current men's prototype:
    #   l = d shifted left by O
    #   m = l shifted upward by O/3
    #   p = second trisection point of l-d
    # They must therefore follow the current formal/prototype geometry.
    # Leaving p/m in frozen BACK_POINTS mixes current d/s with historical
    # p/m and corrupts both the back-neckline and back-shoulder geometry.
    for name in ("n2", "n1", "g", "n3", "m2", "d", "p", "m"):
        if name in fp:
            p[name] = list(fp[name])
    ws = [deepcopy(edge) for edge in formal_front_result.ws_edges]
    for edge in ws:
        for name in (edge["p0"], edge["p1"]):
            if name in fp:
                p[name] = list(fp[name])
    m1_index = formal_front_result.diagnostics["m1_curve_segment"]
    _, remainder = split_curve_at_t(
        ws[m1_index], p, formal_front_result.diagnostics["m1_curve_t"], "m1"
    )
    m1_to_s = [remainder] + ws[m1_index + 1:]
    armhole = [reverse_record(edge) for edge in reversed(m1_to_s)]
    for edge in armhole:
        edge["source"] = "formal_ws_back_armhole"
        edge["semantic_group"] = "armhole"

    records = list(armhole)
    for template in BACK_EDGES[2:]:
        rec = {k: deepcopy(v) for k, v in template.items() if k not in ("c1", "c2")}
        if template.get("source") == "side_seam_bottom":
            rec["source"] = "formal_side_seam_lower_shared"
        if template.get("kind") == "curve":
            if template.get("source") == "side_seam_top":
                q1, q2 = [1.0 / 3.0, -0.03], [2.0 / 3.0, -0.03]
                rec["source"] = "formal_side_seam_upper_shared_B4"
            else:
                q1 = abs_cp_to_q(BACK_POINTS[rec["p0"]], BACK_POINTS[rec["p1"]], template["c1"])
                q2 = abs_cp_to_q(BACK_POINTS[rec["p0"]], BACK_POINTS[rec["p1"]], template["c2"])
            rec["c1"] = q_to_abs(p[rec["p0"]], p[rec["p1"]], q1)
            rec["c2"] = q_to_abs(p[rec["p0"]], p[rec["p1"]], q2)
        records.append(rec)
    return p, records, len(armhole)


class FormalSuitBackPanel(pyg.Panel):
    def __init__(self, name, formal_front_result):
        super().__init__(name)
        self.original_points, records, armhole_count = build_formal_back_geometry(formal_front_result)
        self.vertices = localize_points(self.original_points, "s")
        self.edges = pyg.EdgeSequence()
        built = []
        for record in records:
            edge = make_edge(self.vertices, record, self.original_points)
            self.edges.append(edge)
            built.append(edge)
        self.interfaces = {
            "armhole": pyg.Interface(self, pyg.EdgeSequence(*built[:armhole_count])),
            "side_seam": pyg.Interface(self, pyg.EdgeSequence(*built[armhole_count:armhole_count+2])),
            "hem": pyg.Interface(self, pyg.EdgeSequence(built[armhole_count+2])),
            "center_back": pyg.Interface(self, pyg.EdgeSequence(*built[armhole_count+3:armhole_count+7])),
            "neckline": pyg.Interface(self, pyg.EdgeSequence(*built[armhole_count+7:armhole_count+10])),
            "shoulder": pyg.Interface(self, pyg.EdgeSequence(built[armhole_count+10])),
        }
