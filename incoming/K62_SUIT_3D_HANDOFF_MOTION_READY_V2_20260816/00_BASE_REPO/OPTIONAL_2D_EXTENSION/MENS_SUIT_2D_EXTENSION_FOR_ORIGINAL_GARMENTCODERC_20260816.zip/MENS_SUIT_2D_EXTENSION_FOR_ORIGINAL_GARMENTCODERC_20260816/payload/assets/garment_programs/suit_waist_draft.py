"""Stage-A2 waist-ease drafting for the formal men's suit body.

This module is deliberately 2-D only.  It does not touch placement, Warp,
attachments, collar fold physics, or sleeve geometry.

Confirmed semantics
-------------------
- ``waist_ease_cm`` is full-circumference garment waist ease:
      finished garment waist - body net waist
- current half-body width before waist take-up:
      B / 2 + 10
- CLEAN rear-center construction:
      y1 = horizontal(e) intersect line(m2,m3)
      |n1-y1| = R_center + 1
      n2 = m3 shifted left by |n1-y1| + 1
      n3 = horizontal(c2) intersect line(m2,m3)
- half-body waist after shaping:
      B / 2 + 10
      - (|n1-y1| - 1)
      - |m7-m8|
      - |p8-p9|
      - |r1-r2|
- the accepted BASE take-ups are preserved as:
      back-center / back-side / front-side-princess / chest-waist dart
      = 1.5 / 4.0 / 1.5 / 1.0 cm
- the BASE itself is NOT required to satisfy 5:4:1.5:1.
- only the increase/decrease relative to that BASE is allocated by:
      delta back-center : delta back-side :
      delta front-side/princess : delta chest-waist dart
      = 5 : 4 : 1.5 : 1
- no hidden chest-dart cap or redistribution is applied.

Baseline compatibility
----------------------
``waist_ease_cm=None`` preserves the accepted BASE exactly.

For an explicit target ``waist_ease_cm``:
1. measure the BASE effective waist ease for the current body;
2. compute the required change in half-body total take-up;
3. add that signed change to the BASE four take-ups in the
   exact ratio 5:4:1.5:1.

Therefore the final four take-ups generally do NOT themselves have the
ratio 5:4:1.5:1; only their delta from BASE does.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import replace
import math

from assets.garment_programs.suit_curve_rules_v2 import q_to_abs


WAIST_EASE_RANGE_CM = (11.0, 19.0)
WAIST_RATIO = (5.0, 4.0, 1.5, 1.0)
BACK_CENTER_CONSTRUCTION_ALLOWANCE_CM = 1.0
BACK_CENTER_N2_EXTRA_CM = 1.0


def _body_value(body, key):
    try:
        return float(body[key])
    except (KeyError, TypeError) as exc:
        raise KeyError(f"Body is missing required measurement {key!r}") from exc


def _distance_x(points, a, b):
    return abs(float(points[b][0]) - float(points[a][0]))


def _line_intersection(a, b, c, d):
    ax, ay = map(float, a)
    bx, by = map(float, b)
    cx, cy = map(float, c)
    dx, dy = map(float, d)
    det = (ax - bx) * (cy - dy) - (ay - by) * (cx - dx)
    if abs(det) < 1.0e-12:
        raise ValueError("CLEAN_WAIST_CONSTRUCTION_LINES_PARALLEL")
    n1 = ax * by - ay * bx
    n2 = cx * dy - cy * dx
    return [
        (n1 * (cx - dx) - (ax - bx) * n2) / det,
        (n1 * (cy - dy) - (ay - by) * n2) / det,
    ]


def _derive_clean_back_center(points, rear_center_takeup_cm):
    """Return y1/n1/n2/n3 from the confirmed CLEAN construction."""
    p = points
    # m2 is a construction point one centimetre right of d.
    m2 = [float(p["d"][0]) + 1.0, float(p["d"][1])]
    y1 = _line_intersection(
        [0.0, float(p["e"][1])],
        [1.0, float(p["e"][1])],
        m2,
        p["m3"],
    )
    n1y1 = float(rear_center_takeup_cm) + BACK_CENTER_CONSTRUCTION_ALLOWANCE_CM
    n1 = [float(y1[0]) - n1y1, float(y1[1])]
    n2 = [
        float(p["m3"][0]) - (n1y1 + BACK_CENTER_N2_EXTRA_CM),
        float(p["m3"][1]),
    ]
    n3 = _line_intersection(
        [0.0, float(p["c2"][1])],
        [1.0, float(p["c2"][1])],
        m2,
        p["m3"],
    )
    return {
        "m2": m2,
        "y1": y1,
        "n1": n1,
        "n2": n2,
        "n3": n3,
        "n1y1_cm": n1y1,
        "rear_center_takeup_cm": float(rear_center_takeup_cm),
    }


def current_half_takeups(formal_result):
    """Measure the four current half-pattern waist reductions in centimetres.

    The CLEAN rear-center reduction is not |e-n1|.  It is:
        R_center = |n1-y1| - 1
    """
    p = formal_result.points
    if "y1" in p:
        y1 = p["y1"]
    else:
        y1 = _derive_clean_back_center(
            p,
            max(
                0.0,
                abs(float(p["e"][0]) - float(p["n1"][0])),
            ),
        )["y1"]

    back_center = (
        abs(float(p["n1"][0]) - float(y1[0]))
        - BACK_CENTER_CONSTRUCTION_ALLOWANCE_CM
    )
    if back_center < -1.0e-8:
        raise ValueError("CLEAN_BACK_CENTER_TAKEUP_NEGATIVE")

    values = {
        "back_center_cm": max(0.0, back_center),
        "back_side_cm": _distance_x(p, "m7", "m8"),
        "front_side_cm": _distance_x(p, "p8", "p9"),
        "chest_waist_dart_cm": _distance_x(p, "r1", "r2"),
    }
    values["total_half_takeup_cm"] = sum(values.values())
    values["back_center_n1y1_cm"] = (
        values["back_center_cm"] + BACK_CENTER_CONSTRUCTION_ALLOWANCE_CM
    )
    return values


def allocate_waist_takeup_delta(baseline_takeups, target_total_half_takeup_cm):
    """Apply only the BASE-relative take-up delta in the confirmed ratio.

    BASE:
        [back-center, back-side, front-side/princess, chest-waist dart]

    delta_total:
        target total half-body take-up - BASE total half-body take-up

    delta allocation:
        5 : 4 : 1.5 : 1

    The delta is signed:
    - positive delta_total -> more shaping / less waist ease;
    - negative delta_total -> less shaping / more waist ease.
    """
    keys = (
        "back_center_cm",
        "back_side_cm",
        "front_side_cm",
        "chest_waist_dart_cm",
    )
    base = [float(baseline_takeups[k]) for k in keys]
    base_total = sum(base)
    target_total = float(target_total_half_takeup_cm)
    delta_total = target_total - base_total

    weights = WAIST_RATIO
    weight_sum = sum(weights)
    deltas = [delta_total * w / weight_sum for w in weights]
    values = [b + d for b, d in zip(base, deltas)]

    if min(values) < -1.0e-9:
        raise ValueError(
            "WAIST_DELTA_RATIO_WOULD_CREATE_NEGATIVE_TAKEUP"
        )
    values = [max(0.0, v) for v in values]

    return {
        "back_center_cm": values[0],
        "back_side_cm": values[1],
        "front_side_cm": values[2],
        "chest_waist_dart_cm": values[3],
        "total_half_takeup_cm": sum(values),
        "baseline_takeups_cm": {
            k: float(baseline_takeups[k]) for k in keys
        },
        "baseline_total_half_takeup_cm": base_total,
        "target_total_half_takeup_cm": target_total,
        "delta_total_half_takeup_cm": delta_total,
        "delta_takeups_cm": {
            "back_center_cm": deltas[0],
            "back_side_cm": deltas[1],
            "front_side_cm": deltas[2],
            "chest_waist_dart_cm": deltas[3],
        },
        "delta_ratio": list(WAIST_RATIO),
        "delta_ratio_is_exact": True,
        "final_takeups_are_not_required_to_match_ratio": True,
        "hidden_cap_or_redistribution": False,
    }


def _rebuild_formal_edges(points, boundary_edges, internal_edges):
    """Rebuild only edges whose endpoints moved under waist shaping."""
    boundary = deepcopy(boundary_edges)
    internal = deepcopy(internal_edges)

    # The formal upper side seam is a local-q curve and therefore keeps the
    # frozen local shape while m7 moves.
    for rec in boundary:
        if rec.get("source") == "formal_side_seam_upper_shared_B4":
            q1 = [1.0 / 3.0, 0.03]
            q2 = [2.0 / 3.0, 0.03]
            rec["c1"] = q_to_abs(points["m1"], points["m7"], q1)
            rec["c2"] = q_to_abs(points["m1"], points["m7"], q2)

    # Side-dart and chest-waist-dart records are straight in the formal V0
    # result, so moving their endpoints is sufficient.
    return boundary, internal


def apply_waist_ease(formal_result, third_gen_draft, body, waist_ease_cm=None):
    """Return a new FormalSuitFrontV0Result with waist geometry applied.

    ``None`` preserves the current frozen BASE waist geometry and only reports
    its effective full-circumference waist ease for the current body.
    """
    body_waist = _body_value(body, "waist")
    B = float(third_gen_draft.B)
    basic_half = B / 2.0 + 10.0
    baseline = current_half_takeups(formal_result)

    baseline_finished_half = basic_half - baseline["total_half_takeup_cm"]
    baseline_finished_full = 2.0 * baseline_finished_half
    baseline_effective_ease = baseline_finished_full - body_waist

    if waist_ease_cm is None:
        diagnostics = deepcopy(formal_result.diagnostics)
        derived = deepcopy(formal_result.derived_quantities)
        diagnostics["waist_parameterization"] = {
            "mode": "FROZEN_BASE_PRESERVED",
            "requested_waist_ease_cm": None,
            "effective_baseline_waist_ease_cm": baseline_effective_ease,
            "confirmed_delta_ratio": list(WAIST_RATIO),
            "base_takeups_are_not_required_to_match_ratio": True,
            "clean_back_center_rule_present": "y1" in formal_result.points,
            "baseline_back_center_n1y1_cm": baseline.get(
                "back_center_n1y1_cm"
            ),
            "note": (
                "Null preserves the accepted BASE geometry.  For an explicit "
                "numeric waist_ease_cm, only the signed change from BASE is "
                "distributed by 5:4:1.5:1."
            ),
        }
        derived.update({
            "basic_half_girth_width_cm": basic_half,
            "finished_half_waist_cm": baseline_finished_half,
            "finished_garment_waist_cm": baseline_finished_full,
            "effective_waist_ease_cm": baseline_effective_ease,
            "waist_takeups_cm": deepcopy(baseline),
        })
        return replace(formal_result, diagnostics=diagnostics, derived_quantities=derived)

    ease = float(waist_ease_cm)
    low, high = WAIST_EASE_RANGE_CM
    if not low <= ease <= high:
        raise ValueError(f"waist_ease_cm outside confirmed range [{low}, {high}]")

    target_finished_full = body_waist + ease
    target_finished_half = target_finished_full / 2.0
    total_half_takeup = basic_half - target_finished_half
    allocation = allocate_waist_takeup_delta(
        baseline,
        total_half_takeup,
    )

    p = deepcopy(formal_result.points)

    # 1) CLEAN back-center construction.
    #    y1 = horizontal(e) intersect line(m2,m3)
    #    |n1-y1| = R_center + 1
    #    n2 = m3 left by |n1-y1| + 1
    #    n3 = horizontal(c2) intersect line(m2,m3)
    clean_back = _derive_clean_back_center(
        p,
        allocation["back_center_cm"],
    )
    for name in ("m2", "y1", "n1", "n2", "n3"):
        p[name] = list(clean_back[name])

    # 2) Back-side reduction: symmetric about m6.
    half_back_side = allocation["back_side_cm"] / 2.0
    p["m7"] = [p["m6"][0] - half_back_side, p["m6"][1]]
    p["m8"] = [p["m6"][0] + half_back_side, p["m6"][1]]

    # 3) Front-side reduction: retain confirmed 2/3 : 1/3 placement about p7.
    front_side = allocation["front_side_cm"]
    p["p8"] = [p["p7"][0] - (2.0 / 3.0) * front_side, p["p7"][1]]
    p["p9"] = [p["p7"][0] + (1.0 / 3.0) * front_side, p["p7"][1]]

    # 4) Chest-waist dart: symmetric about q7.
    half_chest = allocation["chest_waist_dart_cm"] / 2.0
    p["r1"] = [p["q7"][0] - half_chest, p["q7"][1]]
    p["r2"] = [p["q7"][0] + half_chest, p["q7"][1]]

    boundary, internal = _rebuild_formal_edges(
        p, formal_result.boundary_edges, formal_result.internal_edges
    )

    diagnostics = deepcopy(formal_result.diagnostics)
    derived = deepcopy(formal_result.derived_quantities)
    diagnostics["waist_parameterization"] = {
        "mode": "BASE_DELTA_RATIO_APPLIED",
        "requested_waist_ease_cm": ease,
        "effective_baseline_waist_ease_cm": baseline_effective_ease,
        "confirmed_delta_ratio": list(WAIST_RATIO),
        "delta_ratio_is_exact": True,
        "final_takeups_are_not_required_to_match_ratio": True,
        "hidden_cap_or_redistribution": False,
        "back_center_construction": {
            "y1": list(p["y1"]),
            "n1y1_cm": clean_back["n1y1_cm"],
            "rear_center_takeup_cm": clean_back["rear_center_takeup_cm"],
            "rule": (
                "y1=horizontal(e)∩line(m2,m3); "
                "|n1y1|=R_center+1; "
                "n2=m3-left(|n1y1|+1); "
                "n3=horizontal(c2)∩line(m2,m3)"
            ),
        },
        "baseline_takeups_cm": baseline,
        "target_takeups_cm": deepcopy(allocation),
        "delta_total_half_takeup_cm": allocation[
            "delta_total_half_takeup_cm"
        ],
        "delta_takeups_cm": deepcopy(allocation["delta_takeups_cm"]),
    }
    derived.update({
        "basic_half_girth_width_cm": basic_half,
        "finished_half_waist_cm": target_finished_half,
        "finished_garment_waist_cm": target_finished_full,
        "effective_waist_ease_cm": ease,
        "waist_takeups_cm": deepcopy(allocation),
    })

    return replace(
        formal_result,
        points=p,
        boundary_edges=boundary,
        internal_edges=internal,
        diagnostics=diagnostics,
        derived_quantities=derived,
    )
