"""
Frozen geometry exported from the previously adjusted mens_sleeve_v8_curve_params.json.

Semantic main vertices:
    big sleeve   : ['e1', 'd3', 'j1', 'j2', 'f3']
    small sleeve : ['k5', 'c2', 'j1', 'k6']

All other named points used by the boundary are retained as internal
curve knots so the adjusted curve shape is preserved as a piecewise-cubic
GarmentCodeRC panel.
"""

METRICS = {
    "arm_length": 55.032,
    "S": 54.532,
    "AH": 49.425,
    "BF": 19.179,
    "CW": 14.0,
    "D": 3.020833333333333,
    "armhole_offset": 3.5,
}

POINTS = {
    "b1": [18.666666666666664, -21.145833333333332],
    "c2": [35.333333333333336, -12.083333333333332],
    "d3": [37.846044152884446, -12.083333333333332],
    "e1": [30.270244298664444, -7.691552414386688],
    "f1": [22.96151103822111, -12.083333333333332],
    "f2": [26.100817971649107, -9.030288565267437],
    "f3": [15.645833333333332, -24.166666666666664],
    "h2": [34.559675762944075, -9.022303510968536],
    "h5": [17.145833333333332, -33.9888],
    "h6": [23.187499999999996, -33.9888],
    "h7": [15.645833333333332, -62.508903774500766],
    "h8": [21.687499999999996, -24.166666666666664],
    "h9": [21.608279021945737, -63.264549323414194],
    "j1": [31.175740940061175, -65.15678826425327],
    "j2": [15.619572389971497, -63.008213661098004],
    "j3": [36.32740367131309, -24.166666666666664],
    "k4": [30.151312017474424, -21.075475534798358],
    "k5": [21.566727179888595, -23.37583550521541],
    "k6": [21.617667676533777, -63.83665384921481],
    "k7": [38.34129256020198, -24.166666666666664],
    "k8": [37.606841032307514, -33.9888],
    "k9": [36.34989658786307, -33.9888],
}

SEGMENTS = {
    "big_top_f3_b1": {
        "label": "大袖上缘 f3→b1", "p0": "f3", "p1": "b1",
        "piece": "big", "bulge": -0.4694814797208724,
    },
    "big_top_b1_f1": {
        "label": "大袖上缘 b1→f1", "p0": "b1", "p1": "f1",
        "piece": "big", "bulge": -0.10052399777149268,
    },
    "big_top_f1_f2": {
        "label": "大袖上缘 f1→f2", "p0": "f1", "p1": "f2",
        "piece": "big", "bulge": 0.14586081115742777,
    },
    "big_top_f2_e1": {
        "label": "大袖上缘 f2→e1", "p0": "f2", "p1": "e1",
        "piece": "big", "bulge": 0.5023788149610553,
    },
    "big_top_e1_h2": {
        "label": "大袖上缘 e1→h2", "p0": "e1", "p1": "h2",
        "piece": "big", "bulge": 0.3273483115055907,
    },
    "big_top_h2_d3": {
        "label": "大袖上缘 h2→d3", "p0": "h2", "p1": "d3",
        "piece": "big", "bulge": 0.1429847093552879,
    },
    "big_right_d3_k7": {
        "label": "大袖右侧 d3→k7", "p0": "d3", "p1": "k7",
        "piece": "big", "bulge": 0.29019457853004327,
    },
    "big_right_k7_k8": {
        "label": "大袖右侧 k7→k8", "p0": "k7", "p1": "k8",
        "piece": "big", "bulge": 0.19842591282223354,
    },
    "big_right_k8_j1": {
        "label": "大袖右侧 k8→j1", "p0": "k8", "p1": "j1",
        "piece": "big", "bulge": 1.1409636868379418,
    },
    "big_left_j2_h7": {
        "label": "大袖左侧 j2→h7", "p0": "j2", "p1": "h7",
        "piece": "big", "bulge": 2.8765792517182827e-15,
    },
    "big_left_h7_h5": {
        "label": "大袖左侧 h7→h5", "p0": "h7", "p1": "h5",
        "piece": "big", "bulge": -0.1476791531680554,
    },
    "big_left_h5_f3": {
        "label": "大袖左侧 h5→f3", "p0": "h5", "p1": "f3",
        "piece": "big", "bulge": -0.4244808429485441,
    },
    "small_top_k5_k4": {
        "label": "小袖上缘 k5→k4", "p0": "k5", "p1": "k4",
        "piece": "small", "bulge": -1.6370132761724594,
    },
    "small_top_k4_c2": {
        "label": "小袖上缘 k4→c2", "p0": "k4", "p1": "c2",
        "piece": "small", "bulge": -1.1991865134518371,
    },
    "small_right_c2_j3": {
        "label": "小袖右侧 c2→j3", "p0": "c2", "p1": "j3",
        "piece": "small", "bulge": 0.2998350641345811,
    },
    "small_right_j3_k9": {
        "label": "小袖右侧 j3→k9", "p0": "j3", "p1": "k9",
        "piece": "small", "bulge": 0.17727699928640456,
    },
    "small_right_k9_j1": {
        "label": "小袖右侧 k9→j1", "p0": "k9", "p1": "j1",
        "piece": "small", "bulge": 1.2109582936204109,
    },
    "small_outer_k6_h9": {
        "label": "小袖外侧 k6→h9", "p0": "k6", "p1": "h9",
        "piece": "small", "bulge": 0.0,
    },
    "small_outer_h9_h6": {
        "label": "小袖外侧 h9→h6", "p0": "h9", "p1": "h6",
        "piece": "small", "bulge": 0.0,
    },
    "small_outer_h6_h8": {
        "label": "小袖外侧 h6→h8", "p0": "h6", "p1": "h8",
        "piece": "small", "bulge": -0.4244808429485434,
    },
    "small_outer_h8_k5": {
        "label": "小袖外侧 h8→k5", "p0": "h8", "p1": "k5",
        "piece": "small", "bulge": 5.497841793358103e-16,
    },
    "bottom_j1_j2": {
        "label": "下口曲线 j1→j2", "p0": "j1", "p1": "j2",
        "piece": "bottom", "bulge": -0.8,
    },
}

BIG_MAIN_VERTICES = ["e1", "d3", "j1", "j2", "f3"]
BIG_AUX_POINTS = ["b1", "f1", "f2", "h2", "h5", "h7", "k7", "k8"]
SMALL_MAIN_VERTICES = ["k5", "c2", "j1", "k6"]
SMALL_AUX_POINTS = ["h6", "h8", "h9", "j3", "k4", "k9"]

BIG_BOUNDARY_GROUPS = [
    ("cap_e1_d3", ["big_top_e1_h2", "big_top_h2_d3"]),
    ("seam_d3_j1", ["big_right_d3_k7", "big_right_k7_k8", "big_right_k8_j1"]),
    ("cuff_j1_j2", ["bottom_j1_j2"]),
    ("seam_j2_f3", ["big_left_j2_h7", "big_left_h7_h5", "big_left_h5_f3"]),
    ("cap_f3_e1", ["big_top_f3_b1", "big_top_b1_f1", "big_top_f1_f2", "big_top_f2_e1"]),
]

SMALL_BOUNDARY_GROUPS = [
    ("cap_k5_c2", ["small_top_k5_k4", "small_top_k4_c2"]),
    ("seam_c2_j1", ["small_right_c2_j3", "small_right_j3_k9", "small_right_k9_j1"]),
    ("cuff_j1_k6", ["small_cuff_j1_k6"]),
    ("seam_k6_k5", ["small_outer_k6_h9", "small_outer_h9_h6", "small_outer_h6_h8", "small_outer_h8_k5"]),
]
