# -*- coding: utf-8 -*-
r"""Decorative button semantics for the CLEAN men's suit.

This module does not create real closure.
It only records:
- decorative button positions for rendering / preview;
- closure-pair semantics for later 3-D engineering.
"""
from __future__ import annotations

from copy import deepcopy
import pygarment as pyg


def _leaf(value):
    if isinstance(value, dict) and "v" in value:
        return value["v"]
    return value


class SuitButtonComponent(pyg.Component):
    def __init__(self, name, front_component, suit_params):
        super().__init__(name)
        self.subs = []
        self.interfaces = {}
        self.front_component = front_component
        self.suit_params = deepcopy(suit_params)
        self.render_buttons = bool(_leaf(suit_params.get("render_buttons", True)))

        owner = getattr(front_component, "center", front_component)
        button_info = deepcopy(owner.internal_features.get("drafting_buttons", {}))
        active_count = int(button_info.get("active_count", int(_leaf(suit_params.get("button_count", 2)))))
        spacing_cm = float(_leaf(suit_params.get("button_spacing_cm", 10.0)))
        if active_count not in (1, 2):
            raise ValueError("button_count must be 1 or 2")

        draft = getattr(owner, "front_draft_result", None)
        draft_points = getattr(draft, "points", {}) or {}
        derived = getattr(draft, "derived_quantities", {}) or {}
        if active_count == 1:
            if "r3" not in draft_points:
                raise ValueError("ONE_BUTTON_R3_SEMANTIC_MISSING")
            resolved = {"button_1": list(draft_points["r3"])}
            button_authority = {"button_1": "CURRENT_FRONT_DRAFT_R3"}
        else:
            resolved = {
                "button_1": list(derived.get("first_button_drafting_point", button_info.get("button_1", []))),
                "button_2": list(derived.get("second_button_drafting_point", button_info.get("button_2", []))),
            }
            if not resolved["button_1"] or not resolved["button_2"]:
                raise ValueError("TWO_BUTTON_CURRENT_DRAFTING_SEMANTICS_MISSING")
            button_authority = {
                "button_1": "CURRENT_FIRST_BUTTON_DRAFTING_POINT",
                "button_2": "CURRENT_SECOND_BUTTON_DRAFTING_POINT",
            }

        buttons = []
        if self.render_buttons and "button_1" in resolved:
            buttons.append({
                "name": "button_1",
                "center_2d": list(resolved["button_1"]),
                "semantic": "r3" if active_count == 1 else "button_1",
                "owner": "FRONT_CENTER",
                "render_role": "decorative",
                "mirror_to_other_front": False,
            })
        if self.render_buttons and active_count >= 2 and "button_2" in resolved:
            buttons.append({
                "name": "button_2",
                "center_2d": list(resolved["button_2"]),
                "semantic": "button_2",
                "owner": "FRONT_CENTER",
                "render_role": "decorative",
                "mirror_to_other_front": False,
            })

        if active_count == 1:
            pair_semantics = {
                "enabled": False,
                "mode": "lapel_point_only",
                "current_stage_apply": False,
                "target_zone": "button_1_break_point_lapel_point",
                "interface_hint": "button_1",
                "front_opening_line": False,
            }
        else:
            pair_semantics = {
                "enabled": True,
                "mode": "two_button_long_pair",
                "current_stage_apply": True,
                "target_zone": "segment_between_button_1_and_button_2",
                "boundary_source_hint": "front_edge_3",
                "front_interface_hints": ["button_1", "button_2", "front_opening"],
                "front_opening_line": True,
            }

        self.button_semantics = {
            "button_count": active_count,
            "button_spacing_cm": spacing_cm,
            "buttons": buttons,
            "resolved_positions_2d": deepcopy(resolved),
            "position_authority": button_authority,
            "formal_stitch_count": 0,
            "button_render_only": True,
            "closure_enabled": False,
            "render_buttons": self.render_buttons,
            "pair_semantics": pair_semantics,
            "placement_rule": [
                "one button: button_1 = current r3",
                "two buttons: current drafting button_1/button_2 authority",
            ],
            "boundary_projection": deepcopy(button_info.get("boundary_projection", {})),
        }

        self.stage_report = {
            "decorative_buttons_created": len(buttons) if self.render_buttons else 0,
            "button_render_count": len(buttons) if self.render_buttons else 0,
            "button_count": active_count,
            "button_spacing_cm": spacing_cm,
            "real_button_mesh_created": False,
            "formal_stitch_created": False,
            "closure_created": False,
            "pair_semantics_recorded": True,
            "current_stage_pair_apply": bool(pair_semantics.get("current_stage_apply", False)),
        }


def build_suit_buttons(front_component, suit_params, name="clean_suit_buttons"):
    return SuitButtonComponent(name, front_component, suit_params)
