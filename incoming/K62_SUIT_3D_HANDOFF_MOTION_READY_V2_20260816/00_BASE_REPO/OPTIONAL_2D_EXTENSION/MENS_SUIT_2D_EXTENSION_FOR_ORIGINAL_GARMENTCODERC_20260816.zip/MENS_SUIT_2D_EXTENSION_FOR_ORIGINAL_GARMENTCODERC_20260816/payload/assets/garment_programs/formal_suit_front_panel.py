"""Formal front panel with Stage-A2 design-driven lower front edge and buttons.

2-D scope only:
- curved front lower edge keeps the frozen V9 t6-t4-u3-r3 curve chain;
- straight mode replaces that chain by t6-t2 and t2-r3 straight segments;
- true drafting button points remain inside the panel:
    button_1 = r3 shifted horizontally right by M
    button_2 = button_1 shifted vertically downward by button_spacing_cm
- the existing GarmentCode virtual closure still requires boundary interfaces;
  therefore each drafting button is mapped to the nearest point on the lower
  front-opening boundary.  This is an interface adapter, not a redefinition of
  the drafting button position.
"""
from __future__ import annotations

from copy import deepcopy
import math

import numpy as np
import pygarment as pyg

from assets.garment_programs.suit_curve_rules_v2 import (
    abs_cp_to_q,
    q_to_abs,
    split_curve_at_t,
)
from assets.garment_programs.suit_geometry import localize_points, make_edge, make_sequence
from assets.garment_programs.suit_pattern_data import FRONT_EDGES, FRONT_POINTS
from assets.garment_programs.suit_peak_lapel_geometry import (
    build_peak_front_opening_records,
    resolve_lapel_style,
)
from assets.garment_programs.suit_lapel_fold_semantics import (
    build_lapel_fold_records,
    lapel_fold_definition,
)


def _rebuild_record(template, points, *, source=None, group=None):
    rec = {k: deepcopy(v) for k, v in template.items() if k not in ("c1", "c2")}
    if source is not None:
        rec["source"] = source
    if template.get("kind") == "curve":
        q1 = abs_cp_to_q(
            FRONT_POINTS[template["p0"]], FRONT_POINTS[template["p1"]], template["c1"]
        )
        q2 = abs_cp_to_q(
            FRONT_POINTS[template["p0"]], FRONT_POINTS[template["p1"]], template["c2"]
        )
        rec["c1"] = q_to_abs(points[rec["p0"]], points[rec["p1"]], q1)
        rec["c2"] = q_to_abs(points[rec["p0"]], points[rec["p1"]], q2)
    if group is not None:
        rec["semantic_group"] = group
    return rec


def _straight(p0, p1, source, group):
    return {
        "kind": "straight",
        "p0": p0,
        "p1": p1,
        "source": source,
        "semantic_group": group,
    }


def build_formal_front_boundary(formal_result, front_draft_result):
    """Join one already-resolved front draft to the formal WS construction."""
    if front_draft_result is None:
        raise ValueError("front_draft_result is required")
    points = {name: list(value) for name, value in front_draft_result.points.items()}
    # t2 is a drafting auxiliary in the curved BASE, but becomes a true
    # boundary point in straight mode.
    points["t2"] = list(front_draft_result.derived_quantities["t2"])
    points.update({name: list(value) for name, value in formal_result.points.items()})

    split_ws = [deepcopy(edge) for edge in formal_result.ws_split_edges]
    last_index = next(i for i, edge in enumerate(split_ws) if edge["p1"] == "s")
    left, _ = split_curve_at_t(
        split_ws[last_index], points, formal_result.diagnostics["m1_curve_t"], "m1"
    )
    split_ws[last_index:last_index + 1] = [left]
    p5_end = next(i for i, edge in enumerate(split_ws) if edge["p1"] == "p5")
    p6_start = next(i for i, edge in enumerate(split_ws) if edge["p0"] == "p6")
    armhole_upper = split_ws[:p5_end + 1]
    armhole_lower = split_ws[p6_start:]
    for edge in armhole_upper:
        edge["semantic_group"] = "armhole_upper"
        edge["source"] = "formal_ws_armhole_upper"
    for edge in armhole_lower:
        edge["semantic_group"] = "armhole_lower"
        edge["source"] = "formal_ws_armhole_lower"

    by_source = {edge["source"]: edge for edge in FRONT_EDGES}
    neckline = [_rebuild_record(by_source["neckline_front"], points, group="neckline")]
    shoulder = [
        _rebuild_record(by_source["v_a2"], points, group="shoulder"),
        _rebuild_record(by_source["a2_w"], points, group="shoulder"),
    ]
    side_dart_left = [deepcopy(edge) for edge in formal_result.boundary_edges[0:2]]
    side_dart_right = [deepcopy(edge) for edge in formal_result.boundary_edges[2:4]]
    for edge in side_dart_left:
        edge["semantic_group"] = "side_dart_left"
    for edge in side_dart_right:
        edge["semantic_group"] = "side_dart_right"
    side_seam = [
        deepcopy(formal_result.boundary_edges[-2]),
        deepcopy(formal_result.boundary_edges[-1]),
    ]
    for edge in side_seam:
        edge["semantic_group"] = "side_seam"

    hem = [_rebuild_record(by_source["hem"], points, group="hem")]

    style = front_draft_result.derived_quantities.get("front_lower_edge_style", "curved")
    if style == "curved":
        lower_front = [
            _rebuild_record(by_source["front_edge_1"], points, group="front_opening"),
            _rebuild_record(by_source["front_edge_2"], points, group="front_opening"),
            _rebuild_record(by_source["front_edge_3"], points, group="front_opening"),
        ]
    elif style == "straight":
        # User-confirmed rule, current boundary traversal direction reversed:
        # r3 -> t2 -> t6  ==  t6 -> t2 -> r3.
        lower_front = [
            _straight("t6", "t2", "front_straight_t6_t2", "front_opening"),
            _straight("t2", "r3", "front_straight_t2_r3", "front_opening"),
        ]
    else:
        raise ValueError(f"Unsupported front_lower_edge_style: {style}")

    # The formal lapel_to_neck record is a straight s5->r5 segment in the
    # current construction.  Subdivide that same segment at the generated
    # semantic s4 point; this preserves the boundary exactly while exposing
    # an independent r5-s4 physical edge for the formal collar seam.
    lapel = by_source["lapel_to_neck"]
    p0 = np.asarray(points[lapel["p0"]], dtype=float)
    p1 = np.asarray(points[lapel["p1"]], dtype=float)
    s4 = np.asarray(points["s4"], dtype=float)
    den = float(np.dot(p1 - p0, p1 - p0))
    t_s4 = float(np.dot(s4 - p0, p1 - p0) / den) if den > 1e-12 else -1.0
    if not (1e-9 < t_s4 < 1.0 - 1e-9):
        raise ValueError(f"FORMAL_S4_NOT_ON_LAPEL_TO_NECK:t={t_s4}")
    notched_upper_front = [
        _rebuild_record(by_source["lapel_edge_1"], points, group="front_opening"),
        _rebuild_record(by_source["lapel_edge_2"], points, group="front_opening"),
        _straight("s5", "s4", "lapel_to_neck_remaining", "front_opening"),
        _straight("s4", "r5", "a4_current_r5_s4", "front_opening"),
    ]

    lapel_style = str(
        front_draft_result.diagnostics.get("lapel_style", "notched")
    ).lower()
    if lapel_style == "notched":
        upper_front = notched_upper_front
    elif lapel_style == "peak":
        upper_front = build_peak_front_opening_records(
            points,
            notched_upper_front,
        )
    else:
        raise ValueError(f"Unsupported lapel_style: {lapel_style}")

    records = (
        neckline + shoulder + armhole_upper + side_dart_left + side_dart_right
        + armhole_lower + side_seam + hem + lower_front + upper_front
    )
    return points, records


def _eval_record(record, points, t):
    a = np.asarray(points[record["p0"]], dtype=float)
    b = np.asarray(points[record["p1"]], dtype=float)
    if record.get("kind") != "curve":
        return a + float(t) * (b - a)
    c1 = np.asarray(record["c1"], dtype=float)
    c2 = np.asarray(record["c2"], dtype=float)
    u = 1.0 - float(t)
    return u**3 * a + 3*u*u*t*c1 + 3*u*t*t*c2 + t**3*b


def _nearest_fraction_on_record(record, points, target, samples=241):
    """Return approximate arc-length fraction nearest an interior button point."""
    target = np.asarray(target, dtype=float)
    ts = np.linspace(0.0, 1.0, int(samples))
    pts = np.asarray([_eval_record(record, points, t) for t in ts])
    ds = np.linalg.norm(pts - target[None, :], axis=1)
    idx = int(np.argmin(ds))
    seg = np.linalg.norm(np.diff(pts, axis=0), axis=1)
    cum = np.concatenate([[0.0], np.cumsum(seg)])
    total = float(cum[-1])
    frac = 0.0 if total <= 1.0e-12 else float(cum[idx] / total)
    return frac, float(ds[idx])


def _split_edge_for_markers(edge, markers, button_length_cm):
    """Subdivide one boundary edge once and return replacement/button segments.

    ``pygarment.Edge.subdivide_len()`` must not receive zero-length ratios.
    A button whose true drafting point projects to an edge endpoint naturally
    produces a virtual interval such as [0, L] or [1-L, 1].  The previous A2
    implementation inserted both the endpoint and the interval endpoint into
    ``bounds``, creating a leading/trailing ratio of 0 and therefore a
    zero-length Edge.  Here we deduplicate cut positions before subdivision
    and determine button pieces from their normalized spans instead of relying
    on fixed part indices.
    """
    total = float(edge.length())
    if total <= 1.0e-8:
        raise ValueError("virtual button source edge has zero length")

    button_length_cm = float(button_length_cm)
    if button_length_cm <= 0.0:
        raise ValueError("button_length_cm must be positive")

    button_fraction = button_length_cm / total
    if button_fraction >= 1.0 - 1.0e-8:
        raise ValueError(
            "virtual button segment must be shorter than its source edge"
        )
    half = 0.5 * button_fraction

    intervals = []
    for name, center in sorted(markers, key=lambda row: row[1]):
        # Keep the true drafting point untouched.  Only the finite virtual
        # boundary segment is clamped so it remains fully on the source edge.
        c = min(max(float(center), half), 1.0 - half)
        lo = max(0.0, c - half)
        hi = min(1.0, c + half)
        intervals.append([lo, hi, name, c])

    for a, b in zip(intervals[:-1], intervals[1:]):
        if a[1] > b[0] - 1.0e-8:
            raise ValueError(
                "virtual button regions overlap on one front-opening edge"
            )

    # Build all cut positions, then remove duplicates caused by an interval
    # touching 0 or 1.  This guarantees every subdivide_len ratio is positive.
    raw_bounds = [0.0, 1.0]
    for lo, hi, _, _ in intervals:
        raw_bounds.extend([lo, hi])

    bounds = []
    for value in sorted(raw_bounds):
        value = min(max(float(value), 0.0), 1.0)
        if not bounds or abs(value - bounds[-1]) > 1.0e-10:
            bounds.append(value)

    ratios = [
        bounds[i + 1] - bounds[i]
        for i in range(len(bounds) - 1)
    ]
    if not ratios or any(ratio <= 1.0e-10 for ratio in ratios):
        raise ValueError("virtual button subdivision produced a zero-length part")

    source_label = getattr(edge, "label", "")
    parts = list(edge.subdivide_len(ratios))
    spans = list(zip(bounds[:-1], bounds[1:]))
    if len(parts) != len(spans):
        raise RuntimeError(
            "unexpected edge subdivision result while creating button interfaces"
        )

    button_parts = {}
    tol = 1.0e-9
    for part, (seg_lo, seg_hi) in zip(parts, spans):
        matched_name = None
        for lo, hi, name, _ in intervals:
            if seg_lo >= lo - tol and seg_hi <= hi + tol:
                matched_name = name
                break

        if matched_name is None:
            part.label = source_label
        else:
            if matched_name in button_parts:
                raise RuntimeError(
                    f"virtual {matched_name} unexpectedly spans multiple edge parts"
                )
            part.label = f"virtual_{matched_name}"
            button_parts[matched_name] = part

    missing = [name for _, _, name, _ in intervals if name not in button_parts]
    if missing:
        raise RuntimeError(
            f"failed to create virtual button edge(s): {', '.join(missing)}"
        )

    return parts, button_parts


class FormalParametricSuitFrontPanel(pyg.Panel):
    """Formal full front using one shared draft result and semantic button points."""

    def __init__(
        self, name, formal_result, front_draft_result,
        button_stitch_cm=0.8, button_count=None,
    ):
        super().__init__(name)
        self.formal_result = formal_result
        self.front_draft_result = front_draft_result
        if button_count is None:
            button_count = int(front_draft_result.derived_quantities.get("button_count", 2))
        self.button_count = int(button_count)
        if self.button_count not in (1, 2):
            raise ValueError("button_count must be 1 or 2")

        self.original_points, self.semantic_edges = build_formal_front_boundary(
            formal_result, front_draft_result
        )
        # Preserve the formal A4 semantic landmarks for downstream adapters.
        # These are metadata only; the boundary remains unchanged here.
        self.semantic_points = {
            name: list(front_draft_result.points[name])
            for name in ("r5", "s4")
            if name in front_draft_result.points
        }
        self.vertices = localize_points(self.original_points, "r5")
        self.edges = pyg.EdgeSequence()
        grouped = {}
        built_rows = []
        for record in self.semantic_edges:
            edge = make_edge(self.vertices, record, self.original_points)
            self.edges.append(edge)
            grouped.setdefault(record["semantic_group"], []).append(edge)
            built_rows.append([record, edge])

        lower_sources = {
            "front_edge_1", "front_edge_2", "front_edge_3",
            "front_straight_t6_t2", "front_straight_t2_r3",
        }
        lower_rows = [row for row in built_rows if row[0].get("source") in lower_sources]
        if not lower_rows:
            raise ValueError("no lower front-opening records found for button mapping")

        targets = [(
            "button_1",
            front_draft_result.derived_quantities["first_button_drafting_point"],
        )]
        if self.button_count >= 2:
            targets.append((
                "button_2",
                front_draft_result.derived_quantities["second_button_drafting_point"],
            ))

        markers_by_edge = {}
        button_projection_report = {}
        for button_name, target in targets:
            best = None
            for record, edge in lower_rows:
                fraction, distance = _nearest_fraction_on_record(record, self.original_points, target)
                row = (distance, fraction, record, edge)
                if best is None or row[0] < best[0]:
                    best = row
            distance, fraction, record, edge = best
            markers_by_edge.setdefault(id(edge), {"edge": edge, "markers": []})["markers"].append(
                (button_name, fraction)
            )
            button_projection_report[button_name] = {
                "drafting_point": list(target),
                "boundary_source": record.get("source"),
                "nearest_arc_fraction": fraction,
                "draft_to_boundary_distance_cm": distance,
            }

        replacements = {}
        button_edges = {}
        for row in markers_by_edge.values():
            edge = row["edge"]
            parts, buttons = _split_edge_for_markers(edge, row["markers"], button_stitch_cm)
            self.edges.substitute(edge, parts)
            replacements[id(edge)] = parts
            button_edges.update(buttons)

        front_opening = []
        for edge in grouped["front_opening"]:
            front_opening.extend(replacements.get(id(edge), [edge]))

        interface_edges = {
            "neckline": grouped["neckline"],
            "shoulder": grouped["shoulder"],
            "armhole_upper": grouped["armhole_upper"],
            "side_dart_left": grouped["side_dart_left"],
            "side_dart_right": grouped["side_dart_right"],
            "armhole_lower": grouped["armhole_lower"],
            "side_seam": grouped["side_seam"],
            "hem": grouped["hem"],
            "front_opening": front_opening,
        }
        self.interfaces = {
            name_: pyg.Interface(self, pyg.EdgeSequence(*edges))
            for name_, edges in interface_edges.items()
        }
        self.interfaces["side_dart_right"].reverse()
        self.interfaces["button_1"] = pyg.Interface(
            self, pyg.EdgeSequence(button_edges["button_1"])
        )
        if self.button_count >= 2:
            self.interfaces["button_2"] = pyg.Interface(
                self, pyg.EdgeSequence(button_edges["button_2"])
            )
        # Semantic two-button span: derive the unique front-opening boundary
        # segment between the two virtual button intervals.  This is an
        # interface adapter only; it does not alter drafting points or panel
        # geometry and avoids fixed edge-index authority.
        if self.button_count >= 2:
            opening_edges = list(self.interfaces["front_opening"].edges)
            i1 = next(i for i,e in enumerate(opening_edges) if getattr(e, "label", "") == "virtual_button_1")
            i2 = next(i for i,e in enumerate(opening_edges) if getattr(e, "label", "") == "virtual_button_2")
            if i1 > i2:
                i1, i2 = i2, i1
            span = opening_edges[i1 + 1:i2]
            span = [e for e in span if not str(getattr(e, "label", "")).startswith("virtual_button_")]
            if span:
                self.interfaces["two_button_span"] = pyg.Interface(self, pyg.EdgeSequence(*span))
        # Formal A4 semantic seam hooks.  These are interface-only views of
        # the existing lapel_to_neck geometry; no boundary geometry is
        # changed and serialization remains controlled by the assembly layer.
        self.interfaces["r5_s4"] = pyg.Interface(
            self, pyg.EdgeSequence(next(e for e in self.edges
                                        if getattr(e, "label", "") == "a4_current_r5_s4"))
        )
        self.interfaces["armhole"] = pyg.Interface.from_multiple(
            self.interfaces["armhole_upper"], self.interfaces["armhole_lower"]
        )
        self.internal_features = {
            "chest_waist_dart": make_sequence(
                self.vertices, formal_result.internal_edges, self.original_points
            ),
            "chest_waist_dart_definition": {
                "left": ["q9", "r1", "q6"],
                "right": ["q9", "r2", "q6"],
            },
            "drafting_buttons": {
                "button_1": list(
                    front_draft_result.derived_quantities["first_button_drafting_point"]
                ),
                "button_2": list(
                    front_draft_result.derived_quantities["second_button_drafting_point"]
                ),
                "active_count": self.button_count,
                "boundary_projection": button_projection_report,
            },
        }
        lapel_fold_parent = front_draft_result.diagnostics[
            "lapel_fold_semantic"
        ]["collar_edge_reference"]
        self.internal_features["lapel_fold"] = make_sequence(
            self.vertices,
            build_lapel_fold_records(
                self.original_points,
                lapel_fold_parent,
            ),
            self.original_points,
        )
        self.internal_features["lapel_fold_definition"] = (
            lapel_fold_definition(lapel_fold_parent)
        )
