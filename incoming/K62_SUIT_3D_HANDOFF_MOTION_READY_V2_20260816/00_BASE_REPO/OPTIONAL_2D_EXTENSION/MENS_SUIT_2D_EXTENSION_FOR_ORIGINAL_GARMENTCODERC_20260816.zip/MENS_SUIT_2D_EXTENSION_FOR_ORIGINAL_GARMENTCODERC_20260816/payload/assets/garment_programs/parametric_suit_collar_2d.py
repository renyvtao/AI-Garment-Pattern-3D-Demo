"""Stage A4 standalone 2-D parametric collar Panel adapter.

This class is intentionally NOT substituted into FormalSuitAssemblyBase in A4.
It proves that the design parameters reach a real pygarment Panel while leaving
all existing 3-D collar placement/fold/simulation behavior frozen.
"""
from __future__ import annotations

import pygarment as pyg

from assets.garment_programs.suit_geometry import localize_points, make_edge


class ParametricSuitCollar2DPanel(pyg.Panel):
    def __init__(self, name, draft_result):
        super().__init__(name)
        self.draft_result = draft_result
        self.original_points = draft_result.points
        self.vertices = localize_points(self.original_points, "r8")

        self.edges = pyg.EdgeSequence()
        built = []
        for record in draft_result.boundary_records:
            edge = make_edge(self.vertices, record, self.original_points)
            self.edges.append(edge)
            built.append(edge)

        if len(built) != 8:
            raise ValueError("A4 collar boundary must contain exactly 8 edges")

        self.interfaces = {
            "attach_right": pyg.Interface(self, pyg.EdgeSequence(built[0])),
            "attach_left": pyg.Interface(
                self, pyg.EdgeSequence(built[-1])
            ).reverse(),
            "outer_right": pyg.Interface(
                self, pyg.EdgeSequence(*built[1:4])
            ),
            "outer_left": pyg.Interface(
                self, pyg.EdgeSequence(*built[4:7])
            ),
        }

        self.stage_a4_report = {
            "two_d_only": True,
            "three_d_placement_applied": False,
            "warp_run": False,
            "derived_quantities": dict(draft_result.derived_quantities),
            "diagnostics": dict(draft_result.diagnostics),
        }
