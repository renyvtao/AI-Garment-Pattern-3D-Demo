"""A4-Peak — peak-lapel front-body 2-D branch.

Scope
-----
This module changes ONLY the 2-D front-body peak-lapel boundary.
The collar piece, 3-D placement, fold physics and Warp logic are untouched.

User-confirmed peak-lapel rules (2026-08-12)
--------------------------------------------
Start from the already-resolved construction points:
    r3, r5, s3, s4, s5

1) y3
   s3-s4 is a straight line. Continue the directed line s4->s3 beyond s3
   and place y3 so that:
       |y3-s4| = 1.875 * |s3-s4|
   Therefore:
       y3 = s4 + 1.875 * (s3-s4)
   and y3 lies beyond s3 on the same straight line.

2) y4
   First trisection point from r3 toward y3:
       y4 = r3 + (y3-r3)/3

3) y5
   At y4 construct a 0.5 cm perpendicular to line r3-y3 toward the left.
   The directed reference is r3->y3:
       left_normal(r3->y3) = (-dy, dx) / |r3-y3|
       y5 = y4 + 0.5 * left_normal(r3->y3)

4) New peak outer curve
   Connect r3 -> y5 -> y3 with a smooth, slightly left-convex curve.
   Its curvature character should stay approximately consistent with the old
   notched-lapel s5-r3 curve.  Implementation keeps the old two cubic
   chord-local q-shapes and retargets them to:
       old r3->s8  -> new r3->y5
       old s8->s5  -> new y5->y3
   Thus y5 is a real through-point rather than an arbitrary Bezier handle.

5) Straight peak lines
       y3 -> s4 : straight
       s4 -> r5 : straight
   The construction segment s3-s4 remains straight and y3 is on its extension.

6) Front-body collar corner semantics
   The semantic corner sequence is:
       v -> r5 -> s4 -> y3 -> r3
   y4/y5 are drafting/curve construction points, not additional semantic
   collar corners.

Important
---------
- y3/y4/y5 are drafting-derived points, not design parameters.
- lapel_style remains the style selector: notched | peak.
- No 3-D placement, collision, Warp, rest-length, topology or whole-piece
  scaling changes are introduced here.
"""
from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np

from assets.garment_programs.suit_curve_rules_v2 import abs_cp_to_q, q_to_abs


EPS = 1.0e-10

PEAK_Y3_S4_TO_S3_S4_RATIO = 1.875
PEAK_Y4_LEFT_NORMAL_CM = 0.5
PEAK_RULE_VERSION = "PEAK_2D_Y3Y5R3_2026_08_12"


class PeakLapelValidationError(ValueError):
    pass


@dataclass(frozen=True)
class PeakLapelGeometry:
    points: dict
    diagnostics: dict


def _leaf(value):
    if isinstance(value, dict) and "v" in value:
        return value["v"]
    return value


def resolve_lapel_style(suit_params):
    supplied = {} if suit_params is None else suit_params
    raw = supplied.get("lapel_style", "notched")
    raw = _leaf(raw)
    if raw is None:
        raw = "notched"
    style = str(raw).strip().lower()
    aliases = {
        "notched": "notched",
        "notch": "notched",
        "平驳领": "notched",
        "peak": "peak",
        "peaked": "peak",
        "枪驳领": "peak",
    }
    if style not in aliases:
        raise PeakLapelValidationError(
            "lapel_style must be one of: notched, peak"
        )
    return aliases[style]


def _arr(p):
    return np.asarray(p, dtype=float)


def _distance(a, b):
    return float(np.linalg.norm(_arr(b) - _arr(a)))


def _unit_vec(v):
    v = _arr(v)
    n = float(np.linalg.norm(v))
    if n <= EPS:
        raise PeakLapelValidationError("zero-length peak-lapel direction")
    return v / n


def _cross2(a, b):
    a = _arr(a)
    b = _arr(b)
    return float(a[0] * b[1] - a[1] * b[0])


def _point_line_distance(p, a, b):
    p, a, b = map(_arr, (p, a, b))
    return abs(_cross2(_unit_vec(b - a), p - a))


def _angle_deg(v1, v2):
    a = _unit_vec(v1)
    b = _unit_vec(v2)
    dot = float(np.clip(np.dot(a, b), -1.0, 1.0))
    return math.degrees(math.acos(dot))


def _left_normal(direction):
    d = _unit_vec(direction)
    return np.asarray([-d[1], d[0]], dtype=float)


def derive_peak_lapel_points(base_points):
    """Derive y3/y4/y5 from the resolved front/collar construction."""
    needed = ("r3", "r5", "s3", "s4", "s5")
    missing = [name for name in needed if name not in base_points]
    if missing:
        raise PeakLapelValidationError(
            "missing peak-lapel upstream point(s): " + ", ".join(missing)
        )

    r3 = _arr(base_points["r3"])
    s3 = _arr(base_points["s3"])
    s4 = _arr(base_points["s4"])

    # y3: continue the straight s4->s3 line beyond s3.
    # |y3-s4| = 1.875 * |s3-s4|.
    y3 = s4 + PEAK_Y3_S4_TO_S3_S4_RATIO * (s3 - s4)

    # y4: first trisection point from r3 toward y3.
    y4 = r3 + (y3 - r3) / 3.0

    # y5: 0.5 cm to the LEFT of directed line r3->y3.
    left = _left_normal(y3 - r3)
    y5 = y4 + PEAK_Y4_LEFT_NORMAL_CM * left

    points = {
        "y3": y3.tolist(),
        "y4": y4.tolist(),
        "y5": y5.tolist(),
    }

    d_s = s3 - s4
    t_from_s4 = float(np.dot(y3 - s4, d_s) / np.dot(d_s, d_s))
    diagnostics = {
        "stage": "A4_PEAK_LAPEL_DERIVED_POINTS",
        "rule_version": PEAK_RULE_VERSION,
        "y3_s4_over_s3_s4": _distance(s4, y3) / _distance(s4, s3),
        "y3_ratio_residual": abs(
            _distance(s4, y3) / _distance(s4, s3)
            - PEAK_Y3_S4_TO_S3_S4_RATIO
        ),
        "y3_on_s4_s3_extension_residual_cm": _point_line_distance(y3, s4, s3),
        "y3_extension_parameter_from_s4": t_from_s4,
        "y3_beyond_s3": bool(t_from_s4 > 1.0),
        "r3_y4_over_r3_y3": _distance(r3, y4) / _distance(r3, y3),
        "y4_on_r3_y3_residual_cm": _point_line_distance(y4, r3, y3),
        "y4_y5_cm": _distance(y4, y5),
        "y4_y5_perpendicular_dot": abs(float(np.dot(
            _unit_vec(y5 - y4), _unit_vec(y3 - r3)
        ))),
        "y5_left_normal_alignment": float(np.dot(
            _unit_vec(y5 - y4), _left_normal(y3 - r3)
        )),
        "y5_is_literal_left_in_pattern_x": bool(y5[0] < y4[0]),
        "left_rule": "directed r3->y3; left normal = (-dy, dx)",
        "outer_curve_replaces": "original s5-r3 outer curve",
        "body_corner_topology": ["v", "r5", "s4", "y3", "r3"],
        "derived_points_are_design_parameters": False,
        "three_d_modified": False,
        "warp_run": False,
    }
    return PeakLapelGeometry(points=points, diagnostics=diagnostics)


def _retarget_curve_record(record, points, new_p0, new_p1, source):
    """Retarget an existing curve while preserving its chord-local q shape."""
    if record.get("kind") != "curve":
        raise PeakLapelValidationError(
            f"peak curve reference {record.get('source')} must be cubic"
        )
    old_p0 = record["p0"]
    old_p1 = record["p1"]
    if old_p0 not in points or old_p1 not in points:
        raise PeakLapelValidationError(
            f"missing old curve endpoint(s): {old_p0}, {old_p1}"
        )
    q1 = abs_cp_to_q(points[old_p0], points[old_p1], record["c1"])
    q2 = abs_cp_to_q(points[old_p0], points[old_p1], record["c2"])
    return {
        "kind": "curve",
        "p0": new_p0,
        "p1": new_p1,
        "c1": q_to_abs(points[new_p0], points[new_p1], q1),
        "c2": q_to_abs(points[new_p0], points[new_p1], q2),
        "source": source,
        "semantic_group": "front_opening",
        "shape_reference_source": record.get("source"),
        "shape_policy": "retarget_old_notched_curve_q_shape",
    }


def build_peak_body_curve_records(points, notched_upper_front):
    """Build the new r3->y5->y3 slightly-left-convex outer curve.

    Curve policy:
    - old notched r3->s8 chord-local q-shape is retargeted to r3->y5;
    - old notched s8->s5 chord-local q-shape is retargeted to y5->y3.

    This preserves the curvature character of the existing s5-r3 opening as
    closely as possible without inventing a new free curvature parameter.
    """
    needed = ("r3", "s8", "s5", "y3", "y5")
    missing = [name for name in needed if name not in points]
    if missing:
        raise PeakLapelValidationError(
            "missing peak curve point(s): " + ", ".join(missing)
        )
    if len(notched_upper_front) < 2:
        raise PeakLapelValidationError(
            "notched upper-front reference must contain r3-s8 and s8-s5 curves"
        )

    rec0 = notched_upper_front[0]
    rec1 = notched_upper_front[1]
    if (rec0.get("p0"), rec0.get("p1")) != ("r3", "s8"):
        raise PeakLapelValidationError(
            "first notched reference must be directed r3->s8"
        )
    if (rec1.get("p0"), rec1.get("p1")) != ("s8", "s5"):
        raise PeakLapelValidationError(
            "second notched reference must be directed s8->s5"
        )

    return [
        _retarget_curve_record(
            rec0, points, "r3", "y5", "a4_peak_body_curve_r3_y5"
        ),
        _retarget_curve_record(
            rec1, points, "y5", "y3", "a4_peak_body_curve_y5_y3"
        ),
    ]


def build_peak_front_opening_records(points, notched_upper_front):
    """Return the full 2-D replacement for the notched upper opening chain."""
    curves = build_peak_body_curve_records(points, notched_upper_front)
    return curves + [
        {
            "kind": "straight",
            "p0": "y3",
            "p1": "s4",
            "source": "a4_peak_y3_s4_straight",
            "semantic_group": "front_opening",
        },
        {
            "kind": "straight",
            "p0": "s4",
            "p1": "r5",
            # This is the same formal collar/front junction used by the
            # notched branch.  Peak changes the upstream lapel-tip boundary,
            # not the semantic identity of s4->r5.  Keep the common label so
            # four/six-panel assemblies can share the collar interface
            # contract without branching on lapel style.
            "source": "a4_current_r5_s4",
            "style_source": "a4_peak_s4_r5_straight",
            "semantic_group": "front_opening",
        },
    ]


def peak_rule_audit(points, peak_records):
    """Audit the 2026-08-12 user-confirmed 2-D peak-lapel construction."""
    needed = ("r3", "r5", "s3", "s4", "s5", "y3", "y4", "y5")
    missing = [name for name in needed if name not in points]
    if missing:
        raise PeakLapelValidationError(
            "peak audit missing point(s): " + ", ".join(missing)
        )

    r3,r5,s3,s4,s5,y3,y4,y5 = [
        _arr(points[n]) for n in needed
    ]

    expected_sources = [
        "a4_peak_body_curve_r3_y5",
        "a4_peak_body_curve_y5_y3",
        "a4_peak_y3_s4_straight",
        "a4_current_r5_s4",
    ]
    sources = [r.get("source") for r in peak_records]

    d_s = s3 - s4
    t_s = float(np.dot(y3 - s4, d_s) / np.dot(d_s, d_s))
    left = _left_normal(y3 - r3)

    rows = {
        "rule_version": PEAK_RULE_VERSION,
        "y3_s4_over_s3_s4": _distance(s4,y3)/_distance(s4,s3),
        "y3_ratio_residual": abs(
            _distance(s4,y3)/_distance(s4,s3)
            - PEAK_Y3_S4_TO_S3_S4_RATIO
        ),
        "y3_collinear_s4_s3_cm": _point_line_distance(y3,s4,s3),
        "y3_beyond_s3_parameter_from_s4": t_s,
        "y4_trisection_residual": abs(
            _distance(r3,y4)/_distance(r3,y3) - 1.0/3.0
        ),
        "y4_collinear_r3_y3_cm": _point_line_distance(y4,r3,y3),
        "y4_y5_residual_cm": abs(_distance(y4,y5)-PEAK_Y4_LEFT_NORMAL_CM),
        "y4_y5_perpendicular_dot": abs(float(np.dot(
            _unit_vec(y5-y4), _unit_vec(y3-r3)
        ))),
        "y5_left_normal_alignment": float(np.dot(
            _unit_vec(y5-y4), left
        )),
        "y5_is_literal_left_in_pattern_x": bool(y5[0] < y4[0]),
        "s3_on_y3_s4_straight_cm": _point_line_distance(s3,y3,s4),
        "peak_front_sources_exact": sources == expected_sources,
        "body_corner_topology": ["v","r5","s4","y3","r3"],
        "boundary_construction_chain": ["r3","y5","y3","s4","r5","v"],
        "outer_curve_replaces_original_s5_r3": True,
        "outer_curve_shape_policy": "RETARGET_OLD_NOTCHED_S5_R3_Q_SHAPE",
        "y5_left_rule": "directed r3->y3 left normal",
        "collar_piece_changed": False,
        "three_d_modified": False,
    }

    if len(peak_records) >= 2:
        c0,c1 = peak_records[:2]
        y5_in = y5 - _arr(c0["c2"])
        y5_out = _arr(c1["c1"]) - y5
        rows["y5_curve_join_tangent_angle_deg"] = _angle_deg(y5_in,y5_out)
    else:
        rows["y5_curve_join_tangent_angle_deg"] = None

    if len(peak_records) >= 3:
        c1 = peak_records[1]
        y3_curve = y3 - _arr(c1["c2"])
        y3_straight = s4 - y3
        rows["y3_curve_to_s4_straight_angle_deg"] = _angle_deg(
            y3_curve, y3_straight
        )
    else:
        rows["y3_curve_to_s4_straight_angle_deg"] = None

    tol = 1.0e-7
    rows["PEAK_RULES_PASS"] = bool(
        rows["y3_ratio_residual"] <= tol
        and rows["y3_collinear_s4_s3_cm"] <= tol
        and rows["y3_beyond_s3_parameter_from_s4"] > 1.0
        and rows["y4_trisection_residual"] <= tol
        and rows["y4_collinear_r3_y3_cm"] <= tol
        and rows["y4_y5_residual_cm"] <= tol
        and rows["y4_y5_perpendicular_dot"] <= tol
        and abs(rows["y5_left_normal_alignment"] - 1.0) <= tol
        and rows["y5_is_literal_left_in_pattern_x"]
        and rows["s3_on_y3_s4_straight_cm"] <= tol
        and rows["peak_front_sources_exact"]
    )
    return rows
