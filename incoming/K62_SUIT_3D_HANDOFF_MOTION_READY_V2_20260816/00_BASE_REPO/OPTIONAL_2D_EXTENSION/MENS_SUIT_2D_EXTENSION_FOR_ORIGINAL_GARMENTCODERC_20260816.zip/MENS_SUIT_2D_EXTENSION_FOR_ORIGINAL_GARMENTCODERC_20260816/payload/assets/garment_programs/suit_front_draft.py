"""Pure 2-D drafting layer for the parametric four-panel suit front.

The module intentionally creates no pygarment objects.  Missing dynamic rules
are never hidden: the normal mode raises ``UNRESOLVED_DYNAMIC_POINT`` and the
only BASE escape hatch is an explicit, labelled frozen-only diagnostic mode.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import math
from pathlib import Path

import yaml

from assets.garment_programs.suit_curve_rules_v2 import edge_key, q_to_abs
from assets.garment_programs.suit_pattern_data import (
    FRONT_EDGES,
    FRONT_POINTS,
)


ROOT = Path(__file__).resolve().parents[2]
FRONT_CONFIG = ROOT / "assets/design_params/suit_parametric/front_notched.yaml"
RULES_CONFIG = ROOT / "assets/design_params/suit_parametric/rules_v1/construction_rules.yaml"

SEMANTIC_POINT_ORDER = tuple(FRONT_POINTS)
EDGE_TEMPLATE = tuple(
    {k: record[k] for k in ("kind", "p0", "p1", "source") if k in record}
    for record in FRONT_EDGES
)

# No rule in the audited source currently makes these points dynamic.  The
# list is deliberately explicit so adding a rule requires a conscious edit.
UNRESOLVED_SEMANTIC_POINTS = (
    "m1", "m7", "t8", "s5",
    "p5", "p8", "p4", "q9", "r1", "q6", "r2", "p9", "p6",
    "a7", "a4", "c1", "c5", "r5",
)
UNRESOLVED_UPSTREAM_POINTS = ("final_suit_a5", "final_suit_dynamic_ws_curve")

FORMAL_INTERNAL_DART_EDGES = (
    {"kind": "straight", "p0": "q9", "p1": "r1", "source": "chest_dart_left_1"},
    {"kind": "straight", "p0": "r1", "p1": "q6", "source": "chest_dart_left_2"},
    {"kind": "straight", "p0": "q9", "p1": "r2", "source": "chest_dart_right_1"},
    {"kind": "straight", "p0": "r2", "p1": "q6", "source": "chest_dart_right_2"},
)


class UnresolvedDynamicPointError(ValueError):
    pass


@dataclass(frozen=True)
class SuitFrontDraftResult:
    points: dict
    derived_quantities: dict
    semantic_edges: list
    diagnostics: dict
    point_provenance: dict
    internal_edges: list
    # Reuse the exact prototype in downstream formal drafting.  Keeping this
    # object here is what prevents a second prototype_construction() call.
    prototype_result: object




def _leaf_value(value):
    """Read a native GarmentCode design leaf or a plain scalar."""
    if isinstance(value, dict) and "v" in value:
        return value["v"]
    return value


def resolve_suit_front_params(suit_params=None, *, front_config_path=FRONT_CONFIG):
    """Resolve the single current-value set used by the front draft.

    Priority is explicit design value -> component BASE fallback.  The fallback
    exists only so current callers remain reproducible; new dataset generation
    should always pass the values through ``design['suit']``.
    """
    cfg = yaml.safe_load(Path(front_config_path).read_text(encoding="utf-8"))
    defaults = cfg["drafting_parameters"]
    supplied = {} if suit_params is None else dict(suit_params)

    def get(name):
        if name in supplied:
            value = _leaf_value(supplied[name])
            if value is not None:
                return value, "design:suit"
        return defaults[name]["base"], "front_notched.yaml:base"

    garment_ratio, src_ratio = get("garment_length_ratio")
    overlap_M, src_overlap = get("overlap_M_cm")
    break_height, src_break = get("break_point_height_cm")
    button_spacing, src_button = get("button_spacing_cm")
    button_count, src_button_count = get("button_count")
    front_style, src_front_style = get("front_lower_edge_style")

    resolved = {
        "garment_length_ratio": float(garment_ratio),
        "overlap_M_cm": float(overlap_M),
        "break_point_height_cm": float(break_height),
        "button_spacing_cm": float(button_spacing),
        "button_count": int(button_count),
        "front_lower_edge_style": str(front_style),
    }
    sources = {
        "garment_length_ratio": src_ratio,
        "overlap_M_cm": src_overlap,
        "break_point_height_cm": src_break,
        "button_spacing_cm": src_button,
        "button_count": src_button_count,
        "front_lower_edge_style": src_front_style,
    }

    # All Stage-A1 ranges live in front_notched.yaml; Python consumes those
    # ranges instead of duplicating hard-coded limits.
    for name in (
        "garment_length_ratio", "overlap_M_cm",
        "break_point_height_cm", "button_spacing_cm",
    ):
        if "range" in defaults[name]:
            low, high = (float(v) for v in defaults[name]["range"])
            if not low <= resolved[name] <= high:
                raise ValueError(f"{name} outside confirmed range [{low}, {high}]")

    if resolved["button_count"] not in (1, 2):
        raise ValueError("button_count must be 1 or 2")
    if resolved["front_lower_edge_style"] not in ("curved", "straight"):
        raise ValueError("front_lower_edge_style must be curved or straight")

    return resolved, sources


def _distance(a, b):
    return math.hypot(b[0] - a[0], b[1] - a[1])


def _line_intersection(a, b, c, d):
    ax, ay = a
    bx, by = b
    cx, cy = c
    dx, dy = d
    det = (ax - bx) * (cy - dy) - (ay - by) * (cx - dx)
    if abs(det) < 1.0e-12:
        raise ValueError("drafting lines are parallel")
    n1 = ax * by - ay * bx
    n2 = cx * dy - cy * dx
    return [
        (n1 * (cx - dx) - (ax - bx) * n2) / det,
        (n1 * (cy - dy) - (ay - by) * n2) / det,
    ]


def _distance_on_ray(origin, through, distance):
    dx, dy = through[0] - origin[0], through[1] - origin[1]
    length = math.hypot(dx, dy)
    if length < 1.0e-12:
        raise ValueError("zero-length drafting ray")
    scale = float(distance) / length
    return [origin[0] + scale * dx, origin[1] + scale * dy]


def _chord_local_point(p0, p1, uv):
    return q_to_abs(p0, p1, uv)


class SuitFrontDraft:
    """Execute confirmed suit-front rules on a ThirdGenDraft prototype."""

    def __init__(self, third_gen_draft, front_config_path=FRONT_CONFIG):
        self.third_gen_draft = third_gen_draft
        self.front_config_path = Path(front_config_path)

    def build(
        self, *, suit_params=None, allow_frozen_base_fallback=False, variant="BASE"
    ):
        if allow_frozen_base_fallback and variant != "BASE":
            raise ValueError("frozen-only fallback is forbidden outside BASE")

        cfg = yaml.safe_load(self.front_config_path.read_text(encoding="utf-8"))
        resolved_params, parameter_sources = resolve_suit_front_params(
            suit_params, front_config_path=self.front_config_path
        )
        garment_ratio = resolved_params["garment_length_ratio"]
        prototype_result = self.third_gen_draft.prototype_construction(
            garment_length_ratio=garment_ratio
        )
        prototype = prototype_result.points
        unresolved = list(UNRESOLVED_SEMANTIC_POINTS + UNRESOLVED_UPSTREAM_POINTS)
        if not allow_frozen_base_fallback:
            joined = ", ".join(unresolved)
            raise UnresolvedDynamicPointError(f"UNRESOLVED_DYNAMIC_POINT: {joined}")

        points = {"v": list(prototype["v"]), "i": list(prototype["i"])}
        provenance = {
            "v": "ThirdGenDraft:audited_prototype_rule",
            "i": "ThirdGenDraft:audited_prototype_rule",
        }

        # Explicit BASE-only coordinates.  They are prerequisites or semantic
        # points with no confirmed dynamic rule, never an implicit success path.
        for name in UNRESOLVED_SEMANTIC_POINTS:
            points[name] = list(FRONT_POINTS[name])
            provenance[name] = "frozen-only:FRONT_POINTS"

        c, e = prototype["c"], prototype["e"]
        r, s = prototype["r"], prototype["s"]
        back_length = float(self.third_gen_draft.back_length)
        O = float(self.third_gen_draft.neck_width)

        overlap_M = resolved_params["overlap_M_cm"]
        break_height = resolved_params["break_point_height_cm"]
        button_spacing = resolved_params["button_spacing_cm"]
        button_count = resolved_params["button_count"]
        front_lower_edge_style = resolved_params["front_lower_edge_style"]

        r3 = [c[0] - overlap_M, c[1] + break_height]
        points["r3"] = r3
        provenance["r3"] = "SuitFrontDraft:confirmed_construction_rule"
        first_button = [r3[0] + overlap_M, r3[1]]
        if not math.isclose(first_button[0], c[0], rel_tol=0.0, abs_tol=1.0e-12):
            raise AssertionError("first_button_drafting_point.x must equal c.x")
        u1 = [first_button[0], first_button[1] - button_spacing]
        points["first_button_drafting_point"] = first_button
        points["u1"] = u1

        m2 = list(prototype["m2"])
        points["m2"] = m2
        garment_length = prototype_result.derived_quantities["garment_length_cm"]
        points["m3"] = list(prototype["m3"])

        m4 = [c[0], c[1] - (0.75 * back_length - 1.0)]
        t1 = [m4[0], m4[1] - 2.5]
        t2 = [t1[0] + 2.5, t1[1]]
        t3 = _line_intersection(points["r3"], t2, m4, points["m3"])
        beta = _distance(m4, t3)
        t4 = [t3[0] + beta, t3[1]]
        m5 = _line_intersection(
            [points["m1"][0], 0.0], [points["m1"][0], -1.0],
            m4, points["m3"],
        )
        m6 = _line_intersection(
            [points["m1"][0], 0.0], [points["m1"][0], -1.0], c, e,
        )
        t5 = [m5[0], m5[1] + 0.5]
        t6 = _distance_on_ray(t2, t5, 2.5 * beta)
        delta = prototype_result.derived_quantities["delta"]
        a1 = list(prototype["a1"])
        w = list(prototype["w"])
        a2 = [a1[0], a1[1] + 0.5]
        u3 = [u1[0] - 1.5, u1[1]]
        s8_uv = [0.3333333333333333, 0.0194195346414124]
        s8 = _chord_local_point(points["r3"], points["s5"], s8_uv)

        generated = {
            "a2": a2, "w": w, "t4": t4, "t6": t6, "u3": u3, "s8": s8,
        }
        for name, value in generated.items():
            points[name] = value
            provenance[name] = "SuitFrontDraft:confirmed_construction_rule"

        auxiliaries = {
            "c": c, "e": e, "r": r, "s": s,
            "m4": m4, "t1": t1, "t2": t2, "t3": t3,
            "m5": m5, "m6": m6, "t5": t5, "a1": a1,
        }
        points.update({name: list(value) for name, value in auxiliaries.items()})

        overrides = cfg["curve_overrides"]
        semantic_edges = []
        for template in EDGE_TEMPLATE:
            record = deepcopy(template)
            if record["kind"] == "curve":
                key = edge_key(record)
                frozen_q = overrides[key]
                record["c1"] = q_to_abs(points[record["p0"]], points[record["p1"]], frozen_q["q1"])
                record["c2"] = q_to_abs(points[record["p0"]], points[record["p1"]], frozen_q["q2"])
            semantic_edges.append(record)

        semantic_points = {name: points[name] for name in SEMANTIC_POINT_ORDER}
        fallback_semantic = [name for name in SEMANTIC_POINT_ORDER if provenance[name].startswith("frozen-only")]
        fully_dynamic_semantic = [
            name for name in SEMANTIC_POINT_ORDER
            if provenance[name].startswith(("ThirdGenDraft", "SuitFrontDraft"))
        ]
        diagnostics = {
            "variant": variant,
            "parameter_sources": parameter_sources,
            "resolved_design_parameters": deepcopy(resolved_params),
            "fallback_mode": "frozen-only" if allow_frozen_base_fallback else "disabled",
            "implicit_frozen_coordinate_fallback": False,
            "unresolved_dynamic_points": unresolved,
            "fully_dynamic_semantic_points": fully_dynamic_semantic,
            "rule_derived_from_frozen_upstream_points": [],
            "frozen_coordinate_fallback_points": fallback_semantic,
            "frozen_auxiliary_fallback_points": [],
            "third_gen_semantic_point_count": sum(
                value.startswith("ThirdGenDraft") for value in provenance.values()
            ),
            "suit_front_dynamic_semantic_point_count": sum(
                value.startswith("SuitFrontDraft") for value in provenance.values()
            ),
            "dynamic_rule_semantic_point_count": sum(
                not value.startswith("frozen-only") for name, value in provenance.items()
                if name in SEMANTIC_POINT_ORDER
            ),
            "frozen_coordinate_fallback_count": len(fallback_semantic),
            "curve_q_source": str(self.front_config_path),
            "curve_q_count": len(overrides),
            "drafting_buttons_separate_from_simulation": True,
            "formal_internal_dart_edge_kinds": ["straight"] * 4,
            "prototype_construction": {
                "stage": "prototype_construction",
                "point_records": deepcopy(prototype_result.point_records),
                "derived_quantities": deepcopy(prototype_result.derived_quantities),
                "curve_audit": deepcopy(prototype_result.curve_audit),
                "unresolved": list(prototype_result.diagnostics["prototype_construction_unresolved"]),
            },
            "no_global_prototype_to_suit_armhole_transform": True,
            "historical_suit_armhole_knots_are_formal_targets": False,
            "formal_armhole_derivation": "same_prototype_ws_geometry_plus_p5_p6_topology_split",
            "final_suit_derivation_unresolved": [],
            "final_suit_semantic_unresolved": list(UNRESOLVED_SEMANTIC_POINTS),
            "prototype_final_comparison_status": "NO_GLOBAL_TRANSFORM_BY_FORMAL_RULE",
        }
        return SuitFrontDraftResult(
            points=semantic_points,
            derived_quantities={
                "beta": beta,
                "delta": delta,
                "garment_length_cm": garment_length,
                "garment_length_ratio": garment_ratio,
                "overlap_M_cm": overlap_M,
                "break_point_height_cm": break_height,
                "button_spacing_cm": button_spacing,
                "button_count": button_count,
                "front_lower_edge_style": front_lower_edge_style,
                "first_button_drafting_point": first_button,
                "second_button_drafting_point": u1,
                "u1": u1,
                "m2": m2,
                "m3": points["m3"],
                "t2": t2,
            },
            semantic_edges=semantic_edges,
            diagnostics=diagnostics,
            point_provenance={name: provenance[name] for name in SEMANTIC_POINT_ORDER},
            internal_edges=deepcopy(FORMAL_INTERNAL_DART_EDGES),
            prototype_result=prototype_result,
        )
