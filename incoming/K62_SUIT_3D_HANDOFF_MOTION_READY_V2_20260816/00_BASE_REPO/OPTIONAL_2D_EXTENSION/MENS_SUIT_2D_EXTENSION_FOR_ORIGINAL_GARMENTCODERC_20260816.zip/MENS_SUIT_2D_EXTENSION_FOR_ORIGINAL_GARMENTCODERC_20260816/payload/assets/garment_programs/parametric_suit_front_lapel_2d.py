"""Stage A4 standalone parametric front-lapel 2-D Panel.

This adapter applies the current A4 2-D collar/lapel points to a COPY of the
already-passed A1/A2 draft result.  For peak lapels it additionally derives y3/y4/y5 using the 2026-08-12
formal construction rule; the replacement outer r3-y5-y3 curve reuses the old
notched r3-s8-s5 chord-local q-shape so the curvature character stays close to
the original s5-r3 opening.

It is intentionally NOT installed into FormalSuitAssemblyBase, so 3-D remains
untouched.
"""
from __future__ import annotations

from assets.garment_programs.suit_front_draft import SuitFrontDraftResult
from assets.garment_programs.suit_peak_lapel_geometry import (
    derive_peak_lapel_points,
    resolve_lapel_style,
)
from assets.garment_programs.formal_suit_front_panel import (
    FormalParametricSuitFrontPanel,
)


def apply_a4_lapel_points(
    front_draft_result,
    collar_lapel_draft_result,
    suit_params=None,
):
    points = {
        name: list(value)
        for name, value in front_draft_result.points.items()
    }
    provenance = dict(front_draft_result.point_provenance)

    for name, value in collar_lapel_draft_result.front_point_updates.items():
        points[name] = list(value)
        provenance[name] = "stage_a4_formal_collar_lapel_construction"

    diagnostics = dict(front_draft_result.diagnostics)
    diagnostics["stage_a4_lapel_points_applied"] = sorted(
        collar_lapel_draft_result.front_point_updates
    )

    lapel_style = resolve_lapel_style(suit_params)
    diagnostics["lapel_style"] = lapel_style

    # Common 2-D lapel-fold landmarks for BOTH notched and peak styles.
    # These points are internal semantic landmarks, not boundary changes and
    # not sewing interfaces.
    for name in ("r7", "r8", "s6", "s4"):
        points[name] = list(collar_lapel_draft_result.points[name])
        provenance[name] = "stage_a4_common_lapel_fold_semantic"

    parent_fold_edge = next(
        (
            dict(record)
            for record in collar_lapel_draft_result.boundary_records
            if record.get("source") == "a4_current_collar_r8_r5"
        ),
        None,
    )
    if parent_fold_edge is None:
        raise ValueError(
            "A4_LAPEL_FOLD_PARENT_CURVE_MISSING:a4_current_collar_r8_r5"
        )

    diagnostics["lapel_fold_semantic"] = {
        "point_chain": ["r7", "s6", "r3"],
        "upper_segment_kind": "curve",
        "lower_segment_kind": "straight",
        "collar_edge_reference": dict(parent_fold_edge),
        "upper_relation": "approx_equidistant_offset_of_curve",
        "offset_construction": "linear_endpoint_vector_field",
        "storage": "internal_features",
        "physics_status": "2D_SEMANTIC_ONLY",
    }

    if lapel_style == "peak":
        # Peak is a FRONT-BODY branch only.  The collar piece itself remains
        # exactly the existing A4 collar geometry.
        for name in ("s3", "s4"):
            points[name] = list(collar_lapel_draft_result.points[name])
            provenance[name] = "stage_a4_common_collar_lapel_construction"

        peak = derive_peak_lapel_points({
            "r3": points["r3"],
            "r5": points["r5"],
            "s3": points["s3"],
            "s4": points["s4"],
            "s5": points["s5"],
            "s6": points["s6"],
        })
        for name, value in peak.points.items():
            points[name] = list(value)
            provenance[name] = "stage_a4_peak_lapel_formal_construction"

        diagnostics["peak_lapel"] = {
            "derived_points": sorted(peak.points),
            "rules": dict(peak.diagnostics),
            "collar_piece_changed": False,
            "front_body_corner_topology": ["v", "r5", "s4", "y3", "r3"],
        }

    return SuitFrontDraftResult(
        points=points,
        derived_quantities=dict(front_draft_result.derived_quantities),
        semantic_edges=list(front_draft_result.semantic_edges),
        diagnostics=diagnostics,
        point_provenance=provenance,
        internal_edges=list(front_draft_result.internal_edges),
        prototype_result=front_draft_result.prototype_result,
    )


class ParametricSuitFrontLapel2DPanel(FormalParametricSuitFrontPanel):
    def __init__(
        self,
        name,
        formal_result,
        front_draft_result,
        collar_lapel_draft_result,
        *,
        button_count=None,
    ):
        self.a4_front_draft_result = apply_a4_lapel_points(
            front_draft_result,
            collar_lapel_draft_result,
        )
        super().__init__(
            name,
            formal_result,
            self.a4_front_draft_result,
            button_count=button_count,
        )
        self.semantic_points = {
            "r5": list(self.a4_front_draft_result.points["r5"]),
            "s4": list(self.a4_front_draft_result.points["s4"]),
        }
        self.stage_a4_report = {
            "two_d_only": True,
            "common_dynamic_front_points": ["r5", "s5", "s8"],
            "peak_derived_points": ["y3", "y4", "y5"],
            "peak_body_corner_topology": ["v", "r5", "s4", "y3", "r3"],
            "peak_outer_curve": ["r3", "y5", "y3"],
            "three_d_placement_applied": False,
            "warp_run": False,
        }
