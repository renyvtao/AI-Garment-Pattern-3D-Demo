"""Helpers for converting the adjusted sleeve geometry into PyGarment edges."""

from copy import deepcopy
import math
import pygarment as pyg


def shift_points(points, origin_name):
    ox, oy = points[origin_name]
    return {
        name: [float(x - ox), float(y - oy)]
        for name, (x, y) in points.items()
    }


def cubic_controls_from_bulge(start, end, bulge):
    dx = end[0] - start[0]
    dy = end[1] - start[1]
    length = math.hypot(dx, dy)
    if length < 1e-12:
        raise ValueError("Zero-length sleeve segment is not allowed")

    nx = -dy / length
    ny = dx / length

    c1 = [
        start[0] + dx / 3.0 + nx * bulge,
        start[1] + dy / 3.0 + ny * bulge,
    ]
    c2 = [
        start[0] + 2.0 * dx / 3.0 + nx * bulge,
        start[1] + 2.0 * dy / 3.0 + ny * bulge,
    ]
    return c1, c2


def curve_edge(vertices, segment, label=None):
    p0 = vertices[segment["p0"]]
    p1 = vertices[segment["p1"]]
    c1, c2 = cubic_controls_from_bulge(
        p0, p1, float(segment["bulge"])
    )
    return pyg.CurveEdge(
        start=p0,
        end=p1,
        control_points=[c1, c2],
        relative=False,
        label=label or segment.get("label", ""),
    )


def curve_sequence(vertices, segment_names, segment_table):
    seq = pyg.EdgeSequence()
    for name in segment_names:
        seq.append(
            curve_edge(vertices, segment_table[name], label=name)
        )
    return seq


def straight_edge(vertices, p0_name, p1_name, label=""):
    return pyg.Edge(
        start=vertices[p0_name],
        end=vertices[p1_name],
        label=label,
    )


def semantic_vertex_coords(vertices, names):
    return {name: deepcopy(vertices[name]) for name in names}
