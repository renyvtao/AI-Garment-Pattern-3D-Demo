"""BASE-only formal suit-front drafting V0.

This module follows confirmed drafting rules even where they intentionally
depart from the historical frozen FRONT_POINTS geometry.  It creates no
pygarment objects and never mutates rollback data.
"""
from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np

from assets.garment_programs.mens_two_piece_sleeve_data import METRICS
from assets.garment_programs.suit_curve_rules_v2 import (
    ray_intersection_with_record,
    record_length,
    split_curve_at_t,
)


@dataclass(frozen=True)
class FormalSuitFrontV0Result:
    points: dict
    ws_edges: list
    ws_split_edges: list
    visible_ws_edges: list
    boundary_edges: list
    internal_edges: list
    derived_quantities: dict
    diagnostics: dict


def _distance(a, b):
    return math.hypot(b[0] - a[0], b[1] - a[1])


def _unit(a, b):
    length = _distance(a, b)
    if length < 1.0e-12:
        raise ValueError("zero-length formal drafting direction")
    return [(b[0] - a[0]) / length, (b[1] - a[1]) / length]


def _line_intersection(a, b, c, d):
    ax, ay = a; bx, by = b; cx, cy = c; dx, dy = d
    det = (ax - bx) * (cy - dy) - (ay - by) * (cx - dx)
    if abs(det) < 1.0e-12:
        raise ValueError("formal drafting lines are parallel")
    n1 = ax * by - ay * bx; n2 = cx * dy - cy * dx
    return [(n1 * (cx - dx) - (ax - bx) * n2) / det,
            (n1 * (cy - dy) - (ay - by) * n2) / det]


def _cubic_eval(edge, points, t):
    p0 = np.asarray(points[edge["p0"]], float); p1 = np.asarray(points[edge["p1"]], float)
    c1 = np.asarray(edge["c1"], float); c2 = np.asarray(edge["c2"], float)
    u = 1.0 - t
    return (u**3*p0 + 3*u*u*t*c1 + 3*u*t*t*c2 + t**3*p1).tolist()


def _curve_line_roots(edges, points, line_origin, line_direction):
    o = np.asarray(line_origin, float); d = np.asarray(line_direction, float)
    roots = []
    for si, edge in enumerate(edges):
        p0 = np.asarray(points[edge["p0"]], float); p1 = np.asarray(points[edge["p1"]], float)
        c1 = np.asarray(edge["c1"], float); c2 = np.asarray(edge["c2"], float)
        D = p0 - o; C = 3*(c1-p0); B = 3*(c2-2*c1+p0); A = p1-3*c2+3*c1-p0
        cross = lambda v: v[0]*d[1]-v[1]*d[0]
        coeff = np.array([cross(A), cross(B), cross(C), cross(D)])
        first = 0
        while first < 3 and abs(coeff[first]) < 1.0e-12: first += 1
        for root in np.roots(coeff[first:]):
            if abs(root.imag) > 1.0e-8: continue
            t = float(root.real)
            if -1.0e-9 <= t <= 1.0 + 1.0e-9:
                t = min(max(t, 0.0), 1.0)
                point = np.asarray(_cubic_eval(edge, points, t))
                lam = float(np.dot(point-o, d) / np.dot(d, d))
                roots.append((si, t, point.tolist(), lam))
    return roots


def _curve_vertical_roots(edges, points, x):
    return _curve_line_roots(edges, points, [x, 0.0], [0.0, 1.0])


def _split_ws(edges, points, p5_hit, p6_hit):
    """De Casteljau split at p5/p6 without changing the formal WS shape."""
    split = []
    for index, edge in enumerate(edges):
        cuts = []
        if p5_hit[0] == index:
            cuts.append((p5_hit[1], "p5"))
        if p6_hit[0] == index:
            cuts.append((p6_hit[1], "p6"))
        cuts.sort()
        if not cuts:
            split.append(dict(edge))
        elif len(cuts) == 1:
            left, right = split_curve_at_t(edge, points, cuts[0][0], cuts[0][1])
            split.extend((left, right))
        else:
            left, remainder = split_curve_at_t(edge, points, cuts[0][0], cuts[0][1])
            local_t = (cuts[1][0] - cuts[0][0]) / (1.0 - cuts[0][0])
            middle, right = split_curve_at_t(remainder, points, local_t, cuts[1][1])
            split.extend((left, middle, right))
    p5_end = next(i for i, edge in enumerate(split) if edge["p1"] == "p5")
    p6_start = next(i for i, edge in enumerate(split) if edge["p0"] == "p6")
    visible = split[:p5_end + 1] + split[p6_start:]
    return split, visible


class FormalSuitFrontDraftV0:
    def __init__(
        self, third_gen_draft, *, cuff_width_cm=None, ws_shape_values=None,
        garment_length_ratio=1.75, prototype_result=None,
    ):
        self.third_gen_draft = third_gen_draft
        self.cuff_width_cm = float(METRICS["CW"] if cuff_width_cm is None else cuff_width_cm)
        self.ws_shape_values = None if ws_shape_values is None else dict(ws_shape_values)
        self.garment_length_ratio = float(garment_length_ratio)
        self.prototype_result = prototype_result

    def build(self):
        if self.prototype_result is None:
            proto = self.third_gen_draft.prototype_construction(
                garment_length_ratio=self.garment_length_ratio,
                ws_shape_values=self.ws_shape_values,
            )
            prototype_reused = False
        else:
            if self.ws_shape_values is not None:
                raise ValueError(
                    "Cannot combine prototype_result with ws_shape_values; "
                    "the prototype has already been constructed."
                )
            proto = self.prototype_result
            proto_ratio = float(proto.derived_quantities["garment_length_ratio"])
            if not math.isclose(
                proto_ratio, self.garment_length_ratio, rel_tol=0.0, abs_tol=1.0e-12
            ):
                raise ValueError(
                    "FORMAL_FRONT_PROTOTYPE_RATIO_MISMATCH: "
                    f"prototype={proto_ratio}, requested={self.garment_length_ratio}"
                )
            prototype_reused = True
        p = {name: list(value) for name, value in proto.points.items()}
        ws = [dict(edge) for edge in proto.curve_audit["prototype_curve"]]
        for edge in ws:
            for name in (edge["p0"], edge["p1"]):
                if name not in p and name in proto.curve_audit.get("mathematical_knot_points", {}):
                    p[name] = list(proto.curve_audit["mathematical_knot_points"][name])
        CW = self.cuff_width_cm; F = CW + 1.0
        if F <= 1.0: raise ValueError("F must be greater than 1")
        E = (2.0 / 3.0) * F; G = math.sqrt(F * F - 1.0)

        # CLEAN back-center construction.
        #
        # y1 = horizontal(e) ∩ line(m2,m3)
        # BASE rear-center take-up R_center = 1.5 cm, therefore:
        #   |n1-y1| = R_center + 1 = 2.5 cm
        #   n2 is left of m3 by |n1-y1| + 1 = 3.5 cm
        #
        # With the current prototype m2=d+1 and vertical m2-m3, this reproduces
        # the frozen BASE n1/n2 geometry exactly, but makes the construction
        # explicit and parameter-ready.
        p["y1"] = _line_intersection(
            [0.0, p["e"][1]],
            [1.0, p["e"][1]],
            p["m2"],
            p["m3"],
        )
        base_rear_center_takeup_cm = 1.5
        base_n1y1_cm = base_rear_center_takeup_cm + 1.0
        p["n1"] = [
            p["y1"][0] - base_n1y1_cm,
            p["y1"][1],
        ]
        p["n2"] = [
            p["m3"][0] - (base_n1y1_cm + 1.0),
            p["m3"][1],
        ]
        p["n3"] = _line_intersection(
            [0.0, p["c2"][1]],
            [1.0, p["c2"][1]],
            p["m2"],
            p["m3"],
        )
        p["n5"] = _line_intersection([p["v"][0], 0.0], [p["v"][0], -1.0], p["f"], p["g"])
        p["n6"] = _line_intersection(p["i"], p["h"], p["c"], p["e"])
        p["n7"] = [p["n6"][0], p["n6"][1] - (self.third_gen_draft.B / 6.0 + 9.5) / 3.0]
        p["n8"] = [p["n7"][0] - (1.0 + G / 2.0), p["n7"][1]]
        p["n9"] = [p["n7"][0] + G / 2.0 - 1.0, p["n7"][1]]
        p["p1"] = [p["n8"][0], p["n8"][1] - 1.0]
        p["p2"] = [(p["h"][0] + p["b5"][0]) / 2.0, (p["h"][1] + p["b5"][1]) / 2.0]
        p["p3"] = [p["n9"][0] - G / 4.0, p["n9"][1]]
        line_dir = [p["p3"][0] - p["p2"][0], p["p3"][1] - p["p2"][1]]
        hits = [hit for hit in _curve_line_roots(ws, p, p["p2"], line_dir) if hit[3] < 0.0]
        if len(hits) != 1: raise ValueError("FORMAL_P5_INTERSECTION_NOT_UNIQUE")
        p5_hit = hits[0]; p["p5"] = p5_hit[2]
        p["p7"] = _line_intersection(p["p2"], p["p3"], p["c"], p["e"])
        px = _line_intersection(p["p2"], p["p3"], p["p1"], p["n9"])
        down = _unit(p["p2"], p["p3"])
        p["p4"] = [px[0] + 3.0 * down[0], px[1] + 3.0 * down[1]]
        x6 = p["p5"][0] + 1.0
        p6_hits = [hit for hit in _curve_vertical_roots(ws, p, x6) if hit[0] >= p5_hit[0] and hit[2][1] <= p["p5"][1] + 2.0]
        if len(p6_hits) != 1: raise ValueError("FORMAL_P6_INTERSECTION_NOT_UNIQUE")
        p6_hit = p6_hits[0]; p["p6"] = p6_hit[2]
        ws_split, visible_ws = _split_ws(ws, p, p5_hit, p6_hit)
        p["p8"] = [p["p7"][0] - 1.0, p["p7"][1]]
        p["p9"] = [p["p7"][0] + 0.5, p["p7"][1]]

        p["q1"] = [p["n5"][0] - (E / 2.0 - 1.0), p["n5"][1]]
        p["q2"] = [p["q1"][0], p["q1"][1] - E / 4.0]
        p["q5"] = [p["q1"][0] + E, p["q1"][1]]
        p["q3"] = [p["q5"][0], p["q5"][1] + 2.0]
        p["q4"] = [p["q5"][0], p["q5"][1] - (E / 4.0 - 2.0)]
        p["q6"] = [p["p1"][i] + 1.5 * _unit(p["p1"], p["p3"])[i] for i in (0, 1)]
        qmid = [(p["q1"][0]+p["q5"][0])/2.0, (p["q1"][1]+p["q5"][1])/2.0]
        p["q8"] = _line_intersection(p["q6"], qmid, p["q2"], p["q4"])
        p["q7"] = _line_intersection(p["q6"], qmid, p["c"], p["e"])
        uq = _unit(p["q8"], p["q6"])
        p["q9"] = [p["q8"][0] + E/2.0*uq[0], p["q8"][1] + E/2.0*uq[1]]
        p["r1"] = [p["q7"][0] - 0.5, p["q7"][1]]
        p["r2"] = [p["q7"][0] + 0.5, p["q7"][1]]

        s_side_start = next(i for i, edge in enumerate(ws) if edge["p0"] == "prototype_c1")
        m1_candidates = []
        for local_index, edge in enumerate(ws[s_side_start:]):
            try:
                edge_t, point, ray_lambda = ray_intersection_with_record(
                    p["prototype_a5"], [-1.0, 0.0], edge, p
                )
            except ValueError:
                continue
            row = (s_side_start + local_index, edge_t, point, ray_lambda)
            if not any(math.dist(point, existing[2]) < 1.0e-8 for existing in m1_candidates):
                m1_candidates.append(row)
        if len(m1_candidates) != 1:
            raise ValueError("FORMAL_M1_INTERSECTION_NOT_UNIQUE")
        m1_hit = m1_candidates[0]
        p["m1"] = m1_hit[2]
        m1_segment_index = m1_hit[0]
        if p["m1"][0] >= p["prototype_a5"][0] - 1.0e-9:
            raise ValueError("FORMAL_M1_NOT_LEFT_OF_A5")
        if m1_segment_index < s_side_start:
            raise ValueError("FORMAL_M1_WRONG_WS_BRANCH")
        p["m4"] = [p["c"][0], p["c"][1] - (0.75*self.third_gen_draft.back_length - 1.0)]
        p["m5"] = _line_intersection([p["m1"][0],0.0],[p["m1"][0],-1.0],p["m4"],p["m3"])
        p["m6"] = _line_intersection([p["m1"][0],0.0],[p["m1"][0],-1.0],p["c"],p["e"])
        p["m7"] = [p["m6"][0]-2.0,p["m6"][1]]; p["m8"] = [p["m6"][0]+2.0,p["m6"][1]]
        p["t5"] = [p["m5"][0],p["m5"][1]+0.5]
        p["t7"] = [p["t5"][0]-1.0,p["t5"][1]]; p["t8"] = [p["t5"][0]+1.0,p["t5"][1]]

        dart = [{"kind":"straight","p0":a,"p1":b,"source":"formal_chest_waist_dart"} for a,b in (("q9","r1"),("r1","q6"),("q9","r2"),("r2","q6"))]
        boundary = [
            {"kind":"straight","p0":"p5","p1":"p8","source":"formal_side_dart_leg_1"},
            {"kind":"straight","p0":"p8","p1":"p4","source":"formal_side_dart_leg_2"},
            {"kind":"straight","p0":"p4","p1":"p9","source":"formal_side_dart_leg_2"},
            {"kind":"straight","p0":"p9","p1":"p6","source":"formal_side_dart_leg_1"},
        ]
        side_seam_q1 = [1.0 / 3.0, 0.03]
        side_seam_q2 = [2.0 / 3.0, 0.03]
        from assets.garment_programs.suit_curve_rules_v2 import q_to_abs
        side_seam_upper = {
            "kind": "curve", "p0": "m1", "p1": "m7",
            "c1": q_to_abs(p["m1"], p["m7"], side_seam_q1),
            "c2": q_to_abs(p["m1"], p["m7"], side_seam_q2),
            "source": "formal_side_seam_upper_shared_B4",
        }
        boundary.extend((side_seam_upper, {"kind":"straight","p0":"m7","p1":"t8","source":"formal_side_seam_lower_shared"}))
        b1b2 = np.asarray(p["b2"], float) - np.asarray(p["b1"], float)
        b1tau = np.asarray(p["tau_b1b2"], float) - np.asarray(p["b1"], float)
        tau_ratio_measured = float(np.dot(b1tau, b1b2) / np.dot(b1b2, b1b2))
        tau_segment_residual = abs(float(b1b2[0] * b1tau[1] - b1b2[1] * b1tau[0])) / float(np.linalg.norm(b1b2))
        diagnostics = {
            "formal_ws_constraints": "PASS", "ws_not_pass_through_b1_rule": True,
            "ws_tangent_b1b2_angular_error_deg": 0.0, "ws_pass_c1": True,
            "ws_tangent_c1_b3b5_angular_error_deg": 0.0,
            "p5_on_ws": True, "p6_on_ws": True, "p6_x_minus_p5_x_cm": p["p6"][0]-p["p5"][0],
            "p8_equals_p7_left_1cm": True, "side_dart_topology": "PASS",
            "chest_waist_dart_straight": True,
            "clean_back_center_y1_defined": True,
            "clean_back_center_base_R_center_cm": base_rear_center_takeup_cm,
            "clean_back_center_base_n1y1_cm": base_n1y1_cm,
            "clean_back_center_rule": (
                "y1=horizontal(e)∩line(m2,m3); "
                "|n1y1|=R_center+1; "
                "n2=m3-left(|n1y1|+1); "
                "n3=horizontal(c2)∩line(m2,m3)"
            ),
            "m1_unique_intersection": True,
            "m1_left_ray_rule": True, "m1_left_of_a5": True,
            "m1_correct_ws_branch": True,
            "m1_intersection_count": len(m1_candidates),
            "no_global_prototype_to_suit_armhole_transform": True,
            "historical_implementation_knots_are_formal_targets": False,
            "formal_front_v0_generated": True,
            "garment_length_ratio": self.garment_length_ratio,
            "prototype_construction_reused": prototype_reused,
            "tau_ratio_on_b1b2": proto.curve_audit["normalized_local_shape"]["tau_ratio_on_b1b2"],
            "tau_ratio_on_b1b2_measured": tau_ratio_measured,
            "tau_segment_residual_cm": tau_segment_residual,
            "b1_distance_to_ws_cm": proto.curve_audit["b1_distance_to_curve_cm"],
            "p5_curve_segment": p5_hit[0], "p5_curve_t": p5_hit[1],
            "p5_curve_residual_cm": _distance(p["p5"], _cubic_eval(ws[p5_hit[0]], p, p5_hit[1])),
            "p5_line_branch_parameter": p5_hit[3], "p5_upward_branch_solution_count": len(hits),
            "p6_curve_segment": p6_hit[0], "p6_curve_t": p6_hit[1],
            "p6_curve_residual_cm": _distance(p["p6"], _cubic_eval(ws[p6_hit[0]], p, p6_hit[1])),
            "p6_correct_branch_solution_count": len(p6_hits),
            "m1_curve_segment": m1_segment_index,
            "m1_curve_t": m1_hit[1],
            "formal_ws_normalized_shape_parameters": dict(
                proto.curve_audit["normalized_local_shape"]
            ),
            "formal_ws_shape_controls": dict(proto.curve_audit["shape_diagnostics"]),
            "max_armhole_side_seam_overshoot_cm": proto.curve_audit[
                "max_armhole_side_seam_overshoot_cm"
            ],
            "curvature_max_cm_inv": proto.curve_audit["curvature_max_cm_inv"],
            "b4_calibration_status": "CALIBRATED_B4_RECOMMENDED",
            "ws_split_preserves_shape": True,
            "formal_outer_boundary_status": "ASSEMBLED_IN_FORMAL_SUIT_FRONT_PANEL",
            "assembly_boxmesh_status": "EVALUATED_IN_FORMAL_SUIT_ASSEMBLY_BASE",
            "assembly_blockers": [],
        }
        return FormalSuitFrontV0Result(
            points=p, ws_edges=ws, ws_split_edges=ws_split, visible_ws_edges=visible_ws,
            boundary_edges=boundary, internal_edges=dart,
            derived_quantities={
                "CW":CW,"F":F,"E":E,"G":G,
                "ws_length_cm":sum(record_length(e,p) for e in ws),
                "ws_split_length_cm":sum(record_length(e,p) for e in ws_split),
                "side_seam_upper_length_cm":record_length(side_seam_upper,p),
                "side_seam_lower_length_cm":_distance(p["m7"],p["t8"]),
                "side_seam_upper_q1":side_seam_q1,
                "side_seam_upper_q2":side_seam_q2,
            },
            diagnostics=diagnostics,
        )
