"""Stage A4 CURRENT — exact 2-D collar/lapel construction rules.

This file supersedes the earlier A4 local-shape fallback implementation.

Latest confirmed rules
----------------------
Front/lapel:
- r3 is the lapel/break point; A1 already resolves:
      r3.x = c.x - M
      break_point_height in [-2,+3] cm, downward negative.
- Extend the auxiliary line w-v through v toward upper-left:
      |r4-v| = BCW.
- Connect r4-r3.
- ux is the fixed B88 revised construction line.
  Historical audited rule:
      x is vertically O/2 below v.
- Through v draw the line parallel to r4-r3; intersect ux -> r5.
      r5-v || r4-r3.
- s6 = intersection(r4-r3, ux).

Back/collar:
- BN = mm2 = CURRENT back-neckline arc length.
- r6-v construction remains the historical vertical one:
      r6 = v + [0, BN].
- Extend v-r5 upward beyond v by BN:
      |v-r7| = BN.
- X = |r6-r7|.
- Latest user rule for r8:
      |r7-r8| = X + 1
      |v-r8|  = BN
      choose the RIGHT-SIDE circle intersection.
  This supersedes the historical editor's strictly-horizontal r8 rule.

Widths:
- FCW = BCW + 1.
- CPW = FCW + point_width_delta.
- point_width_delta in [-0.5,+0.5], default 0.
- default CPW = FCW.
- LPW = CPW + 0.5 (historical verified relation retained).
- s6-s5 length = 3*LPW (historical verified relation retained).
- s5 lies on the ux extension away from r5:
      s5 = s6 + unit(s6-r5) * (3*LPW).
- s4 lies from s5 toward r5 by LPW:
      s4 = s5 + unit(r5-s5) * LPW.
- |s3-s4| = CPW.
- angle(s3,s4,s5) in [75,90], default 90.
  The upper-left/topological branch is selected.

Collar half:
- s1/s2 remain on the left normal to v-r8:
      |r8-s1| = BCW
      |s1-s2| = FCW.
- Whole collar mirrors about r8-s2.

Important scope
---------------
- 2-D only.
- The active 3-D collar in FormalSuitAssemblyBase is NOT replaced.
- No Warp, torso-wrap, attachment, 3-D fold, KE/KD/corridor, q-debug control.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import math

import numpy as np

from assets.garment_programs.suit_curve_rules_v2 import (
    abs_cp_to_q,
    q_to_abs,
    record_length,
)
from assets.garment_programs.suit_pattern_data import (
    BACK_EDGES,
    BACK_POINTS,
    COLLAR_EDGES,
    COLLAR_POINTS,
    FRONT_POINTS,
)

EPS = 1.0e-10

# Current body_mapping is still disabled.  The active frozen suit front uses
# the B88-revised v/w coordinate frame.  Therefore A4 keeps the audited ux
# construction line from that same frame instead of silently mixing in a
# different body-mapped prototype frame.
UX_REFERENCE_U = np.asarray([0.0, -7.833333333333333], dtype=float)
UX_REFERENCE_X = np.asarray(
    [9.833333333333332, -3.9166666666666665], dtype=float
)


class CollarLapelValidationError(ValueError):
    pass


@dataclass(frozen=True)
class ResolvedCollarLapelParams:
    BCW_cm: float
    FCW_cm: float
    point_width_delta_cm: float
    CPW_cm: float
    LPW_cm: float
    collar_point_angle_s3_s4_s5_deg: float


@dataclass(frozen=True)
class SuitCollarLapelDraftResult:
    points: dict
    boundary_records: list
    construction_points: dict
    front_point_updates: dict
    derived_quantities: dict
    diagnostics: dict


def _leaf(value):
    if isinstance(value, dict) and "v" in value:
        return value["v"]
    return value


def resolve_collar_lapel_params(suit_params):
    supplied = {} if suit_params is None else dict(suit_params)

    def value(name, fallback=None):
        if name not in supplied:
            return fallback
        return _leaf(supplied[name])

    if "BN_cm" in supplied and value("BN_cm") is not None:
        raise CollarLapelValidationError(
            "BN_IS_DERIVED_ONLY: BN = mm2 = current back-neckline arc length"
        )

    bcw_raw = value("back_collar_width_BCW_cm", 2.5)
    if bcw_raw is None:
        bcw_raw = 2.5
    BCW = float(bcw_raw)
    if not 2.2 <= BCW <= 2.9:
        raise CollarLapelValidationError(
            "back_collar_width_BCW_cm outside confirmed range [2.2, 2.9]"
        )

    FCW = BCW + 1.0

    delta_raw = value("point_width_delta_cm", 0.0)
    angle_raw = value("collar_point_angle_s3_s4_s5_deg", 90.0)
    if delta_raw is None:
        delta_raw = 0.0
    if angle_raw is None:
        angle_raw = 90.0

    delta = float(delta_raw)
    angle = float(angle_raw)

    if not -0.5 <= delta <= 0.5:
        raise CollarLapelValidationError(
            "point_width_delta_cm outside confirmed range [-0.5, 0.5]"
        )
    if not 75.0 <= angle <= 90.0:
        raise CollarLapelValidationError(
            "collar_point_angle_s3_s4_s5_deg outside confirmed range [75, 90]"
        )

    CPW = FCW + delta
    LPW = CPW + 0.5

    return ResolvedCollarLapelParams(
        BCW_cm=BCW,
        FCW_cm=FCW,
        point_width_delta_cm=delta,
        CPW_cm=CPW,
        LPW_cm=LPW,
        collar_point_angle_s3_s4_s5_deg=angle,
    )


def _arr(p):
    return np.asarray(p, dtype=float)


def _distance(a, b):
    return float(np.linalg.norm(_arr(b) - _arr(a)))


def _unit_vec(v):
    v = _arr(v)
    n = float(np.linalg.norm(v))
    if n <= EPS:
        raise CollarLapelValidationError("zero-length drafting direction")
    return v / n


def _unit(a, b):
    return _unit_vec(_arr(b) - _arr(a))


def _cross2(a, b):
    a = _arr(a)
    b = _arr(b)
    return float(a[0] * b[1] - a[1] * b[0])


def _line_intersection(a, b, c, d):
    """Intersection of infinite lines a-b and c-d."""
    a, b, c, d = map(_arr, (a, b, c, d))
    v = b - a
    w = d - c
    den = _cross2(v, w)
    if abs(den) <= EPS:
        raise CollarLapelValidationError("drafting lines are parallel")
    t = _cross2(c - a, w) / den
    return (a + t * v).tolist()


def _rotate(v, angle_deg):
    a = math.radians(float(angle_deg))
    c, s = math.cos(a), math.sin(a)
    x, y = _arr(v)
    return np.asarray([c * x - s * y, s * x + c * y], dtype=float)


def _reflect_point(point, axis_a, axis_b):
    p = _arr(point)
    a = _arr(axis_a)
    d = _unit(axis_a, axis_b)
    proj = a + d * float(np.dot(p - a, d))
    return (2.0 * proj - p).tolist()


def _angle_deg(a, b, c):
    u = _unit(b, a)
    v = _unit(b, c)
    dot = min(1.0, max(-1.0, float(np.dot(u, v))))
    return math.degrees(math.acos(dot))


def _circle_circle_intersections(c0, r0, c1, r1):
    c0 = _arr(c0)
    c1 = _arr(c1)
    r0 = float(r0)
    r1 = float(r1)
    dvec = c1 - c0
    d = float(np.linalg.norm(dvec))

    if d <= EPS:
        raise CollarLapelValidationError("coincident r8 circle centers")
    if d > r0 + r1 + 1.0e-9:
        raise CollarLapelValidationError("R8_CIRCLES_DISJOINT_EXTERNAL")
    if d < abs(r0 - r1) - 1.0e-9:
        raise CollarLapelValidationError("R8_CIRCLES_DISJOINT_INTERNAL")

    a = (r0*r0 - r1*r1 + d*d) / (2.0*d)
    h2 = r0*r0 - a*a
    if h2 < -1.0e-8:
        raise CollarLapelValidationError("R8_CIRCLE_INTERSECTION_NUMERIC_FAIL")
    h = math.sqrt(max(0.0, h2))

    p = c0 + a * dvec / d
    perp = np.asarray([-dvec[1], dvec[0]], dtype=float) / d
    return [
        (p + h * perp).tolist(),
        (p - h * perp).tolist(),
    ]


def _choose_right_point(candidates, origin):
    origin = _arr(origin)
    rows = sorted(
        candidates,
        key=lambda p: (float(p[0]), float(p[1])),
        reverse=True,
    )
    best = rows[0]
    if float(best[0]) <= float(origin[0]) + 1.0e-10:
        raise CollarLapelValidationError(
            "R8_RIGHT_SIDE_INTERSECTION_NOT_FOUND"
        )
    return list(best)


def _back_neckline_records(records):
    wanted = {"neckline_back_1", "d_p", "p_m"}
    selected = [r for r in records if r.get("source") in wanted]
    if len(selected) != 3:
        raise CollarLapelValidationError(
            "BACK_NECKLINE_MM2_SOURCE_NOT_UNIQUE"
        )
    order = {"neckline_back_1": 0, "d_p": 1, "p_m": 2}
    selected.sort(key=lambda r: order[r["source"]])
    return selected


def derive_mm2(back_points, back_records):
    return float(sum(
        record_length(r, back_points)
        for r in _back_neckline_records(back_records)
    ))


def _dynamic_s8(r3, s5):
    # Historical verified construction:
    # s7 = 1/3 from r3 toward s5; s8 is 0.5 cm normal offset,
    # taking the candidate with smaller x.
    r3 = _arr(r3)
    s5 = _arr(s5)
    s7 = r3 + (s5 - r3) / 3.0
    vv = s5 - r3
    pp = _unit_vec([vv[1], -vv[0]])
    a = s7 + 0.5 * pp
    b = s7 - 0.5 * pp
    return (a if a[0] < b[0] else b).tolist()


# Preserve only curve *shape* in q-space.  All semantic endpoints are dynamic.
_BASE_Q_R8_R5 = {
    "q1": abs_cp_to_q(
        COLLAR_POINTS["r8"], COLLAR_POINTS["r5"], COLLAR_EDGES[0]["c1"]
    ),
    "q2": abs_cp_to_q(
        COLLAR_POINTS["r8"], COLLAR_POINTS["r5"], COLLAR_EDGES[0]["c2"]
    ),
}


def _solve_r8_r5_normal_q(p0, p1, q_along, target_cm, q_initial):
    """Solve one shared chord-normal q for the r8->r5 cubic.

    Endpoints and along fractions remain fixed.  The solve is deliberately
    bounded and deterministic so both mirrored collar halves use the same
    construction relation rather than hand-authored control-point coordinates.
    """
    if target_cm <= 0.0:
        raise CollarLapelValidationError("nonpositive collar r5-r8 target arc")

    def make_record(qn):
        return {
            "kind": "curve", "p0": "r8", "p1": "r5",
            "c1": q_to_abs(p0, p1, [q_along[0], qn]),
            "c2": q_to_abs(p0, p1, [q_along[1], qn]),
        }

    def f(qn):
        return record_length(make_record(qn), {"r8": p0, "r5": p1}) - target_cm

    lo, hi = float(q_initial), float(q_initial)
    flo = f(lo)
    if abs(flo) <= 1.0e-12:
        return lo
    step = 0.01
    for _ in range(80):
        hi -= step
        if f(hi) * flo <= 0.0:
            break
        step *= 1.35
    else:
        raise CollarLapelValidationError(
            "unable to bracket collar r5-r8 arc target with fixed endpoints"
        )
    fhi = f(hi)
    for _ in range(100):
        mid = 0.5 * (lo + hi)
        fm = f(mid)
        if abs(fm) <= 1.0e-12:
            return mid
        if flo * fm <= 0.0:
            hi, fhi = mid, fm
        else:
            lo, flo = mid, fm
    return 0.5 * (lo + hi)
_BASE_Q_S3_S2 = {
    "q1": abs_cp_to_q(
        COLLAR_POINTS["s3"], COLLAR_POINTS["s2"], COLLAR_EDGES[3]["c1"]
    ),
    "q2": abs_cp_to_q(
        COLLAR_POINTS["s3"], COLLAR_POINTS["s2"], COLLAR_EDGES[3]["c2"]
    ),
}


class SuitCollarLapelDraft:
    def build(
        self,
        *,
        front_draft_result,
        back_points,
        back_records,
        suit_params,
    ):
        resolved = resolve_collar_lapel_params(suit_params)

        fp = front_draft_result.points
        for name in ("r3", "v", "w"):
            if name not in fp:
                raise CollarLapelValidationError(
                    f"missing current front point: {name}"
                )

        r3 = _arr(fp["r3"])
        v = _arr(fp["v"])
        w = _arr(fp["w"])
        u = UX_REFERENCE_U.copy()
        x = UX_REFERENCE_X.copy()

        BN = derive_mm2(back_points, back_records)

        # r4: extend w-v through v toward upper-left by BCW.
        r4 = v + resolved.BCW_cm * _unit(w, v)

        # r5: through v draw a line parallel to r4-r3; intersect ux.
        r5 = _arr(_line_intersection(
            v,
            v + (r3 - r4),
            u,
            x,
        ))

        # s6: r4-r3 intersect ux.
        s6 = _arr(_line_intersection(r4, r3, u, x))

        # r6-v construction remains unchanged: vertical above v by BN.
        r6 = v + np.asarray([0.0, BN], dtype=float)

        # r7: extend r5-v upward beyond v by BN.
        r7 = v + BN * _unit(r5, v)

        # X is a derived length.
        X = _distance(r6, r7)

        # Latest r8 rule:
        # |r7-r8| = X+1, |v-r8| = BN, choose the right-side intersection.
        r8_candidates = _circle_circle_intersections(
            r7, X + 1.0, v, BN
        )
        r8 = _arr(_choose_right_point(r8_candidates, r7))

        # Close the collar r5-r8 arc to the actual front-neckline plus
        # back-neckline construction length.  Endpoints remain the geometric
        # r8/r5 authorities; only the shared chord-normal Bezier parameter is
        # solved, then mirrored for the opposite half.
        front_neck_records = [
            rec for rec in front_draft_result.semantic_edges
            if rec.get("source") == "neckline_front"
        ]
        back_neck_records = [
            rec for rec in back_records
            if rec.get("source") in {"neckline_back_1", "d_p", "p_m"}
        ]
        # The formal 27L front-neckline authority is the r5->v segment used
        # by the assembled front panel.  Do not include the lapel_to_neck
        # helper record when deriving the collar r5-r8 target.
        # A4 updates the formal front r5 to this collar construction r5;
        # use that same semantic endpoint before building the final panel.
        front_neck_arc = _distance(r5, v)
        back_neck_arc = sum(record_length(rec, back_points) for rec in back_neck_records)
        target_r5r8_arc = front_neck_arc + back_neck_arc
        r8_r5_q_normal = _solve_r8_r5_normal_q(
            r8, r5, (1.0 / 3.0, 2.0 / 3.0), target_r5r8_arc,
            _BASE_Q_R8_R5["q1"][1],
        )

        # s1/s2: left normal of v-r8.
        axis = r8 - v
        left_normal = _unit_vec([-axis[1], axis[0]])
        if left_normal[0] > 0.0:
            left_normal = -left_normal
        s1 = r8 + resolved.BCW_cm * left_normal
        s2 = s1 + resolved.FCW_cm * left_normal

        # Historical verified length chain retained:
        # LPW=CPW+0.5, |s6-s5|=3*LPW.
        # Direction is the ux extension AWAY from r5, matching the original
        # construction and the user's "extension from u" semantics.
        s5 = s6 + (3.0 * resolved.LPW_cm) * _unit(r5, s6)
        s4 = s5 + resolved.LPW_cm * _unit(s5, r5)

        # Latest direct CPW + angle construction.
        # Two branches satisfy the angle; choose the upper/topological branch,
        # then smaller x as deterministic tie-break.
        ref = _unit(s4, s5)
        ang = resolved.collar_point_angle_s3_s4_s5_deg
        cand_a = s4 + resolved.CPW_cm * _rotate(ref, +ang)
        cand_b = s4 + resolved.CPW_cm * _rotate(ref, -ang)
        s3 = max(
            (cand_a, cand_b),
            key=lambda p: (float(p[1]), -float(p[0])),
        )

        s8 = _arr(_dynamic_s8(r3, s5))

        points = {
            "r8": r8.tolist(),
            "r5": r5.tolist(),
            "s1": s1.tolist(),
            "s2": s2.tolist(),
            "s3": s3.tolist(),
            "s4": s4.tolist(),
            "s5": s5.tolist(),
            "s6": s6.tolist(),
            "s8": s8.tolist(),
            "r3": r3.tolist(),
            "r4": r4.tolist(),
            "r6": r6.tolist(),
            "r7": r7.tolist(),
            "u": u.tolist(),
            "x": x.tolist(),
            "v": v.tolist(),
            "w": w.tolist(),
        }

        for name in ("r5", "s3", "s4"):
            points[name + "_mirror"] = _reflect_point(
                points[name], points["r8"], points["s2"]
            )

        r8_r5 = {
            "kind": "curve",
            "p0": "r8",
            "p1": "r5",
            "c1": q_to_abs(
                points["r8"], points["r5"], [1.0 / 3.0, r8_r5_q_normal]
            ),
            "c2": q_to_abs(
                points["r8"], points["r5"], [2.0 / 3.0, r8_r5_q_normal]
            ),
            "source": "a4_current_collar_r8_r5",
            "semantic_group": "attach_right",
        }
        r8_r5_arc_before = record_length(
            {**r8_r5, "c1": q_to_abs(points["r8"], points["r5"], _BASE_Q_R8_R5["q1"]),
             "c2": q_to_abs(points["r8"], points["r5"], _BASE_Q_R8_R5["q2"])},
            points,
        )
        r8_r5_arc_after = record_length(r8_r5, points)
        s3_s2 = {
            "kind": "curve",
            "p0": "s3",
            "p1": "s2",
            "c1": q_to_abs(
                points["s3"], points["s2"], _BASE_Q_S3_S2["q1"]
            ),
            "c2": q_to_abs(
                points["s3"], points["s2"], _BASE_Q_S3_S2["q2"]
            ),
            "source": "a4_current_collar_s3_s2",
            "semantic_group": "outer_right",
        }

        def reflect_cp(cp):
            return _reflect_point(cp, points["r8"], points["s2"])

        mirror_s2_s3 = {
            "kind": "curve",
            "p0": "s2",
            "p1": "s3_mirror",
            "c1": reflect_cp(s3_s2["c2"]),
            "c2": reflect_cp(s3_s2["c1"]),
            "source": "a4_current_mirror_collar_s3_s2",
            "semantic_group": "outer_left",
        }
        mirror_r5_r8 = {
            "kind": "curve",
            "p0": "r5_mirror",
            "p1": "r8",
            "c1": reflect_cp(r8_r5["c2"]),
            "c2": reflect_cp(r8_r5["c1"]),
            "source": "a4_current_reverse_mirror_collar_r8_r5",
            "semantic_group": "attach_left",
        }

        boundary = [
            r8_r5,
            {
                "kind": "straight", "p0": "r5", "p1": "s4",
                "source": "a4_current_r5_s4",
                "semantic_group": "outer_right",
            },
            {
                "kind": "straight", "p0": "s4", "p1": "s3",
                "source": "a4_current_s4_s3",
                "semantic_group": "outer_right",
            },
            s3_s2,
            mirror_s2_s3,
            {
                "kind": "straight",
                "p0": "s3_mirror", "p1": "s4_mirror",
                "source": "a4_current_mirror_s3_s4",
                "semantic_group": "outer_left",
            },
            {
                "kind": "straight",
                "p0": "s4_mirror", "p1": "r5_mirror",
                "source": "a4_current_mirror_s4_r5",
                "semantic_group": "outer_left",
            },
            mirror_r5_r8,
        ]

        derived = {
            "mm2_back_neckline_arc_cm": BN,
            "BN_cm": BN,
            "BCW_cm": resolved.BCW_cm,
            "FCW_cm": resolved.FCW_cm,
            "point_width_delta_cm": resolved.point_width_delta_cm,
            "CPW_cm": _distance(s3, s4),
            "LPW_cm": _distance(s5, s4),
            "s6_s5_cm": _distance(s6, s5),
            "collar_point_angle_s3_s4_s5_deg": _angle_deg(
                s3, s4, s5
            ),
            "r4_v_cm": _distance(r4, v),
            "v_r7_cm": _distance(v, r7),
            "v_r6_cm": _distance(v, r6),
            "r6_r7_X_cm": X,
            "r7_r8_cm": _distance(r7, r8),
            "v_r8_cm": _distance(v, r8),
            "collar_r5r8_arc_before_cm": r8_r5_arc_before,
            "collar_r5r8_arc_target_cm": target_r5r8_arc,
            "collar_front_neck_arc_cm": front_neck_arc,
            "collar_back_neck_arc_cm": back_neck_arc,
            "collar_r5r8_arc_after_cm": r8_r5_arc_after,
            "collar_r5r8_q_normal": r8_r5_q_normal,
            "collar_r5r8_arc_delta_cm": r8_r5_arc_after - r8_r5_arc_before,
            "collar_r5r8_internal_neck_breakpoint_present": False,
            "r8_s1_cm": _distance(r8, s1),
            "s1_s2_cm": _distance(s1, s2),
            "r5_on_ux_cross": abs(_cross2(r5 - u, x - u)),
            "s6_on_ux_cross": abs(_cross2(s6 - u, x - u)),
            "s5_on_ux_cross": abs(_cross2(s5 - u, x - u)),
            "parallel_cross_r5v_r4r3": abs(
                _cross2(v - r5, r3 - r4)
            ),
        }

        diagnostics = {
            "stage": "A4_COLLAR_LAPEL_2D_CURRENT_RULES",
            "CPW_rule": "CPW = FCW + point_width_delta",
            "FCW_rule": "FCW = BCW + 1",
            "point_width_delta_default_cm": 0.0,
            "collar_point_angle_default_deg": 90.0,
            "LPW_rule": "LPW = CPW + 0.5",
            "s6_s5_rule": "|s6-s5| = 3*LPW",
            "BN_source": "current_back_neckline_arc_mm2",
            "BN_is_independent_design_parameter": False,
            "ux_reference": "audited_B88_revised_u_x_while_body_mapping_disabled",
            "r4_rule": "extend w-v through v; |r4-v|=BCW",
            "r5_rule": "intersection(ux, line_through_v_parallel_r4r3)",
            "s6_rule": "intersection(ux, line_r4_r3)",
            "r6_rule": "historical unchanged construction: r6=v+[0,BN]",
            "r7_rule": "extend r5-v beyond v; |v-r7|=BN",
            "X_rule": "X=|r6-r7|",
            "r8_rule": (
                "right circle intersection satisfying "
                "|r7-r8|=X+1 and |v-r8|=BN"
            ),
            "historical_horizontal_r8_rule_superseded": True,
            "s3_branch": "higher-y/topological branch",
            "whole_piece_scaling_used": False,
            "arbitrary_semantic_point_dragging_used": False,
            "three_d_modified": False,
            "warp_run": False,
            "active_3d_assembly_collar_replaced": False,
        }

        return SuitCollarLapelDraftResult(
            points=points,
            boundary_records=boundary,
            construction_points={
                k: points[k]
                for k in (
                    "r3", "r4", "r5", "r6", "r7", "r8",
                    "s1", "s2", "s3", "s4", "s5", "s6", "s8",
                    "u", "x", "v", "w",
                )
            },
            # These are the front-lapel semantic points that must replace
            # the old frozen front values in the A4 2-D adapter.
            front_point_updates={
                "r5": points["r5"],
                "s5": points["s5"],
                "s8": points["s8"],
            },
            derived_quantities=derived,
            diagnostics=diagnostics,
        )
