"""Helpers for fixed-geometry suit panels."""

import pygarment as pyg


def localize_points(points, origin_name):
    ox, oy = points[origin_name]
    return {
        name: [float(x - ox), float(y - oy)]
        for name, (x, y) in points.items()
    }


def abs_cp_to_relative(start, end, cp):
    dx = end[0] - start[0]
    dy = end[1] - start[1]
    l2 = dx * dx + dy * dy
    if l2 < 1e-12:
        return [0.5, 0.0]

    px, py = -dy, dx
    vx = cp[0] - start[0]
    vy = cp[1] - start[1]

    return [
        float((vx * dx + vy * dy) / l2),
        float((vx * px + vy * py) / l2),
    ]


def make_edge(vertices, record, original_points):
    p0_name, p1_name = record["p0"], record["p1"]
    p0, p1 = vertices[p0_name], vertices[p1_name]

    if record["kind"] == "straight":
        return pyg.Edge(
            p0,
            p1,
            label=record.get("source", ""),
        )

    rel1 = abs_cp_to_relative(
        original_points[p0_name],
        original_points[p1_name],
        record["c1"],
    )
    rel2 = abs_cp_to_relative(
        original_points[p0_name],
        original_points[p1_name],
        record["c2"],
    )

    return pyg.CurveEdge(
        p0,
        p1,
        [rel1, rel2],
        label=record.get("source", ""),
    )


def make_sequence(vertices, records, original_points):
    seq = pyg.EdgeSequence()
    for record in records:
        seq.append(make_edge(vertices, record, original_points))
    return seq
