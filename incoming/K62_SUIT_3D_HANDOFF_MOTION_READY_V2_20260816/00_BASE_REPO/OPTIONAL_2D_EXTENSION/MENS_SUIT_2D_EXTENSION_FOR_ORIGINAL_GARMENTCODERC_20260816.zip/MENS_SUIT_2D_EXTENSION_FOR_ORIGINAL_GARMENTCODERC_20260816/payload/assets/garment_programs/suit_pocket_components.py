# -*- coding: utf-8 -*-
r"""CLEAN men's suit pocket semantics (line-only version).

Rules landed on 2026-08-12
--------------------------
1. Small pocket uses q1-q3-q4-q2 and exists on the LEFT front only.
2. Large pocket uses p1-n9 and exists on BOTH fronts.
3. Both pocket types are display lines only.
4. If the corresponding design parameter is disabled, nothing is drawn.
5. No extra cloth panel is created and no interior stitch is created here.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import numpy as np
import pygarment as pyg


def _leaf(value):
    if isinstance(value, dict) and "v" in value:
        return value["v"]
    return value


def _bool_param(suit, name, default=True):
    if name not in suit:
        return bool(default)
    v = _leaf(suit[name])
    if isinstance(v, str):
        return v.lower() in ("1", "true", "yes", "on")
    return bool(v)


def _pocket_flag(suit, name, nested_name):
    """Resolve a flat render switch, honoring the global pockets.enabled gate."""
    pockets = suit.get("pockets", {}) if isinstance(suit, dict) else {}
    global_enabled = _bool_param(pockets, "enabled", True)
    if not global_enabled:
        return False
    if name in suit:
        return _bool_param(suit, name, True)
    return _bool_param(pockets.get(nested_name, {}), "enabled", True)


def _arr(v):
    return np.asarray(v, dtype=float)


def _dist(a, b):
    return float(np.linalg.norm(_arr(b) - _arr(a)))


@dataclass(frozen=True)
class PocketDesignFlags:
    small_pocket_enabled: bool
    large_pockets_enabled: bool


class SuitPocketComponent(pyg.Component):
    """Semantic-only pocket subsystem added on top of the frozen CLEAN suit body."""

    def __init__(self, name, formal_points, suit_params):
        super().__init__(name)
        flags = PocketDesignFlags(
            small_pocket_enabled=_pocket_flag(suit_params, "small_pocket_enabled", "small"),
            large_pockets_enabled=_pocket_flag(suit_params, "large_pockets_enabled", "big"),
        )
        self.flags = flags
        self.formal_points = deepcopy(formal_points)
        self.subs = []
        self.interfaces = {}
        self.attachment_semantics = {}

        if flags.small_pocket_enabled:
            needed = ("q1", "q3", "q4", "q2")
            missing = [p for p in needed if p not in formal_points]
            if missing:
                raise ValueError(f"SMALL_POCKET_MISSING_FORMAL_POINTS: {missing}")
            self.attachment_semantics["small_left"] = {
                "enabled": True,
                "side": "left",
                "kind": "line_outline_only",
                "line_loop_order": ["q1", "q3", "q4", "q2", "q1"],
                "target_polygon_2d": {k: list(map(float, formal_points[k])) for k in needed},
                "active_stitch": False,
                "real_panel_created": False,
                "display_only": True,
            }

        if flags.large_pockets_enabled:
            if "p1" not in formal_points or "n9" not in formal_points:
                raise ValueError("LARGE_POCKET_MISSING_P1_N9")
            p1 = list(map(float, formal_points["p1"]))
            n9 = list(map(float, formal_points["n9"]))
            for side in ("left", "right"):
                self.attachment_semantics[f"large_{side}"] = {
                    "enabled": True,
                    "side": side,
                    "kind": "line_segment_only",
                    "source_line": ["p1", "n9"],
                    "source_line_2d": [p1, n9],
                    "length_cm": _dist(p1, n9),
                    "mirror_in_physical_assembly": side == "right",
                    "active_stitch": False,
                    "real_panel_created": False,
                    "display_only": True,
                }

        self.stage_report = {
            "small_pocket_enabled": flags.small_pocket_enabled,
            "large_pockets_enabled": flags.large_pockets_enabled,
            "small_pocket_side": "left",
            "large_pocket_sides": ["left", "right"],
            "small_real_panel_count": 0,
            "large_real_panel_count": 0,
            "small_line_outline_count": 1 if flags.small_pocket_enabled else 0,
            "large_mouth_line_count": 2 if flags.large_pockets_enabled else 0,
            "small_pocket_left_rendered": flags.small_pocket_enabled,
            "large_pocket_left_rendered": flags.large_pockets_enabled,
            "large_pocket_right_rendered": flags.large_pockets_enabled,
            "projection_contract": "RENDER_ONLY_NEAREST_SURFACE__NOT_PHYSICAL_POCKET_ATTACHMENT",
            "active_interior_stitches_created": False,
            "front_body_topology_modified": False,
            "3d_modified": False,
            "warp_run": False,
        }


def build_suit_pockets(formal_result, suit_params, name="clean_suit_pockets"):
    return SuitPocketComponent(name, formal_result.points, suit_params)
