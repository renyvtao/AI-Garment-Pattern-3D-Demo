"""Semantic directed Bézier helpers for GarmentCodeRC suit parametric V2.

Important design rule:
- Geometry is not changed by whole-piece scaling or arbitrary point dragging.
- Curve intent is stored in chord-local normalized q1/q2 coordinates.
- When semantic endpoints move, control points are rebuilt from the new chord.
"""
from __future__ import annotations

from copy import deepcopy
import math
import numpy as np


_EPS = 1e-12


def _p2(v):
    a = np.asarray(v, dtype=float)
    if a.shape != (2,):
        a = a.reshape(-1)[:2]
    return a


def q_to_abs(p0, p1, q):
    """Convert chord-local normalized q=(along, normal) to absolute 2D point."""
    a = _p2(p0)
    b = _p2(p1)
    q = _p2(q)
    v = b - a
    if float(np.dot(v, v)) < _EPS:
        return a.tolist()
    perp = np.array([-v[1], v[0]], dtype=float)
    return (a + q[0] * v + q[1] * perp).tolist()


def abs_cp_to_q(p0, p1, cp):
    """Convert absolute control point to chord-local normalized q."""
    a = _p2(p0)
    b = _p2(p1)
    c = _p2(cp)
    v = b - a
    n2 = float(np.dot(v, v))
    if n2 < _EPS:
        return [0.5, 0.0]
    perp = np.array([-v[1], v[0]], dtype=float)
    w = c - a
    return [float(np.dot(w, v) / n2), float(np.dot(w, perp) / n2)]


def edge_key(record):
    """Stable directed semantic key: p0->p1|source."""
    p0 = record.get("p0", "?")
    p1 = record.get("p1", "?")
    src = record.get("source")
    return f"{p0}->{p1}|{src}" if src else f"{p0}->{p1}"


def reverse_record(record):
    r = deepcopy(record)
    r["p0"], r["p1"] = r["p1"], r["p0"]
    if r.get("kind") == "curve":
        r["c1"], r["c2"] = deepcopy(r["c2"]), deepcopy(r["c1"])
    src = r.get("source")
    if src:
        r["source"] = f"reverse({src})"
    return r


def find_oriented_record(records, p0, p1):
    for rec in records:
        if rec.get("p0") == p0 and rec.get("p1") == p1:
            return deepcopy(rec)
    for rec in records:
        if rec.get("p0") == p1 and rec.get("p1") == p0:
            return reverse_record(rec)
    raise KeyError(f"Cannot find edge {p0}->{p1}")


def _override_for(overrides, rec):
    if not overrides:
        return {}
    candidates = [
        edge_key(rec),
        rec.get("source"),
        f"{rec.get('p0')}->{rec.get('p1')}",
    ]
    for k in candidates:
        if k and k in overrides:
            val = overrides[k]
            return val if isinstance(val, dict) else {}
    # Compatibility: editor patch may be nested by panel; caller should normally
    # pass one panel mapping, but tolerate one extra level.
    for v in overrides.values():
        if isinstance(v, dict):
            for k in candidates:
                if k and k in v and isinstance(v[k], dict):
                    return v[k]
    return {}


def apply_curve_overrides(base_points, records, new_points, overrides=None):
    """Rebuild curves on new endpoints while preserving/overriding q1/q2."""
    out = []
    for rec0 in records:
        rec = deepcopy(rec0)
        if rec.get("kind") != "curve":
            out.append(rec)
            continue

        p0, p1 = rec["p0"], rec["p1"]
        if p0 not in new_points or p1 not in new_points:
            raise KeyError(f"Missing new endpoint(s) for {edge_key(rec)}")

        # Baseline q comes from the baseline chord when available. For newly
        # derived records whose endpoints only exist in new_points, use current
        # geometry as the baseline.
        bp0 = base_points.get(p0, new_points[p0])
        bp1 = base_points.get(p1, new_points[p1])

        q1 = abs_cp_to_q(bp0, bp1, rec["c1"])
        q2 = abs_cp_to_q(bp0, bp1, rec["c2"])
        ov = _override_for(overrides or {}, rec)
        if "q1" in ov:
            q1 = ov["q1"]
        if "q2" in ov:
            q2 = ov["q2"]

        rec["c1"] = q_to_abs(new_points[p0], new_points[p1], q1)
        rec["c2"] = q_to_abs(new_points[p0], new_points[p1], q2)
        out.append(rec)
    return out


def _bezier_points(rec, points):
    a = _p2(points[rec["p0"]])
    b = _p2(points[rec["p1"]])
    if rec.get("kind") == "curve":
        c1 = _p2(rec["c1"])
        c2 = _p2(rec["c2"])
        return a, c1, c2, b
    return a, None, None, b


def sample_record(record, points, n=80):
    n = max(int(n), 2)
    a, c1, c2, b = _bezier_points(record, points)
    t = np.linspace(0.0, 1.0, n)
    if record.get("kind") != "curve":
        return (1.0 - t[:, None]) * a + t[:, None] * b
    u = 1.0 - t
    return (
        (u**3)[:, None] * a
        + (3*u*u*t)[:, None] * c1
        + (3*u*t*t)[:, None] * c2
        + (t**3)[:, None] * b
    )


def record_length(record, points, samples=240):
    q = sample_record(record, points, samples)
    d = np.diff(q, axis=0)
    return float(np.linalg.norm(d, axis=1).sum())


def path_length(records, points):
    return float(sum(record_length(r, points) for r in records))


def retarget_curve_endpoint(record, base_points, new_points, new_p1, source=None):
    """Retarget p1 to a semantic point, preserving chord-local q1/q2."""
    rec = deepcopy(record)
    old_p0, old_p1 = rec["p0"], rec["p1"]
    if rec.get("kind") == "curve":
        q1 = abs_cp_to_q(base_points[old_p0], base_points[old_p1], rec["c1"])
        q2 = abs_cp_to_q(base_points[old_p0], base_points[old_p1], rec["c2"])
    rec["p1"] = new_p1
    if source is not None:
        rec["source"] = source
    if rec.get("kind") == "curve":
        rec["c1"] = q_to_abs(new_points[old_p0], new_points[new_p1], q1)
        rec["c2"] = q_to_abs(new_points[old_p0], new_points[new_p1], q2)
    return rec


def split_curve_at_t(record, points, t, split_name):
    """Split a straight/cubic record by De Casteljau; writes split point."""
    t = float(t)
    if not (0.0 <= t <= 1.0):
        raise ValueError(f"t must be in [0,1], got {t}")
    p0 = _p2(points[record["p0"]])
    p1 = _p2(points[record["p1"]])

    if record.get("kind") != "curve":
        s = (1.0 - t) * p0 + t * p1
        points[split_name] = s.tolist()
        a = {"kind": "straight", "p0": record["p0"], "p1": split_name,
             "source": f"{record.get('source','edge')}:left"}
        b = {"kind": "straight", "p0": split_name, "p1": record["p1"],
             "source": f"{record.get('source','edge')}:right"}
        return a, b

    c1 = _p2(record["c1"])
    c2 = _p2(record["c2"])
    q0 = (1-t)*p0 + t*c1
    q1 = (1-t)*c1 + t*c2
    q2 = (1-t)*c2 + t*p1
    r0 = (1-t)*q0 + t*q1
    r1 = (1-t)*q1 + t*q2
    s = (1-t)*r0 + t*r1
    points[split_name] = s.tolist()
    src = record.get("source", "curve")
    left = {"kind":"curve","p0":record["p0"],"p1":split_name,
            "c1":q0.tolist(),"c2":r0.tolist(),"source":f"{src}:left"}
    right = {"kind":"curve","p0":split_name,"p1":record["p1"],
             "c1":r1.tolist(),"c2":q2.tolist(),"source":f"{src}:right"}
    return left, right


def _cubic_power_coeffs(p0, c1, c2, p1):
    # B(t) = A*t^3 + B*t^2 + C*t + D
    D = p0
    C = 3.0*(c1-p0)
    B = 3.0*(c2-2.0*c1+p0)
    A = p1 - 3.0*c2 + 3.0*c1 - p0
    return A, B, C, D


def ray_intersection_with_record(origin, direction, record, points):
    """Intersect ray O+lambda*d (lambda>=0) with a straight/cubic edge.

    Returns (edge_t, point_list, ray_lambda).
    """
    o = _p2(origin)
    d = _p2(direction)
    dd = float(np.dot(d, d))
    if dd < _EPS:
        raise ValueError("Ray direction is zero")

    def cross2(a, b):
        return float(a[0]*b[1] - a[1]*b[0])

    p0 = _p2(points[record["p0"]])
    p1 = _p2(points[record["p1"]])

    candidates = []
    if record.get("kind") != "curve":
        # Solve o + lam*d = p0 + t*(p1-p0)
        e = p1 - p0
        M = np.column_stack((d, -e))
        det = float(np.linalg.det(M))
        if abs(det) < _EPS:
            raise ValueError(f"Ray is parallel to {edge_key(record)}")
        lam, t = np.linalg.solve(M, p0-o)
        if -1e-9 <= t <= 1+1e-9 and lam >= -1e-9:
            t = min(max(float(t), 0.0), 1.0)
            lam = max(float(lam), 0.0)
            pt = p0 + t*e
            return t, pt.tolist(), lam
        raise ValueError(f"No forward ray intersection with {edge_key(record)}")

    c1 = _p2(record["c1"])
    c2 = _p2(record["c2"])
    A, B, C, D = _cubic_power_coeffs(p0, c1, c2, p1)
    # cross(B(t)-o, d) == 0
    coeff = np.array([
        cross2(A, d),
        cross2(B, d),
        cross2(C, d),
        cross2(D-o, d),
    ], dtype=float)
    # Remove leading numerical zeros.
    first = 0
    while first < len(coeff)-1 and abs(coeff[first]) < 1e-12:
        first += 1
    roots = np.roots(coeff[first:])
    for rr in roots:
        if abs(float(np.imag(rr))) > 1e-8:
            continue
        t = float(np.real(rr))
        if -1e-8 <= t <= 1.0+1e-8:
            t = min(max(t, 0.0), 1.0)
            u = 1.0-t
            pt = u**3*p0 + 3*u*u*t*c1 + 3*u*t*t*c2 + t**3*p1
            lam = float(np.dot(pt-o, d) / dd)
            residual = float(np.linalg.norm((o+lam*d)-pt))
            if lam >= -1e-8 and residual < 1e-5:
                candidates.append((max(lam,0.0), t, pt))
    if not candidates:
        raise ValueError(f"No forward ray intersection with {edge_key(record)}")
    candidates.sort(key=lambda x: x[0])
    lam, t, pt = candidates[0]
    return float(t), pt.tolist(), float(lam)
