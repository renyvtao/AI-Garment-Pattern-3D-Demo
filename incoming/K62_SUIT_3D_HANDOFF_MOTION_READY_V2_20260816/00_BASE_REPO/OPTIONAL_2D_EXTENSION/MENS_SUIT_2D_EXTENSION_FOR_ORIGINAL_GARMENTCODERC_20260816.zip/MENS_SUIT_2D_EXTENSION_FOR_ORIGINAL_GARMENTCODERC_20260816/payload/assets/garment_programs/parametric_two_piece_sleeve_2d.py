"""FINAL CLEAN real 2-D pygarment panels for the parametric sleeve.

No placement, mirroring-to-body, ruffle, cap fit, internal seam engineering,
or Warp behavior is copied from the active frozen V18 sleeve.
"""
from __future__ import annotations

import pygarment as pyg

from assets.garment_programs.sleeve_curve_utils import shift_points
from assets.garment_programs.suit_curve_rules_v2 import q_to_abs


def _curve_edge(vertices, segment, label):
    p0 = vertices[segment["p0"]]
    p1 = vertices[segment["p1"]]
    c1 = q_to_abs(p0, p1, segment["q1"])
    c2 = q_to_abs(p0, p1, segment["q2"])
    return pyg.CurveEdge(
        start=p0,
        end=p1,
        control_points=[c1, c2],
        relative=False,
        label=label,
    )


def _group(vertices, names, table):
    seq = pyg.EdgeSequence()
    for name in names:
        seq.append(_curve_edge(vertices, table[name], name))
    return seq


class ParametricMensBigSleeve2DPanel(pyg.Panel):
    def __init__(self, name, draft):
        super().__init__(name)
        self.draft = draft
        self.original_points = draft.points
        self.vertices = shift_points(draft.points, "e1")
        self.edges = pyg.EdgeSequence()
        self.edge_groups = {}

        for group_name, segment_names in draft.big_boundary_groups:
            group = _group(self.vertices, segment_names, draft.segments)
            self.edge_groups[group_name] = group
            self.edges.append(group)

        self.interfaces = {
            key: pyg.Interface(self, self.edge_groups[key])
            for key in (
                "cap_e1_d3",
                "seam_d3_j1",
                "cuff_j1_j2",
                "seam_j2_f3",
                "cap_f3_e1",
            )
        }
        self.stage_a5_report = {
            "two_d_only": True,
            "three_d_placement_applied": False,
            "warp_run": False,
        }


class ParametricMensSmallSleeve2DPanel(pyg.Panel):
    def __init__(self, name, draft):
        super().__init__(name)
        self.draft = draft
        self.original_points = draft.points
        self.vertices = shift_points(draft.points, "k5")
        self.edges = pyg.EdgeSequence()
        self.edge_groups = {}

        for group_name, segment_names in draft.small_boundary_groups:
            # FINAL CLEAN: small cuff is a real draft segment.
            # The accepted curve q is frozen in sleeve_curve_shapes_clean.yaml.
            group = _group(self.vertices, segment_names, draft.segments)
            self.edge_groups[group_name] = group
            self.edges.append(group)

        self.interfaces = {
            key: pyg.Interface(self, self.edge_groups[key])
            for key in (
                "cap_k5_c2",
                "seam_c2_j1",
                "cuff_j1_k6",
                "seam_k6_k5",
            )
        }
        self.stage_a5_report = {
            "two_d_only": True,
            "three_d_placement_applied": False,
            "warp_run": False,
        }


class ParametricMensTwoPieceSleeve2D(pyg.Component):
    """A5 2-D pair.

    Stitch semantics are exposed but intentionally not turned into active
    Stitches here: the existing V18 uses ruffle/orientation engineering
    controls, which are outside the design-parameter layer.
    """
    def __init__(self, name, draft):
        super().__init__(name)
        self.draft = draft
        self.big_sleeve = ParametricMensBigSleeve2DPanel(
            f"{name}_big", draft
        )
        self.small_sleeve = ParametricMensSmallSleeve2DPanel(
            f"{name}_small", draft
        )
        self.subs = [self.big_sleeve, self.small_sleeve]

        self.stitch_semantics = {
            "internal_1": (
                self.big_sleeve.interfaces["seam_d3_j1"],
                self.small_sleeve.interfaces["seam_c2_j1"],
            ),
            "internal_2": (
                self.big_sleeve.interfaces["seam_j2_f3"],
                self.small_sleeve.interfaces["seam_k6_k5"],
            ),
        }

        self.stage_a5_report = {
            "two_d_only": True,
            "active_internal_stitches_created": False,
            "reason": (
                "V18 ruffle/orientation values are engineering controls and "
                "are not promoted into the A5 design layer"
            ),
            "three_d_placement_applied": False,
            "warp_run": False,
        }
