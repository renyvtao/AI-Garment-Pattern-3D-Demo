"""Stage A6 — unified men's suit 2-D design executor.

Goal
====
One body + one design mapping
    -> ONE ThirdGenDraft
    -> ONE SuitFrontDraft
    -> ONE FormalSuitFrontDraftV0
    -> waist parameterization
    -> A4 collar/lapel construction
    -> A4 front-lapel semantic point update
    -> four/six-panel body topology
    -> FINAL current 2-D AH = front interface - |p5-p6| + back
    -> A5 two-piece sleeve drafting
    -> canonical real pygarment 2-D components
    -> parameter_trace

This file does NOT:
- instantiate FormalSuitAssemblyBase;
- replace the active 3-D collar/front/sleeve;
- apply torso wrap / placement / attachments;
- promote V18 ruffle or 3-D engineering controls;
- run Warp.

A6 is an orchestration/execution stage, not an A7 formula-recovery stage.
Known A5 source-required fallbacks remain explicitly visible in the trace.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from typing import Any
import math

import pygarment as pyg

from assets.garment_programs.mens_third_gen_basic_block import ThirdGenDraft
from assets.garment_programs.suit_front_draft import SuitFrontDraft
from assets.garment_programs.formal_suit_front_v0 import FormalSuitFrontDraftV0
from assets.garment_programs.suit_waist_draft import apply_waist_ease
from assets.garment_programs.formal_suit_front_panel import (
    FormalParametricSuitFrontPanel,
)
from assets.garment_programs.formal_suit_back_panel import (
    FormalSuitBackPanel,
    build_formal_back_geometry,
)
from assets.garment_programs.suit_six_panel_geometry import (
    build_six_panel_geometry,
)
from assets.garment_programs.formal_suit_six_panel import FormalSixPanelFront

from assets.garment_programs.suit_collar_lapel_draft import SuitCollarLapelDraft
from assets.garment_programs.parametric_suit_collar_2d import (
    ParametricSuitCollar2DPanel,
)
from assets.garment_programs.parametric_suit_front_lapel_2d import (
    apply_a4_lapel_points,
)

from assets.garment_programs.suit_two_piece_sleeve_draft_a5 import (
    SuitTwoPieceSleeveDraft,
)
from assets.garment_programs.parametric_two_piece_sleeve_2d import (
    ParametricMensTwoPieceSleeve2D,
)


A6_CONNECTED_DESIGN_PARAMETERS = {
    "lapel_style": {
        "range": ["notched", "peak"],
        "stage": "A4-Peak",
        "effect": "front-body collar/lapel boundary style; collar piece unchanged",
    },
    "garment_length_ratio": {
        "range": [1.70, 1.80],
        "stage": "A1",
        "effect": "front/body garment length",
    },
    "overlap_M_cm": {
        "range": [1.8, 2.2],
        "stage": "A1/A4",
        "effect": "r3 break point horizontal position -> lapel chain",
    },
    "break_point_height_cm": {
        "range": [-2.0, 3.0],
        "stage": "A1/A4",
        "effect": "r3 vertical position -> r5/r7/r8/s6/s5/s4/s3",
    },
    "button_spacing_cm": {
        "range": [8.0, 10.0],
        "stage": "A1/A2",
        "effect": "button_2 drafting point",
    },
    "button_count": {
        "range": [1, 2],
        "stage": "A2",
        "effect": "button interface topology",
    },
    "front_lower_edge_style": {
        "range": ["curved", "straight"],
        "stage": "A2/A3",
        "effect": "lower front-opening boundary sources",
    },
    "body_panel_layout": {
        "range": ["four_panel", "six_panel"],
        "stage": "A3",
        "effect": "front topology: dart vs princess seam",
    },
    "waist_ease_cm": {
        "range": [11.0, 19.0],
        "stage": "A2",
        "effect": "waist take-up; null preserves frozen BASE waist",
        "nullable": True,
    },
    "back_collar_width_BCW_cm": {
        "range": [2.2, 2.9],
        "stage": "A4",
        "effect": "r4/r5/r7/r8 + collar widths",
    },
    "point_width_delta_cm": {
        "range": [-0.5, 0.5],
        "stage": "A4",
        "effect": "CPW=FCW+delta; LPW and s5/s4/s3",
    },
    "collar_point_angle_s3_s4_s5_deg": {
        "range": [75.0, 90.0],
        "stage": "A4",
        "effect": "s3 collar point direction",
    },
    "sleeve_length_reduction_X_cm": {
        "range": [0.5, 1.5],
        "stage": "A5",
        "effect": "S=arm_length-X -> sleeve lower length",
    },
    "sleeve_cap_reduction_cm": {
        "range": [3.0, 4.0],
        "stage": "A5",
        "default": 4.0,
        "effect": "|b1d3|=AH/2-cap_reduction",
    },
}

KNOWN_SOURCE_REQUIRED = [
    # A5 sleeve helper-point construction is now fully rule-driven from
    # the current mens prototype.  Remaining curve shape is deliberately
    # editable/freezeable and is not a missing point-construction rule.
]

NON_DESIGN_ENGINEERING_EXCLUSIONS = [
    "q1/q2 debug engineering controls",
    "3D placement / torso wrap",
    "attachment labels",
    "lapel lay-back / collar roll",
    "Warp solver/material parameters",
    "V18 cap/internal-seam ruffle",
    "V18 panel_z_gap / 3D sleeve rotations/translations",
]


def _inner_design(design):
    if isinstance(design, dict) and "design" in design and "mens_basic_block" not in design:
        return design["design"]
    return design


def _leaf(value):
    if isinstance(value, dict) and "v" in value:
        return value["v"]
    return value


def _suit(design):
    design = _inner_design(design)
    if "suit" not in design:
        raise KeyError("A6 requires design['suit']")
    return design["suit"]


def _value(suit, name, fallback=None):
    if name not in suit:
        return fallback
    value = _leaf(suit[name])
    return fallback if value is None and fallback is not None else value


def _source(suit, name, default_label):
    if name not in suit:
        return default_label
    value = _leaf(suit[name])
    if value is None:
        return "design:suit:null"
    return "design:suit"


def _body_value(body, name):
    if isinstance(body, dict):
        if name in body:
            return float(body[name])
        if "body" in body and name in body["body"]:
            return float(body["body"][name])
    return float(body[name])


def _interface_len(obj, name):
    return float(obj.interfaces[name].edges.length())


def _interface_names(obj):
    return sorted(getattr(obj, "interfaces", {}).keys())


@dataclass
class StageA6Unified2DResult:
    third_gen_draft: object
    front_draft_result: object
    formal_result: object
    collar_lapel_draft_result: object
    a4_front_draft_result: object
    front_component: object
    back_panel: object
    collar_panel: object
    sleeve_draft_result: object
    sleeve_component: object
    body_panel_layout: str
    six_panel_geometry: dict | None
    front_armhole_raw_interface_length_cm: float
    front_armhole_p5p6_deduction_cm: float
    front_armhole_length_cm: float
    back_armhole_length_cm: float
    armhole_length_AH_cm: float
    pattern_component: object
    parameter_trace: dict


class UnifiedMensSuit2DPattern(pyg.Component):
    """Canonical pattern-piece container, intentionally without 3-D placement.

    The canonical pattern contains one front-side set, one back, one collar,
    and one two-piece sleeve set.  Mirrored physical duplicates are not needed
    to prove design-parameter execution and are deferred to assembly/export.
    """

    def __init__(
        self,
        name,
        *,
        front_component,
        back_panel,
        collar_panel,
        sleeve_component,
        body_panel_layout,
    ):
        super().__init__(name)
        self.front = front_component
        self.back = back_panel
        self.collar = collar_panel
        self.sleeve = sleeve_component
        self.body_panel_layout = body_panel_layout
        self.subs = [
            self.front,
            self.back,
            self.collar,
            self.sleeve,
        ]

        # Semantic-only sewing registry.  It is deliberately not converted to
        # active 3-D engineering stitches here.
        self.stitch_semantics = {
            "body_side_seam": (
                self.front.interfaces["side_seam"],
                self.back.interfaces["side_seam"],
            ),
            "body_shoulder": (
                self.front.interfaces["shoulder"],
                self.back.interfaces["shoulder"],
            ),
            "body_armhole": {
                "body": self.front.interfaces["armhole"],
                "back": self.back.interfaces["armhole"],
                "sleeve_cap_front": self.sleeve.big_sleeve.interfaces["cap_f3_e1"],
                "sleeve_cap_back": self.sleeve.big_sleeve.interfaces["cap_e1_d3"],
                "small_sleeve_cap": self.sleeve.small_sleeve.interfaces["cap_k5_c2"],
                "status": "SEMANTIC_ONLY_NO_RUFFLE_OR_3D_STITCH",
            },
            "collar_attachment": {
                "collar_attach_right": self.collar.interfaces["attach_right"],
                "body_front_neckline": self.front.interfaces["neckline"],
                "body_back_neckline": self.back.interfaces["neckline"],
                "status": "SEMANTIC_ONLY_A4_2D; FINAL_ASSEMBLY_DEFERRED",
            },
        }
        if body_panel_layout == "four_panel":
            self.stitch_semantics["front_internal"] = (
                self.front.interfaces["side_dart_left"],
                self.front.interfaces["side_dart_right"],
            )
        else:
            self.stitch_semantics["front_internal"] = (
                self.front.interfaces["princess_center"],
                self.front.interfaces["princess_side"],
            )

        self.stage_a6_report = {
            "canonical_2d_only": True,
            "mirrored_physical_duplicates_created": False,
            "active_3d_stitches_created": False,
            "three_d_placement_applied": False,
            "warp_run": False,
        }


class MensSuitJacket2DExecutor:
    """The Stage-A6 single-entry executor."""

    def build(self, body, design, name="mens_suit_stage_a6_2d"):
        design = _inner_design(design)
        suit = _suit(design)

        if "mens_basic_block" not in design:
            raise KeyError("A6 requires design['mens_basic_block']")

        # ----------------------------------------------------------
        # A1: exactly one prototype / front draft execution
        # ----------------------------------------------------------
        third = ThirdGenDraft.from_body_design(body, design)

        front = SuitFrontDraft(third).build(
            suit_params=suit,
            allow_frozen_base_fallback=True,
        )

        formal_base = FormalSuitFrontDraftV0(
            third,
            garment_length_ratio=front.derived_quantities["garment_length_ratio"],
            prototype_result=front.prototype_result,
        ).build()

        # ----------------------------------------------------------
        # A2: waist
        # ----------------------------------------------------------
        requested_waist = _value(suit, "waist_ease_cm", None)
        formal = apply_waist_ease(
            formal_base,
            third,
            body,
            waist_ease_cm=requested_waist,
        )

        # ----------------------------------------------------------
        # A4: current collar/lapel construction uses same front draft
        # and the current formal back neckline.
        # ----------------------------------------------------------
        back_points, back_records, _ = build_formal_back_geometry(formal)

        collar_draft = SuitCollarLapelDraft().build(
            front_draft_result=front,
            back_points=back_points,
            back_records=back_records,
            suit_params=suit,
        )
        a4_front = apply_a4_lapel_points(
            front,
            collar_draft,
            suit_params=suit,
        )

        collar_panel = ParametricSuitCollar2DPanel(
            f"{name}_collar",
            collar_draft,
        )

        # ----------------------------------------------------------
        # A3: actual front topology using the A4-updated front.
        # ----------------------------------------------------------
        body_panel_layout = str(_value(suit, "body_panel_layout", "four_panel"))
        if body_panel_layout not in ("four_panel", "six_panel"):
            raise ValueError("body_panel_layout must be four_panel or six_panel")

        button_count = int(a4_front.derived_quantities.get("button_count", 2))
        six_geometry = None

        if body_panel_layout == "four_panel":
            front_component = FormalParametricSuitFrontPanel(
                f"{name}_front",
                formal,
                a4_front,
                button_count=button_count,
            )
        else:
            six_geometry = build_six_panel_geometry(
                formal,
                a4_front,
            )
            front_component = FormalSixPanelFront(
                f"{name}_front",
                six_geometry,
                a4_front,
                button_count=button_count,
            )

        back_panel = FormalSuitBackPanel(
            f"{name}_back",
            formal,
        )

        # ----------------------------------------------------------
        # FINAL CLEAN AH rule (user-confirmed 2026-08-10):
        #
        #   raw_front_AH = current final front armhole interface length
        #   p5p6_deduction = |p5-p6|
        #   front_AH = raw_front_AH - p5p6_deduction
        #   back_AH  = current final back armhole interface length
        #   AH       = front_AH + back_AH
        #
        # p5p6 is subtracted EXACTLY ONCE here.
        # This is the formal sleeve-input definition for the final CLEAN
        # two-piece sleeve, regardless of the interface-topology discussion.
        # ----------------------------------------------------------
        raw_front_AH = _interface_len(front_component, "armhole")

        if six_geometry is not None:
            armhole_points = six_geometry["points"]
        else:
            armhole_points = front_component.original_points

        p5p6_deduction = math.dist(
            armhole_points["p5"],
            armhole_points["p6"],
        )
        front_AH = raw_front_AH - p5p6_deduction
        if front_AH <= 0.0:
            raise ValueError(
                "FINAL_CLEAN_FRONT_AH_NONPOSITIVE_AFTER_P5P6_DEDUCTION"
            )

        back_AH = _interface_len(back_panel, "armhole")
        AH = front_AH + back_AH

        sleeve_draft = SuitTwoPieceSleeveDraft().build(
            body=body,
            suit_params=suit,
            armhole_length_cm=AH,
            prototype_result=front.prototype_result,
        )
        sleeve_component = ParametricMensTwoPieceSleeve2D(
            f"{name}_sleeve",
            sleeve_draft,
        )

        pattern = UnifiedMensSuit2DPattern(
            name,
            front_component=front_component,
            back_panel=back_panel,
            collar_panel=collar_panel,
            sleeve_component=sleeve_component,
            body_panel_layout=body_panel_layout,
        )

        trace = self._make_trace(
            body=body,
            design=design,
            suit=suit,
            third=third,
            front=front,
            formal=formal,
            collar_draft=collar_draft,
            a4_front=a4_front,
            front_component=front_component,
            back_panel=back_panel,
            collar_panel=collar_panel,
            sleeve_draft=sleeve_draft,
            sleeve_component=sleeve_component,
            body_panel_layout=body_panel_layout,
            six_geometry=six_geometry,
            raw_front_AH=raw_front_AH,
            p5p6_deduction=p5p6_deduction,
            front_AH=front_AH,
            back_AH=back_AH,
            AH=AH,
            pattern=pattern,
        )

        return StageA6Unified2DResult(
            third_gen_draft=third,
            front_draft_result=front,
            formal_result=formal,
            collar_lapel_draft_result=collar_draft,
            a4_front_draft_result=a4_front,
            front_component=front_component,
            back_panel=back_panel,
            collar_panel=collar_panel,
            sleeve_draft_result=sleeve_draft,
            sleeve_component=sleeve_component,
            body_panel_layout=body_panel_layout,
            six_panel_geometry=six_geometry,
            front_armhole_raw_interface_length_cm=raw_front_AH,
            front_armhole_p5p6_deduction_cm=p5p6_deduction,
            front_armhole_length_cm=front_AH,
            back_armhole_length_cm=back_AH,
            armhole_length_AH_cm=AH,
            pattern_component=pattern,
            parameter_trace=trace,
        )

    def _make_trace(
        self, *,
        body, design, suit, third, front, formal,
        collar_draft, a4_front,
        front_component, back_panel, collar_panel,
        sleeve_draft, sleeve_component,
        body_panel_layout, six_geometry,
        raw_front_AH, p5p6_deduction,
        front_AH, back_AH, AH, pattern,
    ):
        resolved_front = deepcopy(
            front.diagnostics.get("resolved_design_parameters", {})
        )
        front_sources = deepcopy(
            front.diagnostics.get("parameter_sources", {})
        )

        input_rows = {}
        defaults = {
            "lapel_style": "notched",
            "body_panel_layout": "four_panel",
            "back_collar_width_BCW_cm": 2.5,
            "point_width_delta_cm": 0.0,
            "collar_point_angle_s3_s4_s5_deg": 90.0,
            "sleeve_length_reduction_X_cm": 0.5,
        }
        for name, meta in A6_CONNECTED_DESIGN_PARAMETERS.items():
            fallback = defaults.get(name)
            value = _value(suit, name, fallback)
            if name == "waist_ease_cm":
                value = _value(suit, name, None)
            input_rows[name] = {
                "value": value,
                "source": front_sources.get(
                    name,
                    _source(
                        suit, name,
                        f"A{meta['stage']}:internal/default"
                    ),
                ),
                "range": deepcopy(meta["range"]),
                "stage": meta["stage"],
                "effect": meta["effect"],
            }

        waist = deepcopy(formal.diagnostics.get("waist_parameterization", {}))
        front_derived = deepcopy(front.derived_quantities)
        collar_derived = deepcopy(collar_draft.derived_quantities)
        sleeve_derived = deepcopy(sleeve_draft.derived_quantities)

        if body_panel_layout == "six_panel":
            topology = deepcopy(six_geometry["audit"])
            canonical_front_piece_count = 2
            front_piece_names = [
                front_component.center.name,
                front_component.side.name,
            ]
        else:
            topology = {
                "body_panel_layout": "four_panel",
                "front_piece_count_per_side": 1,
                "p8p9_semantics": "side_dart",
                "front_lower_edge_style": front_derived.get(
                    "front_lower_edge_style"
                ),
            }
            canonical_front_piece_count = 1
            front_piece_names = [front_component.name]

        return {
            "stage": "A6_UNIFIED_DESIGN_2D_EXECUTOR",
            "schema_version": "2026-08-09-a6",
            "status": "RUNTIME_RESULT",
            "body_measurements_used": {
                "bust_cm": _body_value(body, "bust"),
                "waist_cm": _body_value(body, "waist"),
                "arm_length_cm": _body_value(body, "arm_length"),
            },
            "design_inputs": input_rows,
            "execution_reuse": {
                "third_gen_draft_created_once_in_a6": True,
                "suit_front_draft_created_once_in_a6": True,
                "formal_reuses_front_prototype": bool(
                    formal.diagnostics.get("prototype_construction_reused")
                ),
                "a4_uses_same_front_result": (
                    a4_front.prototype_result is front.prototype_result
                ),
                "a5_AH_measured_from_existing_final_body": True,
                "a5_final_rule_subtracts_p5p6_once": True,
                "a5_p5p6_subtraction_count": 1,
                "a5_high_level_bridge_rebuild_used": False,
            },
            "derived": {
                "front": {
                    key: front_derived.get(key)
                    for key in (
                        "garment_length_ratio",
                        "garment_length_cm",
                        "overlap_M_cm",
                        "break_point_height_cm",
                        "button_spacing_cm",
                        "button_count",
                        "front_lower_edge_style",
                        "first_button_drafting_point",
                        "second_button_drafting_point",
                    )
                    if key in front_derived
                },
                "waist": {
                    "diagnostics": waist,
                    "finished_garment_waist_cm": formal.derived_quantities.get(
                        "finished_garment_waist_cm"
                    ),
                    "effective_waist_ease_cm": formal.derived_quantities.get(
                        "effective_waist_ease_cm"
                    ),
                    "waist_takeups_cm": deepcopy(
                        formal.derived_quantities.get("waist_takeups_cm")
                    ),
                },
                "collar_lapel": collar_derived,
                "armhole": {
                    "raw_front_armhole_interface_cm": raw_front_AH,
                    "p5p6_deduction_cm": p5p6_deduction,
                    "p5p6_subtraction_count": 1,
                    "front_AH_cm": front_AH,
                    "front_rule": (
                        "front_AH = raw_front_armhole_interface - |p5p6|"
                    ),
                    "back_AH_cm": back_AH,
                    "AH_cm": AH,
                    "source": (
                        "final_user_rule_front_interface_minus_p5p6_plus_back_interface"
                    ),
                },
                "sleeve": sleeve_derived,
            },
            "topology": {
                "body_panel_layout": body_panel_layout,
                "canonical_front_piece_count": canonical_front_piece_count,
                "canonical_front_piece_names": front_piece_names,
                "front_interfaces": _interface_names(front_component),
                "back_interfaces": _interface_names(back_panel),
                "collar_interfaces": _interface_names(collar_panel),
                "big_sleeve_interfaces": _interface_names(
                    sleeve_component.big_sleeve
                ),
                "small_sleeve_interfaces": _interface_names(
                    sleeve_component.small_sleeve
                ),
                "detail": topology,
            },
            "canonical_components": {
                "front": getattr(front_component, "name", None),
                "back": back_panel.name,
                "collar": collar_panel.name,
                "big_sleeve": sleeve_component.big_sleeve.name,
                "small_sleeve": sleeve_component.small_sleeve.name,
            },
            "stitch_semantics_only": sorted(pattern.stitch_semantics.keys()),
            "remaining_source_required": list(KNOWN_SOURCE_REQUIRED),
            "engineering_exclusions": list(NON_DESIGN_ENGINEERING_EXCLUSIONS),
            "safety_state": {
                "whole_piece_scaling_used": False,
                "active_3d_components_replaced": False,
                "three_d_modified": False,
                "warp_run": False,
            },
        }


def build_mens_suit_stage_a6_2d(body, design, name="mens_suit_stage_a6_2d"):
    """Convenience entry point for dataset generation and tests."""
    return MensSuitJacket2DExecutor().build(body, design, name=name)
