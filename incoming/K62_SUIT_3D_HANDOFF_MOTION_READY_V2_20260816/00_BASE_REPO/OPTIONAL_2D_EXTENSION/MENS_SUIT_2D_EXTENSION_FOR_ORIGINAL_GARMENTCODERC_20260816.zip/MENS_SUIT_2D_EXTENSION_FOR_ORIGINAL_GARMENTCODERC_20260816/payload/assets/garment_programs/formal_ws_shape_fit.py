"""Deterministic BASE constrained fitting for the formal prototype WS curve."""
from __future__ import annotations

import math

import numpy as np
from scipy.optimize import differential_evolution, minimize

from assets.garment_programs.suit_curve_rules_v2 import sample_record
from assets.garment_programs.suit_pattern_data import (
    BACK_EDGES,
    BACK_POINTS,
    FRONT_EDGES,
    FRONT_POINTS,
)


CONTROL_NAMES = ("prototype_a7", "prototype_a4", "prototype_c5", "c3")
SELECTED_BASE_VALUES = {
    "tau_ratio_on_b1b2": 0.25,
    "w_tangent_over_chord": 1.0743719481001137,
    "tau_tangent_over_adjacent_chord": 1.4,
    "c1_tangent_over_adjacent_chord": 0.9357778128343512,
    "s_side_kappa_u": 0.33559150229375245,
    "s_side_kappa_v": -0.23649723944849377,
    "s_side_kappa_tangent_angle_rad": 0.8028973705091932,
    "s_side_kappa_tangent_over_adjacent_chord": 1.6,
    "s_tangent_over_chord": 0.8176857415825863,
}


def _value_vector(values):
    return [values[name] for name in SELECTED_BASE_VALUES]


def evaluate_formal_ws_values(points, values):
    """Evaluate an explicit B4 vector without changing the active BASE values."""
    if set(values) != set(SELECTED_BASE_VALUES):
        raise ValueError("FORMAL_WS_B4_FIELD_SET_INVALID")
    vector = _value_vector(values)
    local, edges = _curve_records(points, vector)
    overshoot, m1 = _overshoot(edges, local)
    controls = {}
    for name in CONTROL_NAMES:
        row = _nearest(points[name], edges, local)
        controls[name] = {
            "signed_distance_cm": row[4], "nearest_distance_cm": row[0],
            "nearest_branch_index": row[1],
            "nearest_branch": [edges[row[1]]["p0"], edges[row[1]]["p1"]],
            "nearest_parameter": row[2],
            "nearest_point": row[3],
            "convexity_side": 1 if row[4] > 0 else -1,
            "actively_used_in_fit": True,
        }
    return {
        "values": dict(values), "points": local, "edges": edges,
        "shape_controls": controls, "m1": m1,
        "max_armhole_side_seam_overshoot_cm": float(overshoot),
        "curvature_max_cm_inv": _curvature_metric(edges, local),
        "selection_method": "explicit_B4_candidate_evaluation",
    }


def _unit(v):
    v = np.asarray(v, float); n = float(np.linalg.norm(v))
    if n < 1.0e-12: raise ValueError("zero formal WS tangent")
    return v / n


def _curve_records(points, values):
    tau_ratio, w_mag, tau_mag, c1_mag, k_u, k_v, k_angle, k_mag, s_mag = map(float, values)
    tau = (np.asarray(points["b1"]) + tau_ratio * (np.asarray(points["b2"]) - np.asarray(points["b1"]))).tolist()
    local = dict(points); local["tau_b1b2"] = tau
    c1=np.asarray(points["prototype_c1"],float); s=np.asarray(points["s"],float)
    chord=s-c1; perp=np.array([-chord[1],chord[0]])
    kappa=(c1+k_u*chord+k_v*perp).tolist(); local["ws_kappa_s_side"] = kappa
    names = ("w", "tau_b1b2", "prototype_c1", "ws_kappa_s_side", "s")
    t_tau = _unit(np.asarray(points["b2"]) - np.asarray(points["b1"]))
    t_c1 = _unit(np.asarray(points["b5"]) - np.asarray(points["b3"]))
    if np.dot(t_c1, np.asarray(points["s"]) - np.asarray(points["prototype_c1"])) < 0: t_c1 *= -1
    k_dir=np.array([math.cos(k_angle),math.sin(k_angle)])
    if np.dot(k_dir,s-c1)<0:k_dir*=-1
    lengths = (
        w_mag * np.linalg.norm(np.asarray(tau) - np.asarray(points["w"])),
        tau_mag * min(np.linalg.norm(np.asarray(tau) - np.asarray(points["w"])), np.linalg.norm(np.asarray(points["prototype_c1"]) - np.asarray(tau))),
        c1_mag * min(np.linalg.norm(np.asarray(points["prototype_c1"]) - np.asarray(tau)), np.linalg.norm(np.asarray(points["s"]) - np.asarray(points["prototype_c1"]))),
        k_mag * min(np.linalg.norm(np.asarray(kappa)-c1),np.linalg.norm(s-np.asarray(kappa))),
        s_mag * np.linalg.norm(s-np.asarray(kappa)),
    )
    directions = (
        _unit(np.asarray(tau) - np.asarray(points["w"])), t_tau, t_c1, k_dir,
        _unit(s-np.asarray(kappa)),
    )
    tangents = [directions[i] * lengths[i] for i in range(5)]
    edges = []
    for i in range(4):
        a=np.asarray(local[names[i]],float); b=np.asarray(local[names[i+1]],float)
        edges.append({"kind":"curve","p0":names[i],"p1":names[i+1],
                      "c1":(a+tangents[i]/3.0).tolist(),"c2":(b-tangents[i+1]/3.0).tolist(),
                      "source":"formal_ws_fitted"})
    return local, edges


def _sample(edges, points, n=100):
    return np.vstack([sample_record(edge, points, n)[:-1] for edge in edges] + [sample_record(edges[-1], points, n)[-1:]])


def _historical_reference():
    front = FRONT_EDGES[3:6] + FRONT_EDGES[10:13]
    back = BACK_EDGES[0:2]
    return np.vstack([sample_record(e, FRONT_POINTS, 80) for e in front] + [sample_record(e, BACK_POINTS, 80) for e in back])


def _nearest(point, edges, points):
    best=None
    for index, edge in enumerate(edges):
        q=sample_record(edge,points,160)
        ids=np.argmin(np.linalg.norm(q-np.asarray(point),axis=1)); candidate=q[ids]
        chord=np.asarray(points[edge["p1"]])-np.asarray(points[edge["p0"]])
        offset=np.asarray(point)-candidate
        signed=float((chord[0]*offset[1]-chord[1]*offset[0])/np.linalg.norm(chord))
        item=(float(np.linalg.norm(offset)),index,float(ids/(len(q)-1)),candidate.tolist(),signed)
        if best is None or item[0]<best[0]: best=item
    return best


def _horizontal_root(edge, points, y):
    q=sample_record(edge,points,600); roots=[]
    for i in range(len(q)-1):
        a,b=q[i],q[i+1]
        if (a[1]-y)*(b[1]-y)<=0 and abs(b[1]-a[1])>1e-12:
            u=(y-a[1])/(b[1]-a[1]); roots.append((i+u)/(len(q)-1))
    return roots


def _eval(edge, points, t):
    a=np.asarray(points[edge["p0"]]); b=np.asarray(points[edge["p1"]]); c1=np.asarray(edge["c1"]); c2=np.asarray(edge["c2"]); u=1-t
    return u**3*a+3*u*u*t*c1+3*u*t*t*c2+t**3*b


def _overshoot(edges, points):
    roots=[]
    for index, edge in enumerate(edges[2:], start=2):
        roots.extend((index,t) for t in _horizontal_root(edge,points,points["prototype_a5"][1]))
    if len(roots)!=1: return 99.0, None
    m1_index,m1_t=roots[0]
    m1=_eval(edges[m1_index],points,m1_t); m7=np.array([m1[0]-2.0,points["c"][1]])
    chord=m7-m1; perp=np.array([-chord[1],chord[0]])
    side={"kind":"curve","p0":"_m1","p1":"_m7",
          "c1":(m1+(1/3)*chord+0.03*perp).tolist(),
          "c2":(m1+(2/3)*chord+0.03*perp).tolist()}
    local=dict(points); local["_m1"]=m1.tolist(); local["_m7"]=m7.tolist()
    front_records=list(edges[2:m1_index])
    q=sample_record(edges[m1_index],points,500)
    front_samples=[sample_record(edge,points,500) for edge in front_records]
    front_samples.append(q[:max(2,int(round(m1_t*(len(q)-1)))+1)])
    arm=np.vstack(front_samples); seam=sample_record(side,local,500)
    vals=[]
    for a in arm:
        if seam[:,1].min()-1e-9 <= a[1] <= seam[:,1].max()+1e-9:
            j=int(np.argmin(abs(seam[:,1]-a[1]))); vals.append(a[0]-seam[j,0])
    return max(vals) if vals else 99.0, m1.tolist()


def _curvature_metric(edges, points):
    q=_sample(edges,points,240); d=np.diff(q,axis=0); lens=np.linalg.norm(d,axis=1)
    if lens.min()<1e-7:return 99.0
    u=d/lens[:,None]; ang=np.arccos(np.clip(np.sum(u[:-1]*u[1:],axis=1),-1,1))
    return float((ang/np.maximum((lens[:-1]+lens[1:])/2,1e-12)).max())


def fit_formal_ws_base(points):
    historical=_historical_reference()
    expected_branch={"prototype_a7":0,"prototype_a4":0,"prototype_c5":2,"c3":3}

    def objective(x):
        local,edges=_curve_records(points,x); q=_sample(edges,local,100)
        # Reject large control-polygon reversals/loops even if sampled soft
        # distances happen to look acceptable.
        for edge in edges:
            a=np.asarray(local[edge["p0"]]); b=np.asarray(local[edge["p1"]]); chord=b-a
            for cp in (np.asarray(edge["c1"]),np.asarray(edge["c2"])):
                along=float(np.dot(cp-a,chord)/np.dot(chord,chord))
                if along < -0.35 or along > 1.35:
                    return 10000.0 + 1000.0*abs(along)
        # Symmetric sampled Chamfer: historical is a secondary reference only.
        d1=np.min(np.linalg.norm(q[:,None,:]-historical[None,:,:],axis=2),axis=1)
        d2=np.min(np.linalg.norm(historical[:,None,:]-q[None,:,:],axis=2),axis=1)
        score=0.05*float(np.mean(d1*d1))+0.01*float(np.mean(d2*d2))
        control_rows={name:_nearest(points[name],edges,local) for name in CONTROL_NAMES}
        # Shape controls actively select their intended branch and convexity side.
        for name,row in control_rows.items():
            score += 12.0 * abs(row[1]-expected_branch[name])
            score += 0.02 * row[0]*row[0]
        # Preserve the independently computed BASE convexity sides.
        desired={"prototype_a7":-1,"prototype_a4":-1,"prototype_c5":1,"c3":-1}
        score += sum(50.0 for name,row in control_rows.items() if row[4]*desired[name] <= 0)
        overshoot,_=_overshoot(edges,local)
        # Keep a small inward margin rather than merely touching the numerical
        # tolerance boundary; positive means the armhole is outside the seam.
        if overshoot>-0.001: score += 10000.0 + 10000.0*(overshoot+0.001)**2
        score += 1.5*_curvature_metric(edges,local)**2
        return score

    bounds=((0.25,0.75),(0.2,1.1),(0.35,1.4),(0.15,1.2),
            (0.2,0.8),(-0.25,0.25),(-1.4,1.4),(0.2,1.6),(0.15,1.2))
    coarse=differential_evolution(objective,bounds,seed=19,popsize=7,maxiter=35,tol=2e-5,polish=False,workers=1)
    refined=minimize(objective,coarse.x,method="L-BFGS-B",bounds=bounds,
                     options={"maxiter":1200,"ftol":1e-12,"gtol":1e-8,"maxls":40})
    values=np.asarray(refined.x,float); local,edges=_curve_records(points,values)
    overshoot,m1=_overshoot(edges,local)
    controls={}
    for name in CONTROL_NAMES:
        row=_nearest(points[name],edges,local)
        controls[name]={"signed_distance_cm":row[4],"nearest_distance_cm":row[0],
                        "nearest_branch_index":row[1],"nearest_branch":[edges[row[1]]["p0"],edges[row[1]]["p1"]],
                        "convexity_side":1 if row[4]>0 else -1,"actively_used_in_fit":True}
    return {
        "values": {
            "tau_ratio_on_b1b2":float(values[0]),"w_tangent_over_chord":float(values[1]),
            "tau_tangent_over_adjacent_chord":float(values[2]),
            "c1_tangent_over_adjacent_chord":float(values[3]),
            "s_side_kappa_u":float(values[4]),"s_side_kappa_v":float(values[5]),
            "s_side_kappa_tangent_angle_rad":float(values[6]),
            "s_side_kappa_tangent_over_adjacent_chord":float(values[7]),
            "s_tangent_over_chord":float(values[8]),
        },
        "points":local,"edges":edges,"shape_controls":controls,"m1":m1,
        "max_armhole_side_seam_overshoot_cm":float(overshoot),
        "curvature_max_cm_inv":_curvature_metric(edges,local),
        "objective":float(objective(values)),"optimizer_success":bool(refined.success),
    }


def evaluate_selected_formal_ws_base(points):
    """Evaluate the selected result of the reproducible constrained fit."""
    result = evaluate_formal_ws_values(points, SELECTED_BASE_VALUES)
    result["selection_method"] = "constrained_BASE_fit_with_shape_controls_and_side_seam_rejection"
    return result
