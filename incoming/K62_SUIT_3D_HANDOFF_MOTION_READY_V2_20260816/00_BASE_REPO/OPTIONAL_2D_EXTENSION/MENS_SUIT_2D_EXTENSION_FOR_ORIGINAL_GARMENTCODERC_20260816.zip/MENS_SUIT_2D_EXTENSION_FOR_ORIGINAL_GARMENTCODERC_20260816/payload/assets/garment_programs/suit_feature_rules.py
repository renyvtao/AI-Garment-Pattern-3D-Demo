# -*- coding: utf-8 -*-
"""Single authority for selectable suit button/closure/render features.

Simulation features are resolved before BoxMesh/Warp. Render features are
metadata-only and must not alter the physical specification.
"""
from __future__ import annotations


def _leaf(value):
    return value.get("v") if isinstance(value, dict) and "v" in value else value


def _bool(value, default):
    if value is None:
        return bool(default)
    value = _leaf(value)
    if isinstance(value, str):
        return value.lower() in ("1", "true", "yes", "on")
    return bool(value)


def resolve_suit_features(design_or_suit):
    """Resolve one canonical feature set; accepts design or suit mapping."""
    design = design_or_suit
    if isinstance(design, dict) and "design" in design:
        design = design["design"]
    suit = design.get("suit", design) if isinstance(design, dict) else {}
    button_count = int(_leaf(suit.get("button_count", 2)))
    if button_count not in (1, 2):
        raise ValueError("button_count must be 1 or 2")
    # Closure is a runtime/simulation feature.  It must not be active in the
    # default serialized topology; explicit design input can still enable it.
    closure_enabled = _bool(suit.get("closure_enabled", False), False)
    render_buttons = _bool(suit.get("render_buttons", True), True)
    small = _bool(suit.get("small_pocket_enabled", None), True)
    large = _bool(suit.get("large_pockets_enabled", None), True)
    pockets = suit.get("pockets", {})
    if isinstance(pockets, dict):
        if "enabled" in pockets and not _bool(pockets["enabled"], True):
            small = large = False
        small = _bool(suit.get("small_pocket_enabled", pockets.get("small", {}).get("enabled")), small)
        large = _bool(suit.get("large_pockets_enabled", pockets.get("big", {}).get("enabled")), large)
    one_button_status = "POINT_AT_R3_POLICY_PROVEN" if button_count == 1 else "NOT_APPLICABLE"
    closure_policy = (
        {"mode": "POINT", "point": "r3", "start": "r3", "end": "r3"}
        if button_count == 1 else
        {"mode": "SEGMENT", "start": "button_1", "end": "button_2"}
    )
    return {
        "button_count": button_count,
        "closure_enabled": closure_enabled,
        "render_buttons": render_buttons,
        "small_pocket_enabled": small,
        "large_pockets_enabled": large,
        "one_button_closure": one_button_status,
        "runtime_closure_required": True,
        "runtime_closure_policy": closure_policy,
        "simulation_feature_layer": {
            "closure_enabled": closure_enabled,
            "closure_mode": closure_policy["mode"],
            "closure_policy": closure_policy,
            "formal_stitch": False,
            "warp_execution": "DEFERRED_TO_PART5",
        },
        "render_feature_layer": {
            "render_buttons": render_buttons,
            "small_pocket_enabled": small,
            "large_pockets_enabled": large,
        },
    }


def apply_simulation_features(assembly, features):
    """Record the pre-BoxMesh decision; caller installs the physical rule."""
    assembly.feature_rules = features
    assembly.closure_enabled = bool(features["closure_enabled"])
    assembly.runtime_closure_policy = dict(features["runtime_closure_policy"])
    return assembly


def apply_render_features(target, features):
    """Attach render-only switches without changing physical geometry."""
    target.render_features = dict(features["render_feature_layer"])
    return target
