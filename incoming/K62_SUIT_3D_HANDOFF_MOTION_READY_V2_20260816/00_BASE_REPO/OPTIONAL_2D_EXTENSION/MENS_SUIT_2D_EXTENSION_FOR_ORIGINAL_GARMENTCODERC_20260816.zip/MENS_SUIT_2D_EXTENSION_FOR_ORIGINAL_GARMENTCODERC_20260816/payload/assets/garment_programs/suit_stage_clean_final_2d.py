# -*- coding: utf-8 -*-
r"""Canonical CLEAN men's suit final 2-D entry with line-pockets and decorative buttons.

This stage is intentionally NOT named A7/A8:
- A1..A8 files remain historical development snapshots;
- current geometry base is the frozen CLEAN A6 executor + final sleeve freeze;
- pockets and decorative-button semantics are layered on top without re-running/replacing body/sleeve geometry.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
import pygarment as pyg

from assets.garment_programs.suit_stage_a6_unified_2d import (
    build_mens_suit_stage_a6_2d,
)
from assets.garment_programs.suit_pocket_components import (
    build_suit_pockets,
)
from assets.garment_programs.suit_button_components import (
    build_suit_buttons,
)
from assets.garment_programs.suit_feature_rules import (
    resolve_suit_features,
    apply_render_features,
)


def _inner_design(design):
    if isinstance(design, dict) and "design" in design and "mens_basic_block" not in design:
        return design["design"]
    return design


def _leaf(v):
    return v.get("v") if isinstance(v, dict) and "v" in v else v


@dataclass
class CleanSuitFinal2DResult:
    base_a6_result: object
    pocket_component: object
    button_component: object
    pattern_component: object
    parameter_trace: dict


class CleanSuitFinalPattern(pyg.Component):
    def __init__(self, name, base_pattern, pockets, buttons):
        super().__init__(name)
        self.base_pattern = base_pattern
        self.pockets = pockets
        self.buttons = buttons
        self.subs = [base_pattern, pockets, buttons]

        self.stitch_semantics = deepcopy(getattr(base_pattern, "stitch_semantics", {}))
        self.stitch_semantics["pockets"] = deepcopy(pockets.attachment_semantics)
        self.stitch_semantics["decorative_buttons"] = deepcopy(buttons.button_semantics)
        self.stitch_semantics["button_pair_candidate"] = deepcopy(
            buttons.button_semantics.get("pair_semantics", {})
        )
        self.stage_report = {
            "canonical_clean_final_2d": True,
            "base_stage": "A6_FINAL_SLEEVE_FREEZE",
            "pockets_added": True,
            "buttons_added": True,
            "active_pocket_stitches_created": False,
            "active_button_closure_created": False,
            "front_body_topology_modified": False,
            "3d_modified": False,
            "warp_run": False,
        }


def build_mens_suit_clean_final_2d(body, design, name="mens_suit_clean_final_2d"):
    design = _inner_design(design)
    if "suit" not in design:
        raise KeyError("clean-final requires design['suit']")
    features = resolve_suit_features(design)

    base = build_mens_suit_stage_a6_2d(body, design, name=f"{name}_base")

    suit_params = dict(design["suit"])
    suit_params.update(features)
    pockets = build_suit_pockets(base.formal_result, suit_params, name=f"{name}_pockets")
    buttons = build_suit_buttons(base.pattern_component.front, suit_params, name=f"{name}_buttons")

    pattern = CleanSuitFinalPattern(name, base.pattern_component, pockets, buttons)
    apply_render_features(pattern, features)

    trace = deepcopy(base.parameter_trace)
    trace["stage"] = "CLEAN_SUIT_FINAL_2D_WITH_LINES_AND_DECORATIVE_BUTTONS"
    trace["suit_features"] = deepcopy(features)
    trace["schema_version"] = "2026-08-12-clean-final-lines-buttons"
    trace["base_geometry_stage"] = "A6_FINAL_SLEEVE_FREEZE"
    trace["design_inputs"]["small_pocket_enabled"] = {
        "value": bool(_leaf(design["suit"].get("small_pocket_enabled", True))),
        "source": "design:suit",
        "range": [False, True],
        "effect": "left q1-q3-q4-q2 line-only pocket visibility",
    }
    trace["design_inputs"]["large_pockets_enabled"] = {
        "value": bool(_leaf(design["suit"].get("large_pockets_enabled", True))),
        "source": "design:suit",
        "range": [False, True],
        "effect": "left+right p1-n9 line-only pocket visibility",
    }
    trace["pockets"] = deepcopy(pockets.stage_report)
    trace["pocket_attachment_semantics"] = deepcopy(pockets.attachment_semantics)
    trace["buttons"] = deepcopy(buttons.stage_report)
    trace["feature_execution"] = {
        "button_count": features["button_count"],
        "closure_enabled": features["closure_enabled"],
        "render_buttons": features["render_buttons"],
        "small_pocket_enabled": features["small_pocket_enabled"],
        "large_pockets_enabled": features["large_pockets_enabled"],
        "closure_installed": False,
        "closure_constraint_count": 0,
        "button_render_count": buttons.stage_report["button_render_count"],
        "small_pocket_rendered": pockets.stage_report["small_pocket_left_rendered"],
        "large_pocket_left_rendered": pockets.stage_report["large_pocket_left_rendered"],
        "large_pocket_right_rendered": pockets.stage_report["large_pocket_right_rendered"],
        "pocket_projection_contract": pockets.stage_report["projection_contract"],
        "pocket_is_render_only": True,
        "closure_is_simulation_feature": True,
    }
    trace["decorative_button_semantics"] = deepcopy(buttons.button_semantics)
    trace["remaining_2d_limitations"] = [
        item for item in trace.get("remaining_2d_limitations", [])
        if "Pockets" not in str(item) and "pockets" not in str(item)
    ]
    trace["remaining_2d_limitations"].append(
        "Pocket lines and decorative buttons are semantic preview elements only; no extra cloth piece or button mesh is created here."
    )
    trace["remaining_2d_limitations"].append(
        "Closure is still disabled. Pair semantics are recorded only; actual closure engineering is deferred to later 3D assembly."
    )

    return CleanSuitFinal2DResult(
        base_a6_result=base,
        pocket_component=pockets,
        button_component=buttons,
        pattern_component=pattern,
        parameter_trace=trace,
    )
