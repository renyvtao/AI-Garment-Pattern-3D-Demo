# -*- coding: utf-8 -*-
r"""CLEAN men's two-piece suit sleeve — rule-driven 2-D construction.

This module intentionally removes the former FROZEN_POINTS dependency from
formal sleeve construction.

Formal inputs
=============
AH = current corrected body armhole arc length
BF = sleeve width, derived by the construction
S  = sleeve length = body.arm_length - X
CW = cuff width = 2/3 BF
D  = 1/8 * (B/6 + 9.5)

Current formal cap-height rule:
    |b1-d3| = AH/2 - cap_reduction
    cap_reduction in [3.0, 4.0] cm
    default = 4.0 cm

Prototype dependency
====================
The drafting background and formal reference points come from the SAME
third-generation men's prototype construction already used by the suit front.
The A6 executor passes ``front.prototype_result`` into this sleeve draft.

Therefore prototype points/lines such as:
    i, h, c, e, f, g, b1, b2, c2
are reused rather than reconstructed from historical sleeve coordinates.

Important b2 note
=================
Under the confirmed prototype formulas:
    D = (B/6+9.5)/8
    b2 = h + [D,0]
and the sleeve rule gives:
    h8 = h + [D,0]
so b2 == h8 identically.

The user's rule says the small cap k5-k4-c2 is downward-convex and has a
tangency relationship with fg at b2.  Literal insertion of b2 as an extra
boundary vertex would make the side boundary h8->k5 and cap k5->b2(=h8)
form a degenerate loop.  This module therefore:
- preserves b2 explicitly as a prototype tangent reference;
- initializes the small-cap START tangent parallel to fg;
- exposes b2 and fg in the interactive editor;
- does NOT silently insert b2 into panel topology.

No 3-D placement, stitching, BoxMesh or Warp is defined here.
"""
from __future__ import annotations

from copy import deepcopy
from dataclasses import dataclass
from pathlib import Path
import math

import numpy as np
import yaml

from assets.garment_programs.suit_curve_rules_v2 import (
    q_to_abs,
    abs_cp_to_q,
    ray_intersection_with_record,
)

EPS = 1.0e-10

_CURVE_RULES_PATH = (
    Path(__file__).resolve().parents[1]
    / "design_params/suit_parametric/sleeve_curve_shapes_clean.yaml"
)


class SleeveDraftValidationError(ValueError):
    pass


@dataclass(frozen=True)
class ResolvedSleeveParams:
    net_full_arm_length_cm: float
    sleeve_length_reduction_X_cm: float
    sleeve_length_S_cm: float
    B_cm: float
    D_cm: float
    AH_cm: float
    cap_reduction_cm: float


@dataclass(frozen=True)
class SuitTwoPieceSleeveDraftResult:
    points: dict
    segments: dict
    big_boundary_groups: list
    small_boundary_groups: list
    derived_quantities: dict
    diagnostics: dict
    prototype_points: dict
    prototype_lines: dict


BIG_BOUNDARY_GROUPS = [
    ("cap_e1_d3", ["big_top_e1_h2", "big_top_h2_d3"]),
    ("seam_d3_j1", [
        "big_right_d3_k7", "big_right_k7_k8", "big_right_k8_j1"
    ]),
    ("cuff_j1_j2", ["bottom_j1_j2"]),
    ("seam_j2_f3", [
        "big_left_j2_h7", "big_left_h7_h5", "big_left_h5_f3"
    ]),
    ("cap_f3_e1", [
        "big_top_f3_b1", "big_top_b1_f1",
        "big_top_f1_f2", "big_top_f2_e1"
    ]),
]

SMALL_BOUNDARY_GROUPS = [
    ("cap_k5_c2", ["small_top_k5_k4", "small_top_k4_c2"]),
    ("seam_c2_j1", [
        "small_right_c2_j3", "small_right_j3_k9", "small_right_k9_j1"
    ]),
    ("cuff_j1_k6", ["small_cuff_j1_k6"]),
    ("seam_k6_k5", [
        "small_outer_k6_h9", "small_outer_h9_h6",
        "small_outer_h6_h8", "small_outer_h8_k5"
    ]),
]


def _leaf(value):
    if isinstance(value, dict) and "v" in value:
        return value["v"]
    return value


def _body(body, name):
    if isinstance(body, dict):
        if name in body:
            return body[name]
        if "body" in body and name in body["body"]:
            return body["body"][name]
    try:
        return body[name]
    except Exception as exc:
        raise SleeveDraftValidationError(
            f"missing body measurement: {name}"
        ) from exc


def _suit_value(suit_params, name, default):
    node = (suit_params or {}).get(name)
    if node is None:
        return default
    value = _leaf(node)
    return default if value is None else value


def _arr(p):
    return np.asarray(p, dtype=float)


def _dist(a, b):
    return float(np.linalg.norm(_arr(b) - _arr(a)))


def _unit_vec(v):
    v = _arr(v)
    n = float(np.linalg.norm(v))
    if n <= EPS:
        raise SleeveDraftValidationError("zero-length vector")
    return v / n


def _unit(a, b):
    return _unit_vec(_arr(b) - _arr(a))


def _mid(a, b):
    return (0.5 * (_arr(a) + _arr(b))).tolist()


def _line_intersection(a, b, c, d):
    a, b, c, d = map(_arr, (a, b, c, d))
    v = b - a
    w = d - c
    den = float(v[0] * w[1] - v[1] * w[0])
    if abs(den) <= EPS:
        raise SleeveDraftValidationError("construction lines are parallel")
    ca = c - a
    t = float((ca[0] * w[1] - ca[1] * w[0]) / den)
    return (a + t * v).tolist()


def _normal_candidates(origin, line_a, line_b, length):
    o = _arr(origin)
    d = _unit(line_a, line_b)
    n = np.asarray([-d[1], d[0]], dtype=float)
    L = float(length)
    return [(o + L * n).tolist(), (o - L * n).tolist()]


def _pick(candidates, score):
    return max(candidates, key=score)


def _pick_upper_left(candidates, origin):
    ox, oy = map(float, origin)
    return _pick(candidates, lambda p: (p[1] - oy, ox - p[0]))


def _pick_upper_right(candidates, origin):
    ox, oy = map(float, origin)
    return _pick(candidates, lambda p: (p[1] - oy, p[0] - ox))


def _pick_lower_right(candidates, origin):
    ox, oy = map(float, origin)
    return _pick(candidates, lambda p: (oy - p[1], p[0] - ox))


def _circle_line_intersections(center, radius, line_a, line_b):
    c = _arr(center)
    a = _arr(line_a)
    b = _arr(line_b)
    v = b - a
    A = float(np.dot(v, v))
    if A <= EPS:
        raise SleeveDraftValidationError("degenerate circle-line reference")
    ac = a - c
    B = 2.0 * float(np.dot(ac, v))
    C = float(np.dot(ac, ac) - radius * radius)
    disc = B * B - 4.0 * A * C
    if disc < -1.0e-9:
        raise SleeveDraftValidationError("circle and construction line do not meet")
    disc = max(0.0, disc)
    r = math.sqrt(disc)
    ts = [(-B-r)/(2*A), (-B+r)/(2*A)]
    return [(a + t*v, float(t)) for t in ts]


def _circle_line_pick_d3(center, radius, d2, d1):
    items = _circle_line_intersections(center, radius, d2, d1)
    p, _ = max(items, key=lambda item: item[1])
    if p[1] <= _arr(center)[1]:
        raise SleeveDraftValidationError("d3 is not upper-right of b1")
    return p.tolist()


def _circle_vertical_lower(center, radius, x):
    c = _arr(center)
    dx = float(x - c[0])
    rr = float(radius) ** 2 - dx * dx
    if rr < -1.0e-9:
        raise SleeveDraftValidationError("e1 circle does not reach ih")
    dy = math.sqrt(max(0.0, rr))
    return [float(x), float(c[1] - dy)]


def _load_curve_overrides():
    if not _CURVE_RULES_PATH.exists():
        return {}
    data = yaml.safe_load(_CURVE_RULES_PATH.read_text(encoding="utf-8")) or {}
    return deepcopy(data.get("curve_overrides", {}))


def resolve_sleeve_params(body, suit_params, *, armhole_length_cm):
    B = float(_body(body, "bust"))
    net_arm = float(_body(body, "arm_length"))

    X = float(_suit_value(
        suit_params, "sleeve_length_reduction_X_cm", 0.5
    ))
    if not 0.5 <= X <= 1.5:
        raise SleeveDraftValidationError(
            "sleeve_length_reduction_X_cm outside current range [0.5,1.5]"
        )

    S = net_arm - X
    if S <= 0.0:
        raise SleeveDraftValidationError("resolved sleeve length S <= 0")

    AH = float(armhole_length_cm)
    if not math.isfinite(AH) or AH <= 0.0:
        raise SleeveDraftValidationError("AH must be positive")

    cap_reduction = float(_suit_value(
        suit_params, "sleeve_cap_reduction_cm", 4.0
    ))
    if not 3.0 <= cap_reduction <= 4.0:
        raise SleeveDraftValidationError(
            "sleeve_cap_reduction_cm outside formal range [3.0,4.0]"
        )

    D = (B / 6.0 + 9.5) / 8.0

    return ResolvedSleeveParams(
        net_full_arm_length_cm=net_arm,
        sleeve_length_reduction_X_cm=X,
        sleeve_length_S_cm=S,
        B_cm=B,
        D_cm=D,
        AH_cm=AH,
        cap_reduction_cm=cap_reduction,
    )


def _prototype_lines(proto):
    p = proto
    return {
        "ih": ["i", "h"],
        "de": ["d", "e"],
        "ce": ["c", "e"],
        "fg": ["f", "g"],
    }


def build_sleeve_construction_points(
    body,
    suit_params,
    *,
    armhole_length_cm,
    prototype_result,
):
    """Build every sleeve helper point from current rules and prototype."""
    r = resolve_sleeve_params(
        body, suit_params, armhole_length_cm=armhole_length_cm
    )

    if prototype_result is None:
        raise SleeveDraftValidationError(
            "prototype_result is required; frozen sleeve-point fallback removed"
        )

    proto = deepcopy(prototype_result.points)
    required = ("i","h","c","d","e","f","g","b1","b2","c2")
    missing = [k for k in required if k not in proto]
    if missing:
        raise SleeveDraftValidationError(
            f"prototype_result missing sleeve references: {missing}"
        )

    i, h = _arr(proto["i"]), _arr(proto["h"])
    c, d, e = _arr(proto["c"]), _arr(proto["d"]), _arr(proto["e"])
    f, g = _arr(proto["f"]), _arr(proto["g"])
    b1 = _arr(proto["b1"])
    b2 = _arr(proto["b2"])
    c2 = _arr(proto["c2"])

    right = _unit(d, e)  # vertical in prototype, not desired.
    # Formal horizontal drafting direction is f->g.
    xdir = _unit(f, g)
    updir = _unit(h, i)

    # c2 horizontal -> ih / de.
    d2 = _arr(_line_intersection(
        c2, c2 + xdir, i, h
    ))
    d1 = _arr(_line_intersection(
        c2, c2 + xdir, d, e
    ))

    # h upward AH/3 on ih.
    d5 = h + (r.AH_cm / 3.0) * updir
    d4 = _arr(_line_intersection(
        d5, d5 + xdir, d, e
    ))

    # d3 on d2-d1 with |b1d3|=AH/2-cap_reduction.
    radius = r.AH_cm / 2.0 - r.cap_reduction_cm
    if radius <= EPS:
        raise SleeveDraftValidationError(
            "AH/2-cap_reduction must be positive"
        )
    d3 = _arr(_circle_line_pick_d3(b1, radius, d2, d1))

    # vertical through d3 intersects d5-d4.
    d6 = _arr(_line_intersection(
        d3, d3 + updir, d5, d4
    ))
    BF = _dist(d5, d6)

    # e1 midpoint(d5,d6) right 2D/3.
    e1 = 0.5 * (d5 + d6) + (2.0 * r.D_cm / 3.0) * xdir

    # e2 on extended ih; |e1e2|=S+1.5; choose lower branch.
    e2 = _arr(_circle_vertical_lower(
        e1, r.sleeve_length_S_cm + 1.5, float(i[0])
    ))

    # f group.
    f1 = d2 + (BF / 4.0 - 0.5) * xdir
    f4 = 0.5 * (e1 + f1)
    f2 = _arr(_pick_upper_left(
        _normal_candidates(f4, e1, f1, 1.0), f4
    ))
    f3 = h - r.D_cm * xdir

    # right cap h1/h2.
    h1 = 0.5 * (e1 + d3)
    h2 = _arr(_pick_upper_right(
        _normal_candidates(h1, e1, d3, 1.0), h1
    ))

    # h3/h4 based on prototype ce and line i-e2.
    h3 = _arr(_line_intersection(i, e2, c, e))
    h4 = h3 + 1.5 * _unit(h3, i)

    h5 = h4 - (r.D_cm - 1.5) * xdir
    h6 = h4 + (r.D_cm + 1.5) * xdir
    h7 = e2 - r.D_cm * xdir
    h8 = h + r.D_cm * xdir
    h9 = e2 + r.D_cm * xdir

    # j4 and j1.
    j4 = _arr(_line_intersection(h4, h4 + xdir, d, e))

    CW = (2.0 / 3.0) * BF
    e1e2_dir = _unit(e1, e2)
    n1 = np.asarray([-e1e2_dir[1], e1e2_dir[0]], dtype=float)
    n2 = -n1
    j1_candidates = [e2 + CW*n1, e2 + CW*n2]
    j1 = max(
        j1_candidates,
        key=lambda q: (q[0] - e2[0], e2[1] - q[1])
    )

    # d3-j1 intersections.
    j3 = _arr(_line_intersection(d3, j1, f, g))
    j5 = _arr(_line_intersection(d3, j1, h4, j4))

    # k7/k8/k9.
    k7 = j3 + (2.0 * r.D_cm / 3.0) * xdir
    k8 = j5 + (2.0 * r.D_cm / 3.0 + 0.5) * xdir
    k9 = 0.5 * (j5 + k8)

    # k1-k4.
    k1 = _arr(_line_intersection(e1, e2, f, g))
    k2 = k1 - 1.0 * xdir
    k3 = k2 + (1.0 / 3.0) * (c2 - k2)
    k4 = _arr(_pick_lower_right(
        _normal_candidates(k3, k2, c2, r.D_cm / 2.0), k3
    ))

    pts = {
        # prototype references
        "i": i.tolist(), "h": h.tolist(),
        "c": c.tolist(), "d": d.tolist(), "e": e.tolist(),
        "f": f.tolist(), "g": g.tolist(),
        "b1": b1.tolist(), "b2": b2.tolist(), "c2": c2.tolist(),

        # sleeve formal construction
        "d1": d1.tolist(), "d2": d2.tolist(),
        "d3": d3.tolist(), "d4": d4.tolist(),
        "d5": d5.tolist(), "d6": d6.tolist(),
        "e1": e1.tolist(), "e2": e2.tolist(),
        "f1": f1.tolist(), "f2": f2.tolist(),
        "f3": f3.tolist(), "f4": f4.tolist(),
        "h1": h1.tolist(), "h2": h2.tolist(),
        "h3": h3.tolist(), "h4": h4.tolist(),
        "h5": h5.tolist(), "h6": h6.tolist(),
        "h7": h7.tolist(), "h8": h8.tolist(), "h9": h9.tolist(),
        "j1": j1.tolist(), "j3": j3.tolist(),
        "j4": j4.tolist(), "j5": j5.tolist(),
        "k1": k1.tolist(), "k2": k2.tolist(),
        "k3": k3.tolist(), "k4": k4.tolist(),
        "k7": k7.tolist(), "k8": k8.tolist(), "k9": k9.tolist(),
        # j2 / k5 / k6 are curve-derived later.
    }

    derived = {
        "B_cm": r.B_cm,
        "AH_cm": r.AH_cm,
        "D_cm": r.D_cm,
        "S_cm": r.sleeve_length_S_cm,
        "X_cm": r.sleeve_length_reduction_X_cm,
        "cap_reduction_cm": r.cap_reduction_cm,
        "b1d3_target_cm": radius,
        "BF_cm": BF,
        "CW_cm": CW,
        "e1e2_target_cm": r.sleeve_length_S_cm + 1.5,
        "prototype_b2_h8_distance_cm": _dist(b2, h8),
    }

    diagnostics = {
        "point_policy": "FULL_RULE_DRIVEN_FROM_CURRENT_MENS_PROTOTYPE",
        "frozen_point_dependency_count": 0,
        "b1d3_rule": "|b1d3|=AH/2-cap_reduction",
        "cap_reduction_range_cm": [3.0, 4.0],
        "small_cap_b2_fg_rule": (
            "b2 is kept as prototype tangency reference; b2==h8 under "
            "prototype formulas, so it is not inserted as a second boundary "
            "vertex between k5 and k4"
        ),
        "b2_literal_boundary_vertex_inserted": False,
        "three_d_modified": False,
        "boxmesh_run": False,
        "warp_run": False,
    }

    return pts, derived, diagnostics, deepcopy(proto), _prototype_lines(proto)


def _chain_controls(points, names, scale=0.22, endpoint_tangents=None):
    """C1 cubic chain through all named knots.

    Interior handles on both sides of the same knot have identical length and
    direction, so the chain is true C1 rather than only visually G1.
    """
    endpoint_tangents = endpoint_tangents or {}
    P = [_arr(points[n]) for n in names]
    N = len(P)
    if N < 2:
        raise SleeveDraftValidationError("curve chain needs >=2 points")

    tangents = []
    handles = []

    for idx in range(N):
        name = names[idx]
        if name in endpoint_tangents:
            t = _unit_vec(endpoint_tangents[name])
        elif idx == 0:
            t = _unit_vec(P[1] - P[0])
        elif idx == N - 1:
            t = _unit_vec(P[-1] - P[-2])
        else:
            t = _unit_vec(P[idx+1] - P[idx-1])
        tangents.append(t)

        if idx == 0:
            h = scale * _dist(P[0], P[1])
        elif idx == N - 1:
            h = scale * _dist(P[-2], P[-1])
        else:
            h = scale * min(
                _dist(P[idx-1], P[idx]),
                _dist(P[idx], P[idx+1]),
            )
        handles.append(max(float(h), 0.05))

    out = {}
    for idx in range(N - 1):
        p0, p1 = P[idx], P[idx+1]
        c1 = p0 + handles[idx] * tangents[idx]
        c2 = p1 - handles[idx+1] * tangents[idx+1]
        out[(names[idx], names[idx+1])] = (c1, c2)
    return out


def _q(points, p0, p1, c1, c2):
    return {
        "q1": list(abs_cp_to_q(points[p0], points[p1], c1)),
        "q2": list(abs_cp_to_q(points[p0], points[p1], c2)),
    }


def _segment(points, name, p0, p1, c1, c2, piece, role):
    q = _q(points, p0, p1, c1, c2)
    return {
        "label": name,
        "p0": p0, "p1": p1,
        "piece": piece,
        "q1": list(q["q1"]), "q2": list(q["q2"]),
        "c1": _arr(c1).tolist(), "c2": _arr(c2).tolist(),
        "shape_role": role,
    }


def _straight(points, name, p0, p1, piece, role):
    a = _arr(points[p0])
    b = _arr(points[p1])
    c1 = a + (b-a)/3.0
    c2 = a + 2.0*(b-a)/3.0
    return _segment(points, name, p0, p1, c1, c2, piece, role)


def _apply_override(points, seg, override):
    if not override:
        return seg
    p0, p1 = seg["p0"], seg["p1"]
    q1 = list(map(float, override["q1"]))
    q2 = list(map(float, override["q2"]))
    seg["q1"] = q1
    seg["q2"] = q2
    seg["c1"] = list(q_to_abs(points[p0], points[p1], q1))
    seg["c2"] = list(q_to_abs(points[p0], points[p1], q2))
    seg["shape_role"] = "sleeve_curve_shapes_clean.yaml:q_override"
    return seg


def _reverse_segment(points, name, p0, p1, c1, c2, piece, role):
    """Input is canonical p1->p0 controls; store p0->p1."""
    return _segment(points, name, p0, p1, c2, c1, piece, role)


def build_curve_system(
    base_points,
    derived,
    *,
    curve_overrides=None,
):
    """Build current sleeve curves; derive j2/k5/k6 from final curve tangents."""
    points = deepcopy(base_points)
    overrides = deepcopy(
        _load_curve_overrides() if curve_overrides is None else curve_overrides
    )
    seg = {}

    # --------------------------------------------------------------
    # Big cap: exact pass-through chains.
    # --------------------------------------------------------------
    left_cap = _chain_controls(
        points, ("f3","b1","f1","f2","e1"), scale=0.20
    )
    for (a,b), name in zip(
        (("f3","b1"),("b1","f1"),("f1","f2"),("f2","e1")),
        ("big_top_f3_b1","big_top_b1_f1","big_top_f1_f2","big_top_f2_e1"),
    ):
        c1,c2 = left_cap[(a,b)]
        seg[name] = _apply_override(
            points,
            _segment(points,name,a,b,c1,c2,"big","C1_CAP_CHAIN"),
            overrides.get(name),
        )

    right_cap = _chain_controls(
        points, ("e1","h2","d3"), scale=0.22
    )
    for (a,b), name in zip(
        (("e1","h2"),("h2","d3")),
        ("big_top_e1_h2","big_top_h2_d3"),
    ):
        c1,c2 = right_cap[(a,b)]
        seg[name] = _apply_override(
            points,
            _segment(points,name,a,b,c1,c2,"big","C1_CAP_CHAIN"),
            overrides.get(name),
        )

    # --------------------------------------------------------------
    # Master side f3->h5->h7, true C1.
    # --------------------------------------------------------------
    master = _chain_controls(
        points, ("f3","h5","h7"), scale=0.24
    )
    c1,c2 = master[("f3","h5")]
    tmp = _reverse_segment(
        points, "big_left_h5_f3", "h5","f3",
        c1,c2,"big","C1_MASTER_SIDE_REVERSED"
    )
    seg["big_left_h5_f3"] = _apply_override(
        points,tmp,overrides.get("big_left_h5_f3")
    )
    c1,c2 = master[("h5","h7")]
    tmp = _reverse_segment(
        points, "big_left_h7_h5", "h7","h5",
        c1,c2,"big","C1_MASTER_SIDE_REVERSED"
    )
    seg["big_left_h7_h5"] = _apply_override(
        points,tmp,overrides.get("big_left_h7_h5")
    )

    # Final tangent at h7 from current stored reversed segment.
    master_end_tangent = _unit_vec(
        _arr(points["h7"]) - _arr(seg["big_left_h7_h5"]["c1"])
    )
    points["j2"] = (
        _arr(points["h7"]) + 0.5 * master_end_tangent
    ).tolist()
    seg["big_left_j2_h7"] = _straight(
        points, "big_left_j2_h7", "j2","h7",
        "big","MASTER_END_TANGENT_EXTENSION_0p5"
    )

    # --------------------------------------------------------------
    # Slave side is exact +2D translation of final master geometry.
    # h8/h6/h9 were already rule-derived.
    # --------------------------------------------------------------
    off = np.asarray([2.0*float(derived["D_cm"]),0.0],dtype=float)

    # Derive slave controls by translating canonical master controls.
    # Use final current controls (including possible master q overrides).
    # Stored master orientations are reversed, so reconstruct canonical.
    mf3_h5_c1 = _arr(seg["big_left_h5_f3"]["c2"])
    mf3_h5_c2 = _arr(seg["big_left_h5_f3"]["c1"])
    mh5_h7_c1 = _arr(seg["big_left_h7_h5"]["c2"])
    mh5_h7_c2 = _arr(seg["big_left_h7_h5"]["c1"])

    slave_start_tangent = _unit_vec(
        (mf3_h5_c1 + off) - _arr(points["h8"])
    )
    slave_end_tangent = _unit_vec(
        _arr(points["h9"]) - (mh5_h7_c2 + off)
    )

    points["k5"] = (
        _arr(points["h8"]) - 0.8 * slave_start_tangent
    ).tolist()

    seg["small_outer_h8_k5"] = _straight(
        points,"small_outer_h8_k5","h8","k5",
        "small","SLAVE_START_TANGENT_EXTENSION_0p8"
    )

    # stored reverse orientations
    seg["small_outer_h6_h8"] = _segment(
        points,"small_outer_h6_h8","h6","h8",
        mf3_h5_c2+off, mf3_h5_c1+off,
        "small","EXACT_TRANSLATED_MASTER"
    )
    seg["small_outer_h9_h6"] = _segment(
        points,"small_outer_h9_h6","h9","h6",
        mh5_h7_c2+off, mh5_h7_c1+off,
        "small","EXACT_TRANSLATED_MASTER"
    )

    # --------------------------------------------------------------
    # Big cuff j2->j1, default upward-convex; stored j1->j2.
    # --------------------------------------------------------------
    p0 = _arr(points["j2"])
    p1 = _arr(points["j1"])
    v = p1-p0
    perp = np.asarray([-v[1],v[0]],dtype=float)
    canonical_c1 = p0 + v/3.0 + 0.04*perp
    canonical_c2 = p0 + 2.0*v/3.0 + 0.04*perp
    tmp = _reverse_segment(
        points,"bottom_j1_j2","j1","j2",
        canonical_c1,canonical_c2,
        "big","DEFAULT_UPWARD_CONVEX_CUFF"
    )
    seg["bottom_j1_j2"] = _apply_override(
        points,tmp,overrides.get("bottom_j1_j2")
    )

    # k6 = slave end-tangent ray ∩ current cuff.
    cuff_record = {
        "kind":"curve",
        "p0":"j1","p1":"j2",
        "c1":seg["bottom_j1_j2"]["c1"],
        "c2":seg["bottom_j1_j2"]["c2"],
        "source":"current_big_cuff",
    }
    _, k6, ray_lambda = ray_intersection_with_record(
        points["h9"], slave_end_tangent, cuff_record, points
    )
    points["k6"] = list(k6)
    seg["small_outer_k6_h9"] = _straight(
        points,"small_outer_k6_h9","k6","h9",
        "small","SLAVE_END_TANGENT_TO_CUFF"
    )

    # --------------------------------------------------------------
    # FINAL small cuff j1->k6.
    #
    # The accepted candidate is a cubic curve.  No smoothing, C1 repair,
    # or re-fitting is performed here: q1/q2 are loaded verbatim from
    # sleeve_curve_shapes_clean.yaml and mapped to the CURRENT j1/k6.
    # --------------------------------------------------------------
    a = _arr(points["j1"])
    b = _arr(points["k6"])
    c1 = a + (b-a)/3.0
    c2 = a + 2.0*(b-a)/3.0
    seg["small_cuff_j1_k6"] = _apply_override(
        points,
        _segment(
            points, "small_cuff_j1_k6",
            "j1", "k6", c1, c2,
            "small", "FINAL_FROZEN_SMALL_CUFF"
        ),
        overrides.get("small_cuff_j1_k6"),
    )

    # --------------------------------------------------------------
    # Big / small long sides: full C1 chains through formal points.
    # --------------------------------------------------------------
    big_right = _chain_controls(
        points, ("d3","k7","k8","j1"), scale=0.22
    )
    for (a,b), name in zip(
        (("d3","k7"),("k7","k8"),("k8","j1")),
        ("big_right_d3_k7","big_right_k7_k8","big_right_k8_j1"),
    ):
        c1,c2=big_right[(a,b)]
        seg[name]=_apply_override(
            points,
            _segment(points,name,a,b,c1,c2,"big","C1_LONG_SIDE"),
            overrides.get(name),
        )

    small_right = _chain_controls(
        points, ("c2","j3","k9","j1"), scale=0.22
    )
    for (a,b), name in zip(
        (("c2","j3"),("j3","k9"),("k9","j1")),
        ("small_right_c2_j3","small_right_j3_k9","small_right_k9_j1"),
    ):
        c1,c2=small_right[(a,b)]
        seg[name]=_apply_override(
            points,
            _segment(points,name,a,b,c1,c2,"small","C1_LONG_SIDE"),
            overrides.get(name),
        )

    # --------------------------------------------------------------
    # Small cap k5->k4->c2.
    # User's b2/fg tangency reference:
    # b2 == h8 formally, so b2 is not inserted as a boundary vertex.
    # Default cap-start tangent is parallel to fg.
    # --------------------------------------------------------------
    fg_dir = _unit(points["f"],points["g"])
    small_cap = _chain_controls(
        points, ("k5","k4","c2"), scale=0.24,
        endpoint_tangents={"k5":fg_dir}
    )
    for (a,b), name in zip(
        (("k5","k4"),("k4","c2")),
        ("small_top_k5_k4","small_top_k4_c2"),
    ):
        c1,c2=small_cap[(a,b)]
        seg[name]=_apply_override(
            points,
            _segment(
                points,name,a,b,c1,c2,"small",
                "DOWNWARD_CAP_B2_FG_TANGENCY_REFERENCE"
            ),
            overrides.get(name),
        )

    return points, seg, {
        "j2_extension_cm": _dist(points["h7"],points["j2"]),
        "k5_extension_cm": _dist(points["h8"],points["k5"]),
        "k6_ray_extension_cm": float(ray_lambda),
        "small_cap_tangent_reference": "b2/fg",
        "b2_h8_distance_cm": _dist(points["b2"],points["h8"]),
        "b2_inserted_as_boundary_vertex": False,
    }


def _curve_length(points, segment, samples=160):
    p0=_arr(points[segment["p0"]])
    p1=_arr(points[segment["p1"]])
    c1=_arr(segment["c1"])
    c2=_arr(segment["c2"])
    t=np.linspace(0.0,1.0,samples)
    u=1.0-t
    xy=((u**3)[:,None]*p0
        +(3*u*u*t)[:,None]*c1
        +(3*u*t*t)[:,None]*c2
        +(t**3)[:,None]*p1)
    return float(np.sum(np.linalg.norm(np.diff(xy,axis=0),axis=1)))


def build_sleeve_points(
    body,
    suit_params,
    *,
    armhole_length_cm,
    prototype_result,
    curve_overrides=None,
):
    base, derived, diagnostics, proto, proto_lines = (
        build_sleeve_construction_points(
            body,
            suit_params,
            armhole_length_cm=armhole_length_cm,
            prototype_result=prototype_result,
        )
    )
    points, segments, curve_diag = build_curve_system(
        base, derived, curve_overrides=curve_overrides
    )

    # Formula audits / derived values.
    derived.update({
        "b1d3_actual_cm": _dist(points["b1"],points["d3"]),
        "d5d6_cm": _dist(points["d5"],points["d6"]),
        "e1e2_cm": _dist(points["e1"],points["e2"]),
        "f2f4_cm": _dist(points["f2"],points["f4"]),
        "h1h2_cm": _dist(points["h1"],points["h2"]),
        "h3h4_cm": _dist(points["h3"],points["h4"]),
        "h7j2_cm": _dist(points["h7"],points["j2"]),
        "h8k5_cm": _dist(points["h8"],points["k5"]),
        "k2k3_ratio": _dist(points["k2"],points["k3"]) / max(
            _dist(points["k2"],points["c2"]), EPS
        ),
        "k3k4_cm": _dist(points["k3"],points["k4"]),
    })

    big_cap_names = [
        "big_top_e1_h2","big_top_h2_d3",
        "big_top_f3_b1","big_top_b1_f1",
        "big_top_f1_f2","big_top_f2_e1",
    ]
    small_cap_names = ["small_top_k5_k4","small_top_k4_c2"]
    big_cap = sum(_curve_length(points,segments[n]) for n in big_cap_names)
    small_cap = sum(_curve_length(points,segments[n]) for n in small_cap_names)
    total_cap = big_cap + small_cap
    AH = float(derived["AH_cm"])

    derived.update({
        "big_cap_cm": big_cap,
        "small_cap_cm": small_cap,
        "total_cap_cm": total_cap,
        "cap_minus_AH_cm": total_cap-AH,
        "cap_minus_AH_percent": 100.0*(total_cap-AH)/AH,
        "CAP_FIT_THRESHOLD": "NOT_FROZEN",
    })
    diagnostics.update(curve_diag)
    diagnostics["curve_policy"] = (
        "FORMAL_POINTS_RULE_DRIVEN; FINAL_CURVE_Q_FROZEN_FROM_ACCEPTED_CANDIDATE"
    )
    diagnostics["small_cuff_policy"] = "FINAL_FROZEN_CURVE_J1_K6"
    diagnostics["curve_editor_required"] = False

    return (
        points, segments, derived, diagnostics, proto, proto_lines
    )


class SuitTwoPieceSleeveDraft:
    def build(
        self,
        *,
        body,
        suit_params,
        armhole_length_cm,
        prototype_result,
        curve_overrides=None,
    ):
        points, segments, derived, diagnostics, proto, proto_lines = (
            build_sleeve_points(
                body,
                suit_params,
                armhole_length_cm=armhole_length_cm,
                prototype_result=prototype_result,
                curve_overrides=curve_overrides,
            )
        )

        return SuitTwoPieceSleeveDraftResult(
            points=points,
            segments=segments,
            big_boundary_groups=deepcopy(BIG_BOUNDARY_GROUPS),
            small_boundary_groups=deepcopy(SMALL_BOUNDARY_GROUPS),
            derived_quantities=derived,
            diagnostics=diagnostics,
            prototype_points=proto,
            prototype_lines=proto_lines,
        )
