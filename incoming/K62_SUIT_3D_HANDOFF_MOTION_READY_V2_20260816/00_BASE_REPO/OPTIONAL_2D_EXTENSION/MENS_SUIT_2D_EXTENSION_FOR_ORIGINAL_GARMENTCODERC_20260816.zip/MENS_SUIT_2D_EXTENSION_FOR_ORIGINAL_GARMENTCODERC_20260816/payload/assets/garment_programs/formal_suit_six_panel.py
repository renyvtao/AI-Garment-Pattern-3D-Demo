"""Stage-A3 pygarment adapters for the dynamic six-panel front.

The drafting calculation stays in suit_six_panel_geometry.py.  This module only:
- converts the center-front and side-front records to real Panels;
- creates the princess seam interfaces/stitch;
- exposes a compatibility front component so the current sleeve/collar semantic
  code can still consume front.interfaces without re-running drafting.

A3 does not validate the newer semantic-rest-frame / torso-wrap 3-D placement
for six-panel.  That remains a later 3-D stage.
"""
from __future__ import annotations

import pygarment as pyg

from assets.garment_programs.formal_suit_front_panel import (
    _nearest_fraction_on_record,
    _split_edge_for_markers,
)
from assets.garment_programs.suit_geometry import (
    localize_points,
    make_edge,
    make_sequence,
)
from assets.garment_programs.suit_lapel_fold_semantics import (
    build_lapel_fold_records,
    lapel_fold_definition,
)


_LOWER_FRONT_SOURCES = {
    "front_edge_1",
    "front_edge_2",
    "front_edge_3",
    "front_straight_t6_t2",
    "front_straight_t2_r3",
}


def _build_panel_edges(panel, records, points):
    built_rows = []
    grouped = {}
    panel.edges = pyg.EdgeSequence()
    for record in records:
        edge = make_edge(panel.vertices, record, points)
        panel.edges.append(edge)
        built_rows.append((record, edge))
        grouped.setdefault(record.get("semantic_group"), []).append(edge)
    return built_rows, grouped


class FormalSixPanelCenterFrontPanel(pyg.Panel):
    """Center-front piece: neck/shoulder/upper armhole/front opening."""

    def __init__(
        self,
        name,
        geometry,
        front_draft_result,
        *,
        button_count=2,
        button_stitch_cm=0.8,
    ):
        super().__init__(name)
        self.geometry = geometry
        self.front_draft_result = front_draft_result
        self.semantic_points = {
            "r5": list(front_draft_result.points["r5"]),
            "s4": list(front_draft_result.points["s4"]),
        }
        self.button_count = int(button_count)
        if self.button_count not in (1, 2):
            raise ValueError("button_count must be 1 or 2")

        self.original_points = geometry["points"]
        # Both six-panel front pieces deliberately share the same drafting
        # coordinate origin so their pre-sew registration stays meaningful.
        self.vertices = localize_points(self.original_points, "r5")
        built_rows, grouped = _build_panel_edges(
            self, geometry["center_records"], self.original_points
        )

        targets = [(
            "button_1",
            front_draft_result.derived_quantities["first_button_drafting_point"],
        )]
        if self.button_count >= 2:
            targets.append((
                "button_2",
                front_draft_result.derived_quantities["second_button_drafting_point"],
            ))

        lower_rows = [
            row for row in built_rows if row[0].get("source") in _LOWER_FRONT_SOURCES
        ]
        if not lower_rows:
            raise ValueError("STAGE_A3_NO_LOWER_FRONT_FOR_BUTTON_MAPPING")

        markers_by_edge = {}
        self.button_projection_report = {}
        for button_name, target in targets:
            best = None
            for record, edge in lower_rows:
                fraction, distance = _nearest_fraction_on_record(
                    record, self.original_points, target
                )
                candidate = (distance, fraction, record, edge)
                if best is None or candidate[0] < best[0]:
                    best = candidate
            distance, fraction, record, edge = best
            markers_by_edge.setdefault(
                id(edge), {"edge": edge, "markers": []}
            )["markers"].append((button_name, fraction))
            self.button_projection_report[button_name] = {
                "drafting_point": list(target),
                "boundary_source": record.get("source"),
                "nearest_arc_fraction": float(fraction),
                "draft_to_boundary_distance_cm": float(distance),
            }

        replacements = {}
        button_edges = {}
        for row in markers_by_edge.values():
            edge = row["edge"]
            parts, buttons = _split_edge_for_markers(
                edge, row["markers"], button_stitch_cm
            )
            self.edges.substitute(edge, parts)
            replacements[id(edge)] = parts
            button_edges.update(buttons)

        def resolved(group_name):
            out = []
            for edge in grouped.get(group_name, []):
                out.extend(replacements.get(id(edge), [edge]))
            return out

        required = ("neckline", "shoulder", "armhole_upper", "hem", "front_opening", "princess")
        for name_ in required:
            if not grouped.get(name_):
                raise ValueError(f"STAGE_A3_CENTER_MISSING_INTERFACE:{name_}")

        self.interfaces = {
            name_: pyg.Interface(self, pyg.EdgeSequence(*resolved(name_)))
            for name_ in required
        }
        self.interfaces["button_1"] = pyg.Interface(
            self, pyg.EdgeSequence(button_edges["button_1"])
        )
        if self.button_count >= 2:
            self.interfaces["button_2"] = pyg.Interface(
                self, pyg.EdgeSequence(button_edges["button_2"])
            )
        opening_edges = list(self.interfaces["front_opening"].edges)
        i1 = next(i for i,e in enumerate(opening_edges) if getattr(e, "label", "") == "virtual_button_1")
        i2 = (next(i for i,e in enumerate(opening_edges) if getattr(e, "label", "") == "virtual_button_2")
              if self.button_count >= 2 else i1)
        if i1 > i2:
            i1, i2 = i2, i1
        span = opening_edges[i1 + 1:i2]
        if self.button_count >= 2:
            # two_button_span is a semantic-only closure/render view.  The
            # lower opening may be represented by curved front_edge_3 or by
            # the current straight-front pair; neither case changes the
            # structural pattern/stitch graph.
            span = [e for e in span if not str(getattr(e, "label", "")).startswith("virtual_button_")]
            if span:
                self.interfaces["two_button_span"] = pyg.Interface(self, pyg.EdgeSequence(*span))

        self.internal_features = {
            "chest_waist_dart": make_sequence(
                self.vertices,
                geometry["chest_waist_dart"],
                self.original_points,
            ),
            "drafting_buttons": {
                "button_1": list(
                    front_draft_result.derived_quantities["first_button_drafting_point"]
                ),
                "button_2": list(
                    front_draft_result.derived_quantities["second_button_drafting_point"]
                ),
                "active_count": self.button_count,
            },
        }
        lapel_fold_parent = front_draft_result.diagnostics[
            "lapel_fold_semantic"
        ]["collar_edge_reference"]
        self.internal_features["lapel_fold"] = make_sequence(
            self.vertices,
            build_lapel_fold_records(
                self.original_points,
                lapel_fold_parent,
            ),
            self.original_points,
        )
        self.internal_features["lapel_fold_definition"] = (
            lapel_fold_definition(lapel_fold_parent)
        )


class FormalSixPanelSideFrontPanel(pyg.Panel):
    """Side-front piece: lower armhole/side seam/side hem/princess."""

    def __init__(self, name, geometry):
        super().__init__(name)
        self.geometry = geometry
        self.original_points = geometry["points"]
        self.vertices = localize_points(self.original_points, "r5")
        _, grouped = _build_panel_edges(
            self, geometry["side_records"], self.original_points
        )

        for name_ in ("armhole_lower", "side_seam", "hem", "princess"):
            if not grouped.get(name_):
                raise ValueError(f"STAGE_A3_SIDE_MISSING_INTERFACE:{name_}")

        self.interfaces = {
            "armhole_lower": pyg.Interface(
                self, pyg.EdgeSequence(*grouped["armhole_lower"])
            ),
            "side_seam": pyg.Interface(
                self, pyg.EdgeSequence(*grouped["side_seam"])
            ),
            "hem": pyg.Interface(
                self, pyg.EdgeSequence(*grouped["hem"])
            ),
        }

        # side_records follow the closed boundary as w1->p9->p6.
        # Expose the stitching semantics in the confirmed SAME semantic order:
        # p6->p9->w1.
        princess_edges = list(reversed(grouped["princess"]))
        princess = pyg.Interface(
            self, pyg.EdgeSequence(*princess_edges)
        )
        princess.flip_edges()
        self.interfaces["princess"] = princess


class FormalSixPanelFront(pyg.Component):
    """Two-piece front that remains compatible with current front semantic APIs.

    ``side_dart_left/right`` below are compatibility aliases used only by the
    existing armhole semantic traversal.  They do NOT create a dart stitch in
    six-panel mode; the actual internal stitch is ``princess``.
    """

    def __init__(
        self,
        name,
        geometry,
        front_draft_result,
        *,
        button_count=2,
    ):
        super().__init__(name)
        self.geometry = geometry
        self.button_count = int(button_count)
        self.semantic_points = {
            "r5": list(front_draft_result.points["r5"]),
            "s4": list(front_draft_result.points["s4"]),
        }

        self.center = FormalSixPanelCenterFrontPanel(
            f"{name}_center",
            geometry,
            front_draft_result,
            button_count=self.button_count,
        )
        self.side = FormalSixPanelSideFrontPanel(
            f"{name}_side",
            geometry,
        )
        self.subs = [self.center, self.side]
        # Expose the center-front internal fold semantic at the composite level
        # without turning it into a stitching Interface.
        self.internal_features = {
            "lapel_fold": self.center.internal_features["lapel_fold"],
            "lapel_fold_definition": (
                self.center.internal_features["lapel_fold_definition"]
            ),
        }

        self.interfaces = {
            "neckline": self.center.interfaces["neckline"],
            "shoulder": self.center.interfaces["shoulder"],
            "armhole_upper": self.center.interfaces["armhole_upper"],
            "armhole_lower": self.side.interfaces["armhole_lower"],
            "side_seam": self.side.interfaces["side_seam"],
            "front_opening": self.center.interfaces["front_opening"],
            "button_1": self.center.interfaces["button_1"],
            "princess_center": self.center.interfaces["princess"],
            "princess_side": self.side.interfaces["princess"],
            # Compatibility aliases for the existing semantic armhole builder:
            "side_dart_left": self.center.interfaces["princess"],
            "side_dart_right": self.side.interfaces["princess"],
        }
        if self.button_count >= 2:
            self.interfaces["button_2"] = self.center.interfaces["button_2"]
            self.interfaces["two_button_span"] = self.center.interfaces["two_button_span"]

        self.interfaces["armhole"] = pyg.Interface.from_multiple(
            self.center.interfaces["armhole_upper"],
            self.side.interfaces["armhole_lower"],
        )
        self.interfaces["hem"] = pyg.Interface.from_multiple(
            self.side.interfaces["hem"],
            self.center.interfaces["hem"],
        )

        # The actual topology change: p8/p9 are no longer sewn as a dart;
        # center and side pieces are sewn together along the princess seam.
        self.stitching_rules.append((
            self.center.interfaces["princess"],
            self.side.interfaces["princess"],
        ))

    def _owner_of_vertex(self, vertex):
        for panel in (self.center, self.side):
            for value in panel.vertices.values():
                if vertex is value:
                    return panel
            for edge in panel.edges:
                if vertex is edge.start or vertex is edge.end:
                    return panel
        raise KeyError("vertex is not owned by this six-panel front")

    def point_to_3D(self, vertex):
        """Delegate semantic landmark conversion to the owning real Panel."""
        return self._owner_of_vertex(vertex).point_to_3D(vertex)
