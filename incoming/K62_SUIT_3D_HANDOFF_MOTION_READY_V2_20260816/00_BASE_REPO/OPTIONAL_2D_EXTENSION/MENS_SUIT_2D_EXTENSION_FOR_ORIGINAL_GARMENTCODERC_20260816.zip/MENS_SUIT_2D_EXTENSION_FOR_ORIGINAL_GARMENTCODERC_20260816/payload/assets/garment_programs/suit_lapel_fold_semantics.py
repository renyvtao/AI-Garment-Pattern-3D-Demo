"""Common 2-D lapel fold semantics shared by notched and peak lapels.

Confirmed fold line
-------------------
    Curve(r7 -> s6) + Straight(s6 -> r3)

Upper relation
--------------
The upper fold curve is a drafting approximation of an equidistant offset of
the actual collar-edge parent curve:

    parent: Curve(r8 -> r5), source="a4_current_collar_r8_r5"
    child : Curve(r7 -> s6)

The child is NOT defined by chord parallelism.

Construction used here
----------------------
Let C(t) be the parent cubic Bezier r8->r5.

Let endpoint offset vectors be:
    d0 = r7 - r8
    d1 = s6 - r5

Define a linearly varying offset vector:
    D(t) = (1-t) d0 + t d1

Then the fold curve is:
    F(t) = C(t) + D(t)

This has useful drafting properties:
- exact endpoints: F(0)=r7, F(1)=s6;
- if d0 == d1, F is an exact translated parallel copy of C;
- otherwise the offset changes gradually from the r8-side value to the
  r5-side value, which is a controlled approximation of an equidistant
  offset relation;
- the actual parent Bezier curvature is preserved rather than replaced by
  chord-parallel logic.

The lower fold segment s6->r3 is straight.

This is an INTERNAL semantic feature, not a sewing Interface.
No 3-D fold angle, rest angle, stiffness, KE/KD, lay-back, collar roll,
attachment, or Warp constraint is defined here.
"""
from __future__ import annotations

import math
import numpy as np

EPS = 1.0e-10


class LapelFoldSemanticError(ValueError):
    pass


def _arr(v):
    return np.asarray(v, dtype=float)


def _norm(v):
    return float(np.linalg.norm(_arr(v)))


def _unit(v):
    v = _arr(v)
    n = _norm(v)
    if n <= EPS:
        raise LapelFoldSemanticError("zero-length direction")
    return v / n


def _angle_deg(a, b):
    a, b = _unit(a), _unit(b)
    dot = float(np.clip(np.dot(a, b), -1.0, 1.0))
    return math.degrees(math.acos(dot))


def _cubic(p0, c1, c2, p1, t):
    t = float(t)
    u = 1.0 - t
    return (
        u**3 * _arr(p0)
        + 3.0 * u*u*t * _arr(c1)
        + 3.0 * u*t*t * _arr(c2)
        + t**3 * _arr(p1)
    )


def _cubic_derivative(p0, c1, c2, p1, t):
    t = float(t)
    u = 1.0 - t
    p0, c1, c2, p1 = map(_arr, (p0, c1, c2, p1))
    return (
        3.0 * u*u * (c1-p0)
        + 6.0 * u*t * (c2-c1)
        + 3.0 * t*t * (p1-c2)
    )


def _validate_parent_record(parent_curve_record):
    if parent_curve_record is None:
        raise LapelFoldSemanticError(
            "missing parent collar-edge curve record"
        )
    if parent_curve_record.get("kind") != "curve":
        raise LapelFoldSemanticError(
            "parent collar-edge reference must be a curve"
        )
    if parent_curve_record.get("p0") != "r8" or parent_curve_record.get("p1") != "r5":
        raise LapelFoldSemanticError(
            "parent collar-edge curve must be r8->r5"
        )
    if "c1" not in parent_curve_record or "c2" not in parent_curve_record:
        raise LapelFoldSemanticError(
            "parent collar-edge curve is missing Bezier controls"
        )


def build_upper_fold_curve_record(points, parent_curve_record):
    """Build Curve(r7->s6) from the actual Curve(r8->r5) parent."""
    _validate_parent_record(parent_curve_record)

    required = ("r7", "s6", "r8", "r5")
    missing = [name for name in required if name not in points]
    if missing:
        raise LapelFoldSemanticError(
            "missing fold point(s): " + ", ".join(missing)
        )

    r8 = _arr(points["r8"])
    r5 = _arr(points["r5"])
    r7 = _arr(points["r7"])
    s6 = _arr(points["s6"])
    c1 = _arr(parent_curve_record["c1"])
    c2 = _arr(parent_curve_record["c2"])

    d0 = r7 - r8
    d1 = s6 - r5

    # Degree-elevated cubic control vectors for the linear vector field D(t).
    d_c1 = (2.0/3.0) * d0 + (1.0/3.0) * d1
    d_c2 = (1.0/3.0) * d0 + (2.0/3.0) * d1

    return {
        "kind": "curve",
        "p0": "r7",
        "p1": "s6",
        "c1": (c1 + d_c1).tolist(),
        "c2": (c2 + d_c2).tolist(),
        "source": "a4_common_lapel_fold_curve_r7_s6",
        "semantic_group": "lapel_fold",
        "offset_parent_source": parent_curve_record.get("source"),
        "offset_policy": "linear_endpoint_vector_field",
    }


def build_lapel_fold_records(points, parent_curve_record):
    """Build Curve(r7->s6) + Straight(s6->r3)."""
    required = ("r7", "s6", "r3", "r8", "r5")
    missing = [name for name in required if name not in points]
    if missing:
        raise LapelFoldSemanticError(
            "missing lapel-fold point(s): " + ", ".join(missing)
        )

    upper = build_upper_fold_curve_record(points, parent_curve_record)
    lower = {
        "kind": "straight",
        "p0": "s6",
        "p1": "r3",
        "source": "a4_common_lapel_fold_straight_s6_r3",
        "semantic_group": "lapel_fold",
    }
    return [upper, lower]


def lapel_fold_definition(parent_curve_record=None):
    parent_source = (
        None if parent_curve_record is None
        else parent_curve_record.get("source")
    )
    return {
        "semantic_group": "lapel_fold",
        "point_chain": ["r7", "s6", "r3"],
        "upper_segment": {
            "kind": "curve",
            "p0": "r7",
            "p1": "s6",
        },
        "lower_segment": {
            "kind": "straight",
            "p0": "s6",
            "p1": "r3",
        },
        "collar_edge_reference": {
            "kind": "curve",
            "p0": "r8",
            "p1": "r5",
            "source": parent_source or "a4_current_collar_r8_r5",
        },
        "upper_relation": "approx_equidistant_offset_of_curve",
        "offset_construction": "linear_endpoint_vector_field",
        "numeric_quality_threshold": "NOT_FROZEN",
        "is_sewing_interface": False,
        "physics_status": "2D_SEMANTIC_ONLY",
        "3d_fold_angle": "UNDEFINED",
        "rest_angle": "UNDEFINED",
        "crease_stiffness": "UNDEFINED",
        "warp_constraint": "NOT_DEFINED",
    }


def audit_lapel_fold(points, parent_curve_record, samples=101):
    """Measure the curve-offset relation without inventing a pass threshold."""
    upper = build_upper_fold_curve_record(points, parent_curve_record)

    r8 = _arr(points["r8"])
    r5 = _arr(points["r5"])
    r7 = _arr(points["r7"])
    s6 = _arr(points["s6"])

    pc1 = _arr(parent_curve_record["c1"])
    pc2 = _arr(parent_curve_record["c2"])
    fc1 = _arr(upper["c1"])
    fc2 = _arr(upper["c2"])

    distances = []
    tangent_diffs = []
    normal_deviation = []

    for t in np.linspace(0.0, 1.0, int(samples)):
        edge_p = _cubic(r8, pc1, pc2, r5, t)
        fold_p = _cubic(r7, fc1, fc2, s6, t)
        offset_vec = fold_p - edge_p
        distances.append(_norm(offset_vec))

        edge_t = _cubic_derivative(r8, pc1, pc2, r5, t)
        fold_t = _cubic_derivative(r7, fc1, fc2, s6, t)
        if _norm(edge_t) > EPS and _norm(fold_t) > EPS:
            ang = _angle_deg(edge_t, fold_t)
            tangent_diffs.append(min(ang, abs(180.0-ang)))

        if _norm(edge_t) > EPS and _norm(offset_vec) > EPS:
            ang = _angle_deg(edge_t, offset_vec)
            normal_deviation.append(abs(90.0-ang))

    d0 = _norm(r7-r8)
    d1 = _norm(s6-r5)

    out = {
        "point_chain": ["r7", "s6", "r3"],
        "upper_kind": "curve",
        "lower_kind": "straight",
        "parent_curve_source": parent_curve_record.get("source"),
        "offset_policy": "linear_endpoint_vector_field",
        "endpoint_offset_r8_to_r7_cm": d0,
        "endpoint_offset_r5_to_s6_cm": d1,
        "endpoint_offset_abs_diff_cm": abs(d0-d1),
        "OFFSET_MIN_CM": float(np.min(distances)),
        "OFFSET_MAX_CM": float(np.max(distances)),
        "OFFSET_MEAN_CM": float(np.mean(distances)),
        "OFFSET_RANGE_CM": float(np.max(distances)-np.min(distances)),
        "MEAN_TANGENT_DIRECTION_DIFF_DEG": (
            float(np.mean(tangent_diffs)) if tangent_diffs else None
        ),
        "MAX_TANGENT_DIRECTION_DIFF_DEG": (
            float(np.max(tangent_diffs)) if tangent_diffs else None
        ),
        "MEAN_OFFSET_NORMAL_DEVIATION_DEG": (
            float(np.mean(normal_deviation)) if normal_deviation else None
        ),
        "MAX_OFFSET_NORMAL_DEVIATION_DEG": (
            float(np.max(normal_deviation)) if normal_deviation else None
        ),
        "OFFSET_RELATION": "APPROX_EQUIDISTANT",
        "OFFSET_QUALITY_THRESHOLD": "NOT_FROZEN",
        "LAPEL_FOLD_SEMANTIC_DEFINED": True,
        "CURVE_OFFSET_CONSTRUCTION_DEFINED": True,
        "is_sewing_interface": False,
        "physics_status": "2D_SEMANTIC_ONLY",
    }
    return out
